library (
	name: "lib_tpLink_common",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to tpLink device DRIVERS",
	category: "utilities",
	documentationLink: ""
)

capability "Refresh"

def commonPreferences() {
	input ("nameSync", "enum", title: "Synchronize Names",
		   options: ["none": "Don't synchronize",
					 "device" : "TP-Link device name master",
					 "Hubitat" : "Hubitat label master"],
		   defaultValue: "none")
	input ("pollInterval", "enum", title: "Poll Interval (< 1 min can cause issues)",
		   options: ["5 sec", "10 sec", "30 sec", "1 min", "10 min", "15 min"],
		   defaultValue: "15 min")
	input ("developerData", "bool", title: "Get Data for Developer", defaultValue: false)
	input ("rebootDev", "bool", title: "Reboot Device then run Save Preferences", defaultValue: false)

	input ("encKey", "password", title: "Crypto key. Do not edit.")
	input ("encIv", "password", title: "Crypto vector. Do not edit.")
	input ("cookie", "password", title: "Session cookie. Do not edit.")
	if (getDataValue("protocol") == "KLAP") {
		input ("encSig", "password", title: "KLAP signature. Do not edit.")
	} else {
		input ("token", "password", title: "AES token. Do not edit.")
	}
}

def commonUpdated() {
	unschedule()
	Map logData = [:]
	if (rebootDev == true) {
		runInMillis(50, rebootDevice)
		device.updateSetting("rebootDev",[type:"bool", value: false])
		pauseExecution(20000)
	}
	updateAttr("commsError", "false")
	updateAttr("connected", "true")
	state.errorCount = 0
	state.lastCmd = ""
	logData << [pollInterval: setPollInterval()]
	logData << [loginInterval: setLoginInterval()]
	logData << setLogsOff()
	logData << deviceLogin()
	if (logData.status == "ERROR") {
		logWarn("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
	runIn(10, delayedUpdates)
}

def commonDelayedUpdates() {
	Map logData = [syncName: syncName()]
	if (developerData) { getDeveloperData() }
	refresh()
	return logData
}

def rebootDevice() {
	logWarn("rebootDevice: Rebooting device per preference request")
	def result = syncSend([method: "device_reboot"])
	logWarn("rebootDevice: ${result}")
}

def setPollInterval(pInterval = pollInterval) {
	def method = "commonRefresh"
	if (getDataValue("capability") == "hub" ||
	    getDataValue("capability") == "plug_multi") {
		method = "parentRefresh"
	} else if (getDataValue("capability") == "plug_em") {
		method = "emRefresh"
	}
	if (pInterval.contains("sec")) {
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", method)
		logInfo("setPollInterval: Polling intervals of less than one minute " +
				"can take high resources and may impact hub performance.")
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", method)
	}
	return pInterval
}

def setLoginInterval() {
	def startS = Math.round((59) * Math.random()).toInteger()
	def startM = Math.round((59) * Math.random()).toInteger()
	def startH = Math.round((11) * Math.random()).toInteger()
	schedule("${startS} ${startM} ${startH}/8 * * ?", "deviceLogin")
	return "8 hrs"
}

def syncName() {
	def logData = [syncName: nameSync]
	if (nameSync == "none") {
		logData << [status: "Label Not Updated"]
	} else {
		def cmdResp
		String nickname
		if (nameSync == "device") {
			cmdResp = syncSend([method: "get_device_info"])
			nickname = cmdResp.result.nickname
		} else if (nameSync == "Hubitat") {
			nickname = device.getLabel().bytes.encodeBase64().toString()
			List requests = [[method: "set_device_info",params: [nickname: nickname]]]
			requests << [method: "get_device_info"]
			cmdResp = syncSend(createMultiCmd(requests))
			cmdResp = cmdResp.result.responses.find { it.method == "get_device_info" }
			nickname = cmdResp.result.nickname
		}
		byte[] plainBytes = nickname.decodeBase64()
		String label = new String(plainBytes)
		device.setLabel(label)
		logData << [nickname: nickname, label: label, status: "Label Updated"]
	}
	device.updateSetting("nameSync", [type: "enum", value: "none"])
	return logData
}

def setLedRule() {
	def respData = syncSend([method: "get_led_info"]).result
	Map logData = [method: "setLed", ledRule: ledRule, currentRule: respData.led_rule]
	if (ledRule != respData.led_rule) {
		Map requests = [
			method: "set_led_info",
			params: [
				led_rule: ledRule,
				night_mode: [
					night_mode_type: respData.night_mode.night_mode_type,
					sunrise_offset: respData.night_mode.sunrise_offset, 
					sunset_offset:respData.night_mode.sunset_offset,
					start_time: respData.night_mode.start_time,
					end_time: respData.night_mode.end_time
				]]]
		respData = syncSend(requests).result
		respData = syncSend([method: "get_led_info"]).result
		logData << [status: "Updated"]
	} else {
		logData << [status: "NoChange"]
	}
	device.updateSetting("ledRule", [type:"enum", value: respData.led_rule])
	return logData
	
}

def getDeveloperData() {
	device.updateSetting("developerData",[type:"bool", value: false])
	def attrs = listAttributes()
	Date date = new Date()
	Map devData = [
		currentTime: date.toString(),
		name: device.getName(),
		status: device.getStatus(),
		dataValues: device.getData(),
		attributes: attrs,
		cmdResp: syncSend([method: "get_device_info"]),
		childData: getChildDevData()
	]
	logWarn("DEVELOPER DATA: ${devData}")
}

def getChildDevData(){
	Map cmdBody = [
		method: "get_child_device_list"
	]
	def childData = syncSend(cmdBody)
	if (childData.error_code == 0) {
		return childData.result.child_device_list
	} else {
		return "noChildren"
	}
}

def deviceLogin() {
	Map logData = [method: "deviceLogin"]
	Map sessionData =[:]
	if (getDataValue("protocol") == "KLAP") {
		sessionData = klapLogin(getDataValue("baseUrl"),
								parent.localHash.decodeBase64())
		logData << [localHash: parent.localHash.decodeBase64()]
	} else {
		sessionData = aesLogin(getDataValue("baseUrl"), parent.encPassword,
							   parent.encUsername)
		logData << [encPwd: parent.encPassword, encUser: parent.encUsername]
	}
	logData << [sessionData: sessionData]
	if (sessionData.status == "OK") {
		state.seqNo = sessionData.seqNo
		device.updateSetting("encKey",[type:"password", value: sessionData.encKey])
		device.updateSetting("encIv",[type:"password", value: sessionData.encIv])
		device.updateSetting("cookie",[type:"password", value: sessionData.cookie])
		if (sessionData.protocol == "KLAP") {
			device.updateSetting("encSig",[type:"password", value: sessionData.encSig])
		} else {
			device.updateSetting("token",[type:"password", value: sessionData.token])
		}
	} else {
		logWarn(logData)
	}
	return [method: "deviceLogin", loginStatus: sessionData.status]
}

def refresh() {
	if (getDataValue("capability") == "hub" ||
	    getDataValue("capability") == "plug_parent") {
		parentRefresh()
	} else if (getDataValue("capability") == "plug_em") {
		emRefresh()
	} else {
		asyncSend([method: "get_device_info"], "refresh", "deviceParse")
	}
}

def commonRefresh() {
	asyncSend([method: "get_device_info"], "refresh", "deviceParse")
}

def emRefresh() {
	List requests = [[method: "get_device_info"]]
	requests << [method:"get_energy_usage"]
	asyncSend(createMultiCmd(requests), "emRefresh", "deviceParse")
}

def parentRefresh() {
	List requests = [[method: "get_device_info"]]
	requests << [method:"get_child_device_list"]
	asyncSend(createMultiCmd(requests), "parentRefresh", "deviceParse")
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}
