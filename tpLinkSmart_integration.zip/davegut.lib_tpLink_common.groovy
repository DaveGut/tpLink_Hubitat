library (
	name: "lib_tpLink_common",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to tpLink device DRIVERS",
	category: "utilities",
	documentationLink: ""
)
def driverVer() { 
	if (type().contains("kasaSmart")) { return "2.3.6"}
	else { return "1.1" }
}

def nameSpace() { return "davegut" }

capability "Refresh"

def commonPreferences() {
	input ("nameSync", "enum", title: "Synchronize Names",
		   options: ["none": "Don't synchronize",
					 "device" : "TP-Link device name master",
					 "Hubitat" : "Hubitat label master"],
		   defaultValue: "none")
	input ("pollInterval", "enum", title: "Poll Interval (< 1 min can cause issues)",
		   options: ["5 sec", "10 sec", "30 sec", "1 min", "10 min"],
		   defaultValue: "10 min")
	input ("developerData", "bool", title: "Get Data for Developer", defaultValue: false)
	input ("rebootDev", "bool", title: "Reboot Device then run Save Preferences", defaultValue: false)
}

def commonUpdated() {
	unschedule()
	Map logData = [:]
	if (rebootDev == true) {
		runInMillis(50, rebootDevice)
		device.updateSetting("rebootDev",[type:"bool", value: false])
		pauseExecution(5000)
	}
	updateAttr("commsError", false)
	state.errorCount = 0
	state.lastCmd = ""
	logData << [login: setLoginInterval()]
	logData << setLogsOff()
	logData << deviceLogin()
	pauseExecution(5000)
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
	runIn(3, delayedUpdates)
	pauseExecution(10000)
}

def commonDelayedUpdates() {
	Map logData = [syncName: syncName()]
	logData << [pollInterval: setPollInterval()]
	if (developerData) { getDeveloperData() }
	runEvery10Minutes(refresh)
	logData << [refresh: "15 mins"]
	refresh()
	return logData
}

def rebootDevice() {
	logWarn("rebootDevice: Rebooting device per preference request")
	def result = syncPassthrough([method: "device_reboot"])
	logWarn("rebootDevice: ${result}")
}

def setPollInterval() {
	def method = "poll"
	if (getDataValue("capability") == "plug_em") {
		method = "emPoll"
	}
	if (pollInterval.contains("sec")) {
		def interval= pollInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", method)
		logWarn("setPollInterval: Polling intervals of less than one minute " +
				"can take high resources and may impact hub performance.")
	} else {
		def interval= pollInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", method)
	}
	return pollInterval
}

def setLoginInterval() {
	def startS = Math.round((59) * Math.random()).toInteger()
	def startM = Math.round((59) * Math.random()).toInteger()
	def startH = Math.round((11) * Math.random()).toInteger()
	schedule("${startS} ${startM} ${startH}/12 * * ?", "deviceLogin")
	return "12 hrs"
}

def syncName() {
	def logData = [syncName: nameSync]
	if (nameSync == "none") {
		logData << [status: "Label Not Updated"]
	} else {
		def cmdResp
		String nickname
		if (nameSync == "device") {
			cmdResp = syncPassthrough([method: "get_device_info"])
			nickname = cmdResp.result.nickname
		} else if (nameSync == "Hubitat") {
			nickname = device.getLabel().bytes.encodeBase64().toString()
			List requests = [[method: "set_device_info",params: [nickname: nickname]]]
			requests << [method: "get_device_info"]
			cmdResp = syncPassthrough(createMultiCmd(requests))
			cmdResp = cmdResp.result.responses.find { it.method == "get_device_info" }
			nickname = cmdResp.result.nickname
		}
		byte[] plainBytes = nickname.decodeBase64()
		String label = new String(plainBytes)
		device.setLabel(label)
		logData << [nickname: nickname, label: label, status: "Label Updated"]
	}
	device.updateSetting("nameSync",[type: "enum", value: "none"])
	return logData
}

def getDeveloperData() {
	device.updateSetting("developerData",[type:"bool", value: false])
	def attrs = listAttributes()
	Date date = new Date()
	Map devData = [
		currentTime: date.toString(),
		lastLogin: state.lastSuccessfulLogin,
		name: device.getName(),
		status: device.getStatus(),
		aesKey: aesKey,
		cookie: getDataValue("deviceCookie"),
		tokenLen: getDataValue("deviceToken"),
		dataValues: device.getData(),
		attributes: attrs,
		cmdResp: syncPassthrough([method: "get_device_info"]),
		childData: getChildDevData()
	]
	logWarn("DEVELOPER DATA: ${devData}")
}

def getChildDevData(){
	Map cmdBody = [
		method: "get_child_device_list"
	]
	def childData = syncPassthrough(cmdBody)
	if (childData.error_code == 0) {
		return childData.result.child_device_list
	} else {
		return "noChildren"
	}
}

def deviceLogin() {
	Map logData = [:]
	def handshakeData = handshake(getDataValue("deviceIP"))
	if (handshakeData.respStatus == "OK") {
		Map credentials = [encUsername: getDataValue("encUsername"), 
						   encPassword: getDataValue("encPassword")]
		def tokenData = loginDevice(handshakeData.cookie, handshakeData.aesKey, 
									credentials, getDataValue("deviceIP"))
		if (tokenData.respStatus == "OK") {
			logData << [rsaKeys: handshakeData.rsaKeys,
						cookie: handshakeData.cookie,
						aesKey: handshakeData.aesKey,
						token: tokenData.token]
			
			device.updateSetting("aesKey", [type:"password", value: handshakeData.aesKey])
			updateDataValue("deviceCookie", handshakeData.cookie)
			updateDataValue("deviceToken", tokenData.token)
			logData << [status: "OK"]
		} else {
			logData << [status: "ERROR.",tokenData: tokenData]
		}
	} else {
		logData << [status: "ERROR",handshakeData: handshakeData]
	}
	Map logStatus = [:]
	if (logData.status == "OK") {
		logInfo("deviceLogin: ${logData}")
		logStatus << [logStatus: "SUCCESS"]
	} else {
		logWarn("deviceLogin: ${logData}")
		logStatus << [logStatus: "FAILURE"]
	}
	return logStatus
}

def refresh() {
	logDebug("refresh")
	asyncPassthrough([method: "get_device_info"], "refresh", "deviceParse")
}

def poll() {
	logDebug("poll")
	asyncPassthrough([method: "get_device_running_info"], "poll", "pollParse")
}

def pollParse(resp, data=null) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		def devData = cmdResp.cmdResp.result
		def onOff = "off"
		if (devData.device_on == true) { onOff ="on" }
		updateAttr("switch", onOff)
	}
}

def emPoll() {
	logDebug("poll")
	List requests = [[method: "get_device_running_info"]]
	requests << [method: "get_energy_usage"]
	asyncPassthrough(createMultiCmd(requests), "emPoll", "emPollParse")
}

def emPollParse(resp, data=null) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		def devData = cmdResp.cmdResp.result.responses.find{it.method == "get_device_running_info"}.result
		def onOff = "off"
		if (devData.device_on == true) { onOff ="on" }
		updateAttr("switch", onOff)
		def emData = cmdResp.cmdResp.result.responses.find{it.method == "get_energy_usage"}
		if (emData.error_code == 0) {
			emData = emData.result
			updateAttr("power", emData.current_power)
		}
	}
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}
