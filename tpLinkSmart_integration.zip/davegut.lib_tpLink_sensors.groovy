library (
	name: "lib_tpLink_sensors",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Tapo Sensor Methods",
	category: "utilities",
	documentationLink: ""
)
capability "Refresh"
def version() { return parent.version() }
def label() { return device.displayName }

def refresh() {
	parent.refresh()
}

def getTriggerLog() {
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_trigger_logs",
				params: [page_size: 5,"start_id": 0]
			]
		]
	]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "distTriggerLog")
}

def getDeveloperData() {
	device.updateSetting("developerData",[type:"bool", value: false])
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	Date date = new Date()
	Map devData = [
		currentTime: date.toString(),
		name: device.getName(),
		status: device.getStatus(),
		dataValues: device.getData(),
		attributes: attrs,
		devInfo: getChildDeviceInfo(),
		compList: getDeviceComponents()
	]
	logWarn("DEVELOPER DATA: ${devData}")
}

def getDeviceComponents() {
	Map logData = [:]
	Map cmdBody = [
		device_id: getDataValue("deviceId"),
		method: "get_child_device_component_list"
	]
	def compList = parent.syncSend(cmdBody)
	if (compList == "ERROR") {
		logWarn("getDeviceComponents: [ERROR: Error in Sysn Comms]")
	}
	return compList
}

def getChildDeviceInfo() {
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: [method: "get_device_info"]]]
	return parent.syncSend(cmdBody)
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

/*	Future.
attribute "lowBattery", "string"
attribute "status", "string"
def deviceRefreshParse(childData, data=null) {
	try {
		def devData = childData.find {it.mac = device.getDeviceNetworkId()}
		updateAttr("lowBattery", devData.atLowBattery)
		updateAttr("status", status)
	} catch (error) {
	}
}
*/
