/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Updates from previous version.
a.	Added Klap protocol with associated auto-use logic.
b.	Streamlined comms error processing and synched process to app find device.
c.	Added driver for Multi-plug to set.
d.	Added additional preferences (as appropriate) to child devices (sensors, multi-plug outlets)
e.	Added battery state attribute to sensors.
f.	Added setLed capability to preferences for plugs/switches/hub.
=================================================================================================*/

metadata {
	definition (name: "tpLink_plug_em", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug_em.groovy")
	{
		capability "Switch"
		attribute "connected", "string"
		attribute "commsError", "string"
		capability "EnergyMeter"
		capability "PowerMeter"
		attribute "energyThisMonth", "number"
	}
	preferences {
		commonPreferences()
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["device", "always", "never", "night_mode"], defaultValue: "device")
		input ("autoOffEnable", "bool", title: "Enable Auto Off", defaultValue: false)
		input ("autoOffTime", "NUMBER", title: "Auto Off Time (minutes)", defaultValue: 120)
		input ("defState", "enum", title: "Power Loss Default State",
			   options: ["lastState", "on", "off"], defaultValue: "lastState")
		input ("powerProtect", "bool", title: "Enable Power Protection", defaultValue: false)
		input ("pwrProtectWatts", "NUMBER", title: "Power Protection Watts (Max 1660)", 
			   defaultValue: 1000)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [setAutoOff: setAutoOff()]
	logData << [setDefaultState: setDefaultState()]
	logData << [setPowerProtect: setPowerProtect()]
	logData << [setLedRule: setLedRule()]
	runEvery30Minutes(emUpdate)
	logData << [emUpdate: "30 Minutes"]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
}

def setPowerProtect() {
	Map logData = [:]
	if (pwrProtectWatts > 1660) {
		logWarn("setPowerProtect: entered watts exceed 1660.  Aborting Power Protect Setup.")
		device.updateSetting("pwrProtectWatts", [type: "number", value: 1000])
		logData << [FAILED: "Invalid User Entry"]
	} else {
		List requests = [[method: "set_protection_power",
						  params: [protection_power: pwrProtectWatts,
								   enabled: powerProtect]]]
		requests << [method: "get_protection_power"]
		def devData = syncSend(createMultiCmd(requests))
		def data = devData.result.responses.find { it.method == "get_protection_power" }.result
		device.updateSetting("pwrProtectWatts", [type: "number", value: data.protection_power])
		device.updateSetting("powerProtect", [type: "bool", value: data.enabled])
		logData << [powerProtect: data.enabled, pwrProtectWatts: data.protection_power]
	}
	return logData
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		def devicesData = respData.cmdResp
		Map devData = [:]
		Map emData = [:]
		if (devicesData.result.responses) {
			devData = devicesData.result.responses.find{it.method == "get_device_info"}
			emData = devicesData.result.responses.find{it.method == "get_energy_usage"}
		}
		logData << [devData: devData, emData: emData]
		if (devData != null && devData.error_code == 0) {
			devData = devData.result
			def onOff = "off"
			if (devData.device_on == true) { onOff = "on" }
			if (device.currentValue("switch") != onOff) {
				sendEvent(name: "switch", value: onOff, type: state.eventType)
				state.eventType = "physical"
			}
		}
		if (emData != null && emData.error_code == 0) {
			emData = emData.result
			def power = (emData.current_power/1000).toInteger()
			updateAttr("power", power.toString())
		}
	}
	logDebug(logData)
}

def emUpdate() {
	asyncSend([method:"get_energy_usage"], "refresh", "emUpdateParse")
}
def emUpdateParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "emUpdateParse"]
	if (respData.status == "OK") {
		def emData = respData.cmdResp
		if (emData.result.responses) {
			emData = emData.result.responses.find{it.method == "get_energy_usage"}
		}
		logData << [emData: emData]
		if (emData != null && emData.error_code == 0) {
			emData = emData.result
			def energy = emData.today_energy/1000
			updateAttr("energy", energy.toString())
			updateAttr("energyThisMonth", emData.month_energy.toString())
		}
	}
	logDebug(logData)
}

#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
