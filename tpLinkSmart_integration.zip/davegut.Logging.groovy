library (
	name: "Logging",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Logging and info gathering Methods",
	category: "utilities",
	documentationLink: ""
)

preferences {
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	input ("traceLog", "bool", title: "Enable trace logging as directed by developer", defaultValue: false)
}

def listAttributes() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	return attrs
}

def setLogsOff() {
	def logData = [logEnagle: logEnable, infoLog: infoLog, traceLog:traceLog]
	if (logEnable) {
		runIn(1800, debugLogOff)
		logData << [debugLogOff: "scheduled"]
	}
	if (traceLog) {
		runIn(1800, traceLogOff)
		logData << [traceLogOff: "scheduled"]
	}
	return logData
}

def logTrace(msg){
	if (traceLog == true) {
		log.trace "${device.displayName}-${driverVer()}: ${msg}"
	}
}

def traceLogOff() {
	device.updateSetting("traceLog", [type:"bool", value: false])
	logInfo("traceLogOff")
}

def logInfo(msg) { 
	if (textEnable || infoLog) {
		log.info "${device.displayName}-${driverVer()}: ${msg}"
	}
}

def debugLogOff() {
	device.updateSetting("logEnable", [type:"bool", value: false])
	logInfo("debugLogOff")
}

def logDebug(msg) {
	if (logEnable || debugLog) {
		log.debug "${device.displayName}-${driverVer()}: ${msg}"
	}
}

def logWarn(msg) { log.warn "${device.displayName}-${driverVer()}: ${msg}" }

def logError(msg) { log.error "${device.displayName}-${driverVer()}: ${msg}" }
