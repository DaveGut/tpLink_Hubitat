library (
	name: "Logging",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Logging and info gathering Methods",
	category: "utilities",
	documentationLink: ""
)

def listAttributes() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	return attrs
}

def setLogsOff() {
	def logData = [logEnable: logEnable]
	if (logEnable) {
		runIn(1800, debugLogOff)
		logData << [debugLogOff: "scheduled"]
	}
	return logData
}

def logTrace(msg){
	log.trace "${label()}-${version()}: ${msg}"
}

def logInfo(msg) { 
	if (textEnable || infoLog) {
		log.info "${label()}-${version()}: ${msg}"
	}
}

def debugLogOff() {
	device.updateSetting("logEnable", [type:"bool", value: false])
	logInfo("debugLogOff")
}

def logDebug(msg) {
	if (logEnable || debugLog) {
		log.debug "${label()}-${version()}: ${msg}"
	}
}

def logWarn(msg) {
	log.warn "${label()}-${version()}: ${msg}"
}

def logError(msg) {
	log.error "${label()}-${version()}: ${msg}"
}
