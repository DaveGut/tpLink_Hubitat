/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Updates from previous version.
a.	Added Klap protocol with associated auto-use logic.
b.	Streamlined comms error processing and synched process to app find device.
c.	Added driver for Multi-plug to set.
d.	Added additional preferences (as appropriate) to child devices (sensors, multi-plug outlets)
e.	Added battery state attribute to sensors.
=================================================================================================*/
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def type() { return "tpLink_plug_dimmer" }

metadata {
	definition (name: "tpLink_plug_dimmer", namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Switch"
		capability "Switch Level"
		capability "Change Level"
		attribute "connected", "string"
		attribute "commsError", "string"
	}
	preferences {
		commonPreferences()
		input ("autoOffEnable", "bool", title: "Enable Auto Off", defaultValue: false)
		input ("autoOffTime", "NUMBER", title: "Auto Off Time (minutes)", defaultValue: 120)
		input ("defState", "enum", title: "Power Loss Default State",
			   options: ["lastState", "on", "off"], defaultValue: "lastState")
		input ("gradualOnOff", "bool", title: "Set Gradual ON/OFF", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [setGradualOnOff: setGradualOnOff()]
	logData << [setAutoOff: setAutoOff()]
	logData << [setDefaultState: setDefaultState()]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		def devData = respData.cmdResp
		if (devData.result.responses) {
			devData = devData.result.responses.find{it.method == "get_device_info"}
		}
		logData << [devData: devData]
		if (devData != null && devData.error_code == 0) {
			devData = devData.result
			def onOff = "off"
			if (devData.device_on == true) { onOff = "on" }
			if (device.currentValue("switch") != onOff) {
				sendEvent(name: "switch", value: onOff, type: state.eventType)
				state.eventType = "physical"
			}
			updateAttr("level", devData.brightness)
		}
	}
	logDebug(logData)
}

//	Library Inclusion
#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
