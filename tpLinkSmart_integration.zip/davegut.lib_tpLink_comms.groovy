library (
	name: "lib_tpLink_comms",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Tapo Communications",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def syncSend(cmdBody) {
	Map cmdResp = [:]
	if (getDataValue("protocol") == "KLAP") {
		cmdResp = klapSyncSend(cmdBody)
	} else {
		cmdResp = aesSyncSend(cmdBody)
	}
	return cmdResp
}

def klapSyncSend(cmdBody) {
	Map logData = [method: "klapSyncSend", cmdBody: cmdBody]
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	byte[] encSig = new JsonSlurper().parseText(encSig)
	String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()
	Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv, encSig)
	def uri = "${getDataValue("baseUrl")}/request?seq=${encryptedData.seqNumber}"
	def resp = klapSyncPost(uri, encryptedData.cipherData, cookie)
	Map cmdResp = [status: "ERROR"]
	if (resp.status == 200) {
		try {
			byte[] cipherResponse = resp.data[32..-1]
			def clearResp =  klapDecrypt(cipherResponse, encKey, encIv)
			cmdResp = new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [status: "cryptoError", error: "Error decrypting response", data: err]
		}
	} else {
		logData << [status: "postJsonError", postJsonData: resp]
	}
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def aesSyncSend(cmdBody) {
	Map logData = [method: "aesSyncSend", cmdBody: cmdBody]
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	def uri = "${getDataValue("baseUrl")}?token=${token}"
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
	def resp = aesSyncPost(uri, reqBody, cookie)
	Map cmdResp = [status: "ERROR"]
	if (resp.status == 200) {
		try {
			def clearResp = aesDecrypt(resp.data.result.response, encKey, encIv)
			cmdResp = new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [status: "cryptoError", error: "Error decrypting response", data: err]
		}
	} else {
		logData << [status: "postJsonError", postJsonData: resp]
	}
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def asyncSend(cmdBody, method, action) {
	Map cmdData = [cmdBody: cmdBody, method: method, action: action]
	state.lastCmd = cmdData
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	if (getDataValue("protocol") == "KLAP") {
		byte[] encSig = new JsonSlurper().parseText(encSig)
		String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv, encSig)
		def uri = "${getDataValue("baseUrl")}/request?seq=${encryptedData.seqNumber}"
		asyncPost(uri, encryptedData.cipherData, "application/octet-stream",
					  action, cookie, method)
	} else {
		def uri = "${getDataValue("baseUrl")}?token=${token}"
		def cmdStr = JsonOutput.toJson(cmdBody).toString()
		Map reqBody = [method: "securePassthrough",
					   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
		def body = new groovy.json.JsonBuilder(reqBody).toString()
		asyncPost(uri, body, "application/json", 
					  action, cookie, method)
	}
}

//	===== HTTP POST Methods =====
def klapSyncPost(uri, byte[] body, cookie = null) {
	def reqParams = [
		uri: uri,
		body: body,
		contentType: "application/octet-stream",
		requestContentType: "application/octet-stream",
		headers: [
			"Cookie": cookie,
		],
		timeout: 4
	]
	Map respData = [method: "klapSyncPost", uri: uri, cookie: cookie]
	try {
		httpPost(reqParams) { resp ->
			respData << [status: resp.status]
			if (resp.status == 200) {
				byte[] data = []
				if (resp.data != null) {
					data = parseInputStream(resp.data)
				}
				respData << [data: data, headers: resp.headers]
			} else {
				respData << [properties: resp.properties]
			}
		}
	} catch (err) {
		respData << [status: "HTTP Failed", data: err]
	}
	return respData
}
def parseInputStream(data) {
	def dataSize = data.available()
	byte[] dataArr = new byte[dataSize]
	data.read(dataArr, 0, dataSize)
	return dataArr
}

def aesSyncPost(uri, reqBody, cookie=null) {
	def reqParams = [
		uri: uri,
		headers: [
			Cookie: cookie,
		],
		body : new JsonBuilder(reqBody).toString(),
		timeout: 4
	]
	Map respData = [method: "aesSyncPost", uri: uri, cookie: cookie]
	try {
		httpPostJson(reqParams) {resp ->
			respData << [status: resp.status]
			if (resp.status == 200 && resp.data.error_code == 0) {
				respData << [data: resp.data, headers: resp.headers]
			} else {
				respData << [properties: resp.properties]
			}
		}
	} catch (err) {
		respData << [status: "HTTP Failed", data: err]
	}
	return respData
}

def asyncPost(uri, body, contentType, parseMethod, cookie=null, reqData=null) {
	def reqParams = [
		uri: uri,
		body: body,
		contentType: contentType,
		requestContentType: contentType,
		headers: [
			"Cookie": cookie,
		],
		timeout: 4
	]
	Map logData = [method: "asyncPost", uri: uri, 
				   parseMethod: parseMethod, cookie: cookie, reqData: reqData]
	try {
		asynchttpPost(parseMethod, reqParams, [data: reqData])
		logData << [status: "OK"]
		logDebug(logData)
	} catch (err) {
		logData << [status: "FAILED", error: err, ]
		logWarn(logData)
	}
}
def parseData(resp) {
	def logData = [method: "parseData"]
	if (resp.status == 200) {
		try {
			Map cmdResp
			byte[] encKey = new JsonSlurper().parseText(encKey)
			byte[] encIv = new JsonSlurper().parseText(encIv)
			if (getDataValue("protocol") == "KLAP") {
				byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
				cmdResp =  new JsonSlurper().parseText(klapDecrypt(cipherResponse, encKey, encIv))
			} else {
				cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response, encKey, encIv))
			}
			logData << [status: "OK", cmdResp: cmdResp]
			if (device.currentValue("commsError") == "true") {
				logData << [resetError: setCommsError(false)]
			}
			state.errorCount = 0
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			runIn(1, handleCommsError, [data: "deviceDataParseError"])
		}
	} else {
		logData << [status: "httpFailure(timeout)", data: resp.properties]
		runIn(1, handleCommsError, [data: "httpFailure(timeout)"])
	}
	logDebug(logData)
	return logData
}

//	===== Error Handling =====
def handleCommsError(retryReason) {
	Map logData = [method: "handleCommsError", retryReason: retryReason]
	if (state.lastCommand != "") {
		def count = state.errorCount + 1
		state.errorCount = count
		def cmdData = new JSONObject(state.lastCmd)
		def cmdBody = parseJson(cmdData.cmdBody.toString())
		Map data = [cmdBody: cmdBody, method: cmdData.method, action:cmdData.action]
		logData << [count: count, command: cmdData]
		switch (count) {
			case 1:
				setPollInterval("5 min")
				runIn(1, delayedPassThrough, [data: data])
				logData << [action: "retryCommand"]
				break
			case 2:
				pauseExecution(5000)
				Map loginData = deviceLogin()
				logData << [loginStatus: loginData.loginStatus]
				if (loginData.loginStatus == "OK") {
					logData << [action: "retryCommand"]
					runIn(2, delayedPassThrough, [data:data])
				} else {
					logData << parent.checkDevices()
					logData << [action: "retryCommand"]
					runIn(15, delayedPassThrough, [data:data])
				}
				break
			case 3:
				logData << [loginStatus: setCommsError(true)]
				logWarn(logData)
				break

			default:
				logData << [status: "retriesDisabled"]
				break
		}
	} else {
		logData << [status: "noCommandToRetry"]
	}
	logDebug(logData)
}

def delayedPassThrough(data) {
	asyncSend(data.cmdBody, data.method, data.action)
}

def setCommsError(status, errorData = null) {
	Map logData = [method: "setCommsError", status: status]
	if (status == false) {
		updateAttr("commsError", "false")
		runIn(5, setPollInterval)
		logData << [commsError: false, pollInterval: pollInterval]
	} else {
		logData << [errorData: errorData]
		logData << [pollInterval: "Temporarily set to 5 minutes"]
		updateAttr("commsError", "true")
		logData << [commsError: true]
	}
	return logData
}
