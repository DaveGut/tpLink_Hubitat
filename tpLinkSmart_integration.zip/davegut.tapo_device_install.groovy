/*	tpLinkSmart Device Installation Application
	Copyright Dave Gutheinz
===================================================================================================*/
def appName() { return "tapo_device_install" }
def appVersion() { return "1.1" }
def nameSpace() { return "davegut" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/App/" }
import groovy.json.JsonSlurper
import java.security.MessageDigest

definition(
	name: "tapo_device_install",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Application to install TP-Link Tapo bulbs, plugs, and switches.",
	category: "Convenience",
	iconUrl: "",
	iconX2Url: "",
	installOnOpen: true,
	singleInstance: true,
	documentationLink: "https://github.com/DaveGut/tapoHubitat/blob/main/README.md",
	importUrl: "https://raw.githubusercontent.com/${gitPath()}${appName()}.groovy"
)

preferences {
	page(name: "startPage")
	page(name: "enterCredentialsPage")
	page(name: "processCredentials")
	page(name: "addDevicesPage")
	page(name: "removeDevicesPage")
	page(name: "listDevicesPage")
}

def installed() { }

def updated() {
	unschedule()
	runEvery15Minutes(updateIps)
	app?.removeSetting("selectedAddDevices")
	app?.removeSetting("selectedRemoveDevices")
}

def uninstalled() {
    getAllChildDevices().each { 
        deleteChildDevice(it.deviceNetworkId)
    }
}

def initInstance() {
	logDebug("initInstance: Getting external data for the app.")
	if (!debugLog) { app.updateSetting("debugLog", false) }
	if (!state.devices) { state.devices = [:] }
	state.findingDevices = "ready"
	unschedule()
	if (!state.encCreds) { state.encCreds = [encUsername: "notSet", encPassword: "notSet"] }
	if (!lanSegment) {
		def hub = location.hub
		def hubIpArray = hub.localIP.split('\\.')
		def segments = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
		app?.updateSetting("lanSegment", [type:"string", value: segments])
	}
	if (!hostLimits) {
		app?.updateSetting("hostLimits", [type:"string", value: "2, 254"])
	}
	return
}

def startPage() {
	logInfo("starting Tapo Setup and Installation")
	def action = initInstance()
	if (selectedRemoveDevices) { removeDevices() }
	if (selectedAddDevices) { addDevices() }
	if (devSort) { listDevices() }
	if (debugLog) { runIn(1800, debugOff) }
	try {
		state.segArray = lanSegment.split('\\,')
		def rangeArray = hostLimits.split('\\,')
		def array0 = rangeArray[0].toInteger()
		def array1 = array0 + 2
		if (rangeArray.size() > 1) {
			array1 = rangeArray[1].toInteger()
		}
		state.hostArray = [array0, array1]
	} catch (e) {
		logInfo("startPage: Invalid entry for Lan Segements, or Host Array Range. Resetting to default!")
		def hub = location.hubs[0]
		def hubIpArray = hub.localIP.split('\\.')
		def segments = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
		app?.updateSetting("lanSegment", [type:"string", value: segments])
		app?.updateSetting("hostLimits", [type:"string", value: "1, 254"])
	}

	return dynamicPage(name:"startPage",
					   title:"<b>Tapo Device Installation</b>",
					   uninstall: true,
					   install: true) {
		section() {
			def twoFactor = "<b>The installations function may not work if " +
				"two-factor authentication is enabled in the Tapo phone app.</b>"
			paragraph twoFactor
			def lanConfig = "[lanSegments: ${lanSegment}, hostRange: ${hostLimits}]"
			paragraph "<b>Current LAN Configuration: ${lanConfig}</b>"
			input "appSetup", "bool",
				title: "<b>Modify LAN Configuration</b>",
				description: "Used for setting non-standard IP segemet search",
				submitOnChange: true,
				defaultalue: false
			if (appSetup) {
				input "lanSegment", "string",
					title: "<b>Lan Segments</b> (ex: 192.168.50, 192,168.01)",
					submitOnChange: true
				input "hostLimits", "string",
					title: "<b>Host Address Range</b> (ex: 5, 100)",
					submitOnChange: true
			}
			
			if (!encUsername || !encPassword) {
				paragraph "<b>Credentials require attention</b>"
			}
			href "enterCredentialsPage",
				title: "<b>Enter/Update tpLink Credentials</b>",
				description: "Credentials are used by app and each Tapo devices during periodic login."
			
			if (encUsername && encPassword) {
				href "addDevicesPage",
					title: "<b>Add Tapo Devices</b>",
					description: "Searches LAN for devices and offers new devices for Hubitat installation.  Take 30 seconds to pop to next page."

				href "removeDevicesPage",
					title: "<b>Remove Tapo Devices</b>",
					description: "Provides interface to remove installed devices from Hubitat."
			}
			paragraph " "
			input "debugLog", "bool",
				   title: "<b>Enable debug logging for 30 minutes</b>",
				   submitOnChange: true,
				   defaultValue: false
		}
	}
}

//	===== Enter Credentials =====
def enterCredentialsPage() {
	logInfo("enterCredentialsPage")
	return dynamicPage (name: "enterCredentialsPage", 
    					title: "Enter TP-Link (Tapo) Credentials",
						nextPage: startPage,
                        install: false) {
		section() {
			paragraph "Current Encoded Credentials: ${state.encCreds} \n\r"
			input ("userName", "email",
            		title: "TP-Link Tapo Email Address", 
                    required: false,
                    submitOnChange: true)
			input ("userPassword", "password",
            		title: "TP-Link Tapo Account Password",
                    required: false,
                    submitOnChange: true)
			if (userName && userPassword && userName != null && userPassword != null) {
				logDebug("enterCredentialsPage: [username: ${userName}, pwdLen: ${userPassword.length()}]")
				href "processCredentials", title: "Create Encoded Credentials",
					description: "You may have to press this twice."
			}
		}
	}
}

private processCredentials() {
	Map logData = [:]
	String encUsername = mdEncode(userName).bytes.encodeBase64().toString()
	app?.updateSetting("encUsername", [type: "password", value: encUsername])
	Map credentials = [encUsername: encUsername]
	String encPassword = userPassword.bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "password", value: encPassword])
	credentials << [encPassword: encPassword]
	logData << [creds: credentials]
	if (encUsername != state.encCreds.encUsername ||
		encPassword != state.encCreds.encPassword) {
		runIn(2, updateDeviceData)
		logData << [status: "NewCredentials", action: "updatingChildCredentials"]
	} else {
		logData << [status: "NoCredentialChanges"]
	}
	state.encCreds = credentials
	logInfo("processCredentials: ${logData}")
	return startPage()
}

private String mdEncode(String message) {
	MessageDigest md = MessageDigest.getInstance("SHA-1")
	md.update(message.getBytes())
	byte[] digest = md.digest()
	return digest.encodeHex()
}

//	===== Add Devices =====
def addDevicesPage() {
	Map logData = [:]
	Map uninstalledDevices = [:]
	Map requiredDrivers = [:]
	List installedDevices = []
	def notes = ""
	def addTitle = "<b>Currently Finding Devices</b>.  This can take several minutes."
	if (state.findingDevices == "ready") {
		state.devices = [:]
		logInfo("addDevicesPage: <b>FINDING DEVICES</b>.  ${findDevices("getSmartLanData", 10)}")
	} else if (state.findingDevices == "looking") {
		logInfo("addDevicesPage: <b>WORKING</b>.  Next update in 30 seconds.")
	} else {
		def devices = state.devices
		devices.each { device ->
			def isChild = getChildDevice(device.key)
			if (!isChild) {
				uninstalledDevices["${device.key}"] = "${device.value.alias}, ${device.value.driver}"
				requiredDrivers["${device.value.driver}"] = "${device.value.driver}"
			} else {
				installedDevices << isChild
			}
		}
		logData << [installedDevices: installedDevices]
		uninstalledDevices.sort()
		logData << [uninstalledDevices: uninstalledDevices]
		def reqDrivers = []
		requiredDrivers.each {
			reqDrivers << it.key
		}
		logData << [requiredDrivers: reqDrivers]
		addTitle = "<b>Device Discovery Complete</b>.  Devices available to add "
		addTitle += "${uninstalledDevices.size() ?: 0}.  "
		addTitle += "Total devices: ${devices.size()}.  "
		runIn(35, updateDeviceData)
		logInfo("addDevicesPage: <b>WAITING ON YOU</b>.  ${logData}")
		notes = "\t<b>InstalledDevices</b>: ${installedDevices}"
		if (state.findingDevices == "failed") {
			logWarn("addDevicesPage: <b>Discovery did not end properly</b>.  Check Lan Segments validity and your LAN configuration.")
			notes += "\n\t<b>Discovery did not end properly</b>.  Check LAN and LAN Segments"
		}
	}
	return dynamicPage(name:"addDevicesPage",
					   title: "Add Tapo Devices to Hubitat",
					   refreshInterval: 30,
					   nextPage: startPage,
					   install: false) {
	 	section() {
			input ("selectedAddDevices", "enum",
				   required: false,
				   multiple: true,
				   title: addTitle,
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: uninstalledDevices)
			paragraph "<b>Notes</b>: \n${notes}"
		}
	}
}

def findDevices(action, timeOut) {
	state.findingDevices = "looking"
	def logData = [action: action, timeOut: timeOut]
	def start = state.hostArray.min().toInteger()
	def finish = state.hostArray.max().toInteger() + 1
	logData << [hostArray: state.hostArray, pollSegment: state.segArray]
	List deviceIPs = []
	state.segArray.each {
		def pollSegment = it.trim()
		logDebug("findDevices: Searching for TP-Link SMART LAN deivces on IP Segment = ${pollSegment}")
		for(int i = start; i < finish; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
		sendLanCmd(deviceIPs.join(','), "20002", cmdData, action, timeOut)
	}
	runIn(120, forceEnd)
	return logData
}

def forceEnd() {
	if (state.findingDevices != "done") {
		state.findingDevices = "failed"
	}
}

private sendLanCmd(ip, port, cmdData, action, commsTo = 5) {
	Map data = [port: port, action: action]
	logInfo("sendLanCmd: ${data}")
	def myHubAction = new hubitat.device.HubAction(
		cmdData,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "${ip}:${port}",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 parseWarning: true,
		 timeout: commsTo,
		 callback: action])
	try {
		sendHubCommand(myHubAction)
	} catch (error) {
		logWarn("sendLanCmd: command failed. Error = ${error}")
	}
}

//	App interface to Lib code
def parseSmartDeviceData(devData) {
	def dni = devData.mac.replaceAll("-", "")
	Map deviceData = [dni: dni]
	String deviceType = devData.type
	byte[] plainBytes = devData.nickname.decodeBase64()
	String alias = new String(plainBytes)
	deviceData << [alias: alias]
	deviceData << [model: devData.model]
	deviceData << [ip: devData.ip]
	deviceData << [deviceId: devData.device_id]

	String capability = "newType"
	String feature
	if (deviceType == "SMART.TAPOBULB") {
		capability = "bulb_dimmer"
		if (devData.color_temp_range) {
			deviceData << [ctLow: devData.color_temp_range[0]]
			deviceData << [ctHigh: devData.color_temp_range[1]]
			if (devData.color_temp_range[0] < devData.color_temp_range[1]) {
				capability = "bulb_color"
			} else if (devData.lighting_effect) {
				capability = "bulb_lightStrip"
			}
		}
	} else if (deviceType == "SMART.TAPOSWITCH" || deviceType == "SMART.TAPOPLUG") {
		capability = "plug"
		if (devData.brightness) {
			capability = "plug_dimmer"
		}
		if (devData.power_protection_status) {
			capability = "plug_em"
		}
	} else if (deviceType == "SMART.TAPOHUB") {
		capability = "hub"
	}
	String driver = "tpLink_${capability}"
	deviceData << [driver: driver]
	deviceData << [capability: capability]

	state.devices << ["${dni}": deviceData]
	logDebug("parseDeviceData: [${dni}: ${deviceData}]")
}

def updateDeviceData() {
	def logData = [:]
	if (state.devices != [:]) {
		Map devices = state.devices
		devices.each {
			def child = getChildDevice(it.key)
			if (child) {
				Map childData = [:]
				def deviceIp = child.getDataValue("deviceIp")
				def devEncUsername = child.getDataValue("encUsername")
				def devEncPassword = child.getDataValue("encPassword")
				if (deviceIp == it.value.ip &&
					devEncPassword == encPassword &&
					devEncUsername == encUsername) {
					childData << [Status: "No Changes"]
				} else {
					child.updateDataValue("deviceIp", it.value.ip)
					child.updateDataValue("encPassword", encPassword)
					child.updateDataValue("encUsername", encUsername)
					childData << [status: "Updated", LOGIN: child.deviceLogin()]
				}
				logData << [child: childData]
			} else {
				logData << ["${it.key}": "notChild"]
			}
		}
	} else {
		logData << [status: "noChanges", data: "state.devices is null"]
	}
	logInfo("updateDeviceData: ${logData}")
	return logData
}

//	===== Add wifi devices to Hubitat =====
def addDevices() {
	Map addedDevices = [:]
	Map failedAdds = [:]
	def devices = state.devices
	selectedAddDevices.each { dni ->
		def isChild = getChildDevice(dni)
		if (!isChild) {
			def device = devices.find { it.value.dni == dni }
			def alias = device.value.alias.replaceAll("[\u201C\u201D]", "\"").replaceAll("[\u2018\u2019]", "'").replaceAll("[^\\p{ASCII}]", "")
			Map deviceData = [deviceIP: device.value.ip]
			deviceData << [deviceId: device.value.deviceId]
			deviceData << [encUsername: encUsername]
			deviceData << [encPassword: encPassword]
			deviceData << [capability: device.value.capability]
			if (device.value.ctLow) {
				deviceData << [ctLow: device.value.ctLow]
				deviceData << [ctHigh: device.value.ctHigh]
			}
			try {
				addChildDevice(
					nameSpace(),
					device.value.driver,
					device.key,
					[
						"label": alias,
						"name" : device.value.model,
						"data" : deviceData
					]
				)
				addedDevices << ["${device.key}": [label: alias, ip: device.value.ip]]
			} catch (error) {
				log.debug error
				status = "ERROR"
				failedAdds << ["${device.key}": [label: alias, driver: device.value.driver]]
			}
		}
		pauseExecution(3000)
	}
	logInfo("addDevices: [installed: ${addedDevices}]")
	if (failedAdds != [:]) {
		logWarn("addDevices: [failedToAdd: <b>${failedAdds}</b>]")
	}
	app?.removeSetting("selectedAddDevices")
}

//	===== Remove Devices =====
def removeDevicesPage() {
	logInfo("removeDevicesPage")
	def devices = state.devices
	def installedDevices = [:]
	devices.each {
		def installed = false
		def isChild = getChildDevice(it.key)
		if (isChild) {
			installedDevices["${it.key}"] = "${it.value.alias}, driver = ${it.value.driver}"
		}
	}
	logDebug("removeDevicesPage: installedDevices = ${installedDevices}")
	return dynamicPage(name:"removedDevicesPage",
					   title:"<b>Remove Tapo Devices from Hubitat</b>",
					   nextPage: startPage,
					   install: false) {
		section("Select Devices to Remove from Hubitat") {
			input ("selectedRemoveDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "Devices to remove (${installedDevices.size() ?: 0} available)",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: installedDevices)
		}
	}
}

def removeDevices() {
	Map logData = [devicesToRemove: selectedRemoveDevices]
	def devices = state.devices
	selectedRemoveDevices.each { dni ->
		def device = state.devices.find { it.key == dni }
		def isChild = getChildDevice(dni)
		if (isChild) {
			try {
				deleteChildDevice(dni)
				logData << ["${dni}": [status: "ok", alias: device.value.alias]]
			} catch (error) {
				logData << ["${dni}": [status: "FAILED", alias: device.value.alias, error: error]]
			}
		}
	}
	if (logData.toString().contains("FAILED")) {
		logWarn("removeDevices: ${logData}")
	} else {
		logInfo("removeDevices: ${logData}")
	}
}

//	===== Methods to check and update Children IPs =====
def updateIps() {
	Map logData = [action: "checking and updating IP Addresses"]
	logData << [findDevices: findDevices("distSmartFindResp", 5)]
	logDebug("updateIp: ${logData}")
	return logData
}

def distSmartFindResp(response) {
	Map logData = [:]
	Map ipList = [:]
	def brand = "KASA"
	if (appName() == "tapo_device_install") { brand = "TAPO" }
	if (response instanceof Map) {
		def resp = parseLanMessage(response.description)
		if (resp.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(resp.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			Map payload = new JsonSlurper().parseText(payloadString).result
			if (payloadData.device_type.contains(brand)) {
				def dni = payloadData.mac.replaceAll("-", "")
				def devIp = payloadData.ip
				ipList << ["${dni}": devIp]
			}
		}
	} else {
		response.each {
			def resp = parseLanMessage(it.description)
			if (resp.type == "LAN_TYPE_UDPCLIENT") {
				byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(resp.payload.drop(32)) 
				String payloadString = new String(payloadByte)
				Map payload = new JsonSlurper().parseText(payloadString).result
				if (payload.device_type.contains(brand)) {
					def dni = payload.mac.replaceAll("-", "")
					def devIp = payload.ip
					ipList << ["${dni}": devIp]
				}
			}
		}
	}
	ipList.each {
		def child = getChildDevice(it.key)
		if (child) {
			if (child.getDataValue("deviceIP") == it.value) {
				logData << ["${child}_IP": "noChange"]
			} else {
				child.updateDataValue("deviceIP", it.value)
				logData << ["${child}_IP": it.value]
			}
		} else {
			logData << ["${it.key}": "notChild"]
		}
	}
	logDebug("distSmartFindResp: ${logData}")
}

//	===== Logging Methods =====
def debugOff() { app.updateSetting("debugLog", false) }
def logTrace(msg) { log.trace "TapoInst-${appVersion()}: ${msg}" }
def logDebug(msg){
	if(debugLog == true) { log.debug "TapoInst-${appVersion()}: ${msg}" }
}
def logInfo(msg) { log.info "TapoInst-${appVersion()}: ${msg}" }
def logWarn(msg) { log.warn "TapoInst-${appVersion()}: ${msg}" }
def logError(msg) { log.error "TapoInst-${appVersion()}: ${msg}" }

#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.lib_tpLink_discovery
