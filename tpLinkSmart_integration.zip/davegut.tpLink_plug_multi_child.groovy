/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Updates from previous version.
a.	Added Klap protocol with associated auto-use logic.
b.	Streamlined comms error processing and synched process to app find device.
c.	Added driver for Multi-plug to set.
d.	Added additional preferences (as appropriate) to child devices (sensors, multi-plug outlets)
e.	Added battery state attribute to sensors.
=================================================================================================*/
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def type() { return "tpLink_plug_multi_child" }

metadata {
	definition (name: "tpLink_plug_multi_child", namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Switch"
	}
	preferences {
		input ("nameSync", "enum", title: "Synchronize Names",
			   options: ["none": "Don't synchronize",
						 "device" : "TP-Link device name master",
						 "Hubitat" : "Hubitat label master"],
			   defaultValue: "none")
		input ("defState", "enum", title: "Power Loss Default State",
			   options: ["lastState", "on", "off"], defaultValue: "lastState")
		input ("developerData", "bool", title: "Get Data for Developer", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { runIn(5, updated) }

def updated() {
	unschedule()
	Map logData = [method: "updated"]
	logData << [syncName: syncName()]
	logData << [setDefaultState: setDefaultState()]
	if (developerData) { getDeveloperData() }
	refresh()
	logInfo(logData)
}

def on() { setPower(true) }

def off() { setPower(false) }

def setPower(onOff) {
	Map logData = [method: "setPower", onOff: onOff]
	state.eventType = "digital"
	List requests = [[method: "set_device_info", params: [device_on: onOff]]]
	requests << [method: "get_device_info"]
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: createMultiCmd(requests)]]
	try {
		def cmdResp = parent.syncSend(cmdBody)
		logData << [status: parseDevData(getDeviceInfoData(cmdResp).result)]
	} catch (err) {
		logData << [status: "ERROR", error: err]
	}
	logDebug(logData)
}

def parseDevData(devData) {
	Map logData = [method: "parseDevData"]
	try {
		def onOff = "off"
		if (devData.device_on == true) { onOff = "on" }
		if (device.currentValue("switch") != onOff) {
			sendEvent(name: "switch", value: onOff, type: state.eventType)
			state.eventType = "physical"
		}
		logData << [onOff: onOff, status: "OK"]
	} catch (err) {
		logData << [status: "FAILED", error: err]
	}
	return logData
}

#include davegut.lib_tpLink_child_common
#include davegut.Logging
