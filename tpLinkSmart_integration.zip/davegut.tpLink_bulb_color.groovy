/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
def type() { return "tpLink_bulb_color" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }

metadata {
	definition (name: "tpLink_bulb_color", namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Light"
		attribute "commsError", "string"
	}
	preferences {
		commonPreferences()
		dimmerPreferences()
		securityPreferences()
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [setGradualOnOff: setGradualOnOff()]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
}

def deviceParse(resp, data=null) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		def devData = cmdResp.cmdResp
		if (devData.result.responses) {
			devData = devData.result.responses.find{it.method == "get_device_info"}
		} 
		if (devData != null && devData.error_code == 0) {
			devData = devData.result
			logDebug("deviceParse: ${devData}")
			def onOff = "off"
			if (devData.device_on == true) { onOff = "on" }
			updateAttr("switch", onOff)
			updateAttr("level", devData.brightness)
			if (devData.color_temp == 0) {
				updateAttr("colorMode", "COLOR")
				def hubHue = (devData.hue / 3.6).toInteger()
				updateAttr("hue", hubHue)
				updateAttr("saturation", devData.saturation)
				updateAttr("color", "[hue: ${hubHue}, saturation: ${devData.saturation}]")
				updateAttr("colorName", colorName = convertHueToGenericColorName(hubHue))
				def rgb = hubitat.helper.ColorUtils.hsvToRGB([hubHue,
															  devData.saturation,
															  devData.brightness])
				updateAttr("RGB", rgb)
				updateAttr("colorTemperature", 0)
			} else {
				updateAttr("colorMode", "CT")
				updateAttr("colorTemperature", devData.color_temp)
				updateAttr("colorName", convertTemperatureToGenericColorName(devData.color_temp.toInteger()))
				updateAttr("color", "[:]")
				updateAttr("RGB", "[]")
			}
		} else {
			logWarn("deviceParse: [status: FAILED, error: error in devData, cmdResp: ${cmdResp}]")
		}
	}
}

//	Library Inclusion
#include davegut.lib_tpLink_CapColor
#include davegut.lib_tpLink_CapDimmer
#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
