/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
def type() { return "tpLink_bulb_dimmer" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }

metadata {
	definition (name: "tpLink_bulb_dimmer", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Light"
		attribute "commsError", "bool"
	}
	preferences {
		commonPreferences()
		dimmerPreferences()
		securityPreferences()
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	def logData = [:]
	logData << [setGradualOnOff: setGradualOnOff()]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
}

def deviceParse(resp, data=null) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		def devData = cmdResp.cmdResp.result
		if (devData.responses) {
			devData = devData.responses.find{it.method == "get_device_info"}.result
		}
		logDebug("deviceParse: ${devData}")
		def onOff = "off"
		if (devData.device_on == true) { onOff = "on" }
		updateAttr("switch", onOff)
		updateAttr("level", devData.brightness)
	}
}

//	Library Inclusion
#include davegut.lib_tpLink_CapDimmer
#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
