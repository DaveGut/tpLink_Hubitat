/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Updates from previous version.
a.	Added Klap protocol with associated auto-use logic.
b.	Streamlined comms error processing and synched process to app find device.
c.	Added driver for Multi-plug to set.
d.	Added additional preferences (as appropriate) to child devices (sensors, multi-plug outlets)
e.	Added battery state attribute to sensors.
f.	Added setLed capability to preferences for plugs/switches/hub.
=================================================================================================*/

metadata {
	definition (name: "tpLink_hub_button", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_button.groovy")
	{
		capability "Sensor"
		attribute "lastTrigger", "string"
		attribute "lastTriggerNo", "number"
		attribute "triggerTimestamp", "number"
		attribute "lowBattery", "string"
	}
	preferences {
		input ("nameSync", "enum", title: "Synchronize Names",
			   options: ["none": "Don't synchronize",
						 "device" : "TP-Link device name master",
						 "Hubitat" : "Hubitat label master"],
			   defaultValue: "none")
		input ("developerData", "bool", title: "Get Data for Developer", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << setLogsOff()
	if (developerData) { getDeveloperData() }
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	childData = childData.find{ it.mac == device.getDeviceNetworkId() }
	if (device.currentValue("lowBattery") != childData.atLowBattery.toString()) {
		updateAttr("lowBattery", childData.at_low_battery.toString())
	}
	getTriggerLog()
}

def parseTriggerLog(triggerData, data=null) {
	if (triggerData.status == "OK" && triggerData.cmdResp.result.responseData.error_code == 0) {
		def triggerLog = triggerData.cmdResp.result.responseData.result
		if (device.currentValue("lastTriggerNo") != triggerLog.start_id) {
			updateAttr("lastTriggerNo", triggerLog.start_id)
			def thisTrigger = triggerLog.logs.find{ it.id == triggerLog.start_id }
			def trigger = thisTrigger.event
			if (trigger == "rotation") {
				trigger = thisTrigger.params.rotate_deg
			}
			sendEvent(name: "lastTrigger", value: trigger, isStateChange: true)
			updateAttr("triggerTimestamp", thisTrigger.timestamp)
		}
	} else {
		logWarn("parseTriggerLog: ${triggerData}")
	}
}

//	Library Inclusion
#include davegut.lib_tpLink_sensors
#include davegut.Logging
