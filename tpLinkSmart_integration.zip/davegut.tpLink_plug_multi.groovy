/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Updates from previous version.
a.	Added Klap protocol with associated auto-use logic.
b.	Streamlined comms error processing and synched process to app find device.
c.	Added driver for Multi-plug to set.
d.	Added additional preferences (as appropriate) to child devices (sensors, multi-plug outlets)
e.	Added battery state attribute to sensors.
=================================================================================================*/
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def type() { return "tpLink_plug_multi" }

metadata {
	definition (name: "tpLink_plug_multi", namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		attribute "connected", "string"
		attribute "commsError", "string"
	}
	preferences {
		commonPreferences()
		input ("instChildren", "bool", title: "Install Child Plugs (unusual)",defaultValue: true)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() {
	runIn(1, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
	if (instChildren) {
		installChildDevices()
	}
}

def deviceParse(resp, data=null) {
	Map logData = [method: "deviceParse"]
	def respData = parseData(resp)
	try {
		def childrenData = respData.cmdResp.result.responses.find { it.method == "get_child_device_list" }
		def children = getChildDevices()
		children.each { child ->
			def position = child.getDeviceNetworkId()[-1].toInteger()
			def childData = childrenData.result.child_device_list.find{ it.position == position }
			child.parseDevData(childData)
		}
		logData << [status: "OK"]
	} catch (err) {
		logData << [status: "ERROR", error: err]
	}
	logDebug(logData)
}

//	===== Child Installation =====
def installChildDevices() {
	Map logData = [method: "installChildDevices"]
	def respData = syncSend([method: "get_child_device_list"])
	def children = respData.result.child_device_list
	children.each {
		String childDni = "${it.mac}-${it.position}"
		logData << [childDni: childDni]
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			logData << ["${alias}": "device already installed"]
		} else {
			String model = it.model
			String category = it.category
			String driver = "tpLink_plug_multi_child"
			String deviceId = it.device_id
			Map instData = [childDni: childDni, model: model, 
							category: category, driver: driver] 
			try {
				addChildDevice(nameSpace(), driver, childDni, 
							   [label: alias, name: model, deviceId : deviceId])
				instData << [status: "Installed"]
			} catch (err) {
				instData << [status: "FAILED", error: err]
			}
			logData << ["${alias}": instData]
		}
	}
	device.updateSetting("instChildren", [type: "bool", value: false])
	logDebug(logData)
}

//	===== Include Libraries =====
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
