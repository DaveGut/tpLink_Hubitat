library (
	name: "lib_tpLink_security",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "tpLink security methods",
	category: "utilities",
	documentationLink: ""
)
import groovy.json.JsonSlurper
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.Cipher
import java.security.KeyFactory
import java.util.Random
import java.security.MessageDigest

//	===== KLAP Handshake and Login =====
def klapLogin(baseUrl, localHash) {
	Map logData = [method: "klapLogin"]
	Map sessionData = [protocol: "KLAP"]
	byte[] localSeed = new byte[16]
	new Random().nextBytes(localSeed)
	def status = "ERROR"
	Map handshakeData = klapHandshake(localSeed, localHash, "${baseUrl}/handshake1")
	logData << [handshake: handshakeData]
	sessionData << [handshakeValidated: handshakeData.validated]
	if (handshakeData.validated == true) {
		sessionData << klapCreateSessionData(localSeed, handshakeData.remoteSeed,
											 localHash, handshakeData.cookie)
		Map loginData = klapLoginDevice("${baseUrl}/handshake2", localHash, localSeed, 
										handshakeData.remoteSeed, handshakeData.cookie)
		logData << [loginData: loginData]
		if (loginData.loginSuccess == true) {
			status = "OK"
		}
	}
	sessionData << [status: status]
	if (status != "OK") {
		logInfo(logData)
	}
	return sessionData
}

def klapHandshake(localSeed, localHash, uri) {
	Map handshakeData = [method: "klapHandshake", localSeed: localSeed, uri: uri, localHash: localHash]
	def validated = false
	Map respData = klapSyncPost(uri, localSeed)
	if (respData.status == 200 && respData.data != null) {
		byte[] data = respData.data
		def cookieHeader = respData.headers["set-cookie"].toString()
		def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
		//	Validate data
		byte[] remoteSeed = data[0 .. 15]
		byte[] serverHash = data[16 .. 47]
		byte[] authHashes = [localSeed, remoteSeed, localHash].flatten()
		byte[] localAuthHash = mdEncode("SHA-256", authHashes)
		if (localAuthHash == serverHash) {
			validated = true
			handshakeData << [cookie : cookie]
			handshakeData << [remoteSeed: remoteSeed]
		} else {
			handshakeData << [errorData: "Failed Hash Validation"]
		}
	} else {
		handshakeData << [errorData: respData]
	}
	handshakeData << [validated: validated]
	return handshakeData
}

def klapCreateSessionData(localSeed, remoteSeed, localHash, cookie) {
	Map sessionData = [method: "klapCreateSessionData"]
	//	seqNo and encIv
	byte[] payload = ["iv".getBytes(), localSeed, remoteSeed, localHash].flatten()
	byte[] fullIv = mdEncode("SHA-256", payload)
	byte[] byteSeqNo = fullIv[-4..-1]
	int seqNo = byteArrayToInteger(byteSeqNo)
	sessionData << [seqNo: seqNo]
	sessionData << [encIv: fullIv[0..11], cookie: cookie]
	//	KEY
	payload = ["lsk".getBytes(), localSeed, remoteSeed, localHash].flatten()
	sessionData << [encKey: mdEncode("SHA-256", payload)[0..15]]
	//	SIG
	payload = ["ldk".getBytes(), localSeed, remoteSeed, localHash].flatten()
	sessionData << [encSig: mdEncode("SHA-256", payload)[0..27]]
	return sessionData
}

def klapLoginDevice(uri, localHash, localSeed, remoteSeed, cookie) {
	Map loginData = [method: "klapLoginDevice"]
	byte[] authHashes = [remoteSeed, localSeed, localHash].flatten()
	byte[] body = mdEncode("SHA-256", authHashes)
	Map respData = klapSyncPost(uri, body, cookie)
	def loginSuccess = false
	if (respData.status == 200) {
		loginSuccess = true 
	} else {
		LoginData << [errorData: respData]
	}
	loginData << [loginSuccess: loginSuccess]
	return loginData
}

//	===== Legacy (AES) Handshake and Login =====
def aesLogin(baseUrl, encPassword, encUsername) {
	Map logData = [method: "aesLogin"]
	Map sessionData = [protocol: "AES"]
	Map handshakeData = aesHandshake(baseUrl)
	def status = "ERROR"
	logData << [handshakeData: handshakeData]
	if (handshakeData.respStatus == "OK") {
		byte[] encKey = handshakeData.encKey
		byte[] encIv = handshakeData.encIv
		def tokenData = aesLoginDevice(baseUrl, handshakeData.cookie, 
									   encKey, encIv,
									   encPassword, encUsername)
		logData << [tokenData: tokenData]
		if (tokenData.respStatus == "OK") {
			sessionData << [encKey: handshakeData.encKey,
							encIv: handshakeData.encIv,
							token: tokenData.token,
							cookie: handshakeData.cookie,
						    status: "OK"]
			status = "OK"
		} else {
			sessionData << [status: "ERROR"]
		}
	} else {
		sessionData << [status: "ERROR"]
	}
	logData << [status: status]
	if (logData.status != "OK") {
		logInfo(logData)
	}
	return sessionData
}

def aesHandshake(baseUrl) {
	def rsaKeys = getRsaKeys()
	Map handshakeData = [method: "aesHandshake", rsaKeyNo: rsaKeys.keyNo]
	def pubPem = "-----BEGIN PUBLIC KEY-----\n${rsaKeys.public}-----END PUBLIC KEY-----\n"
	Map cmdBody = [ method: "handshake", params: [ key: pubPem]]
	def respStatus = "ERROR"
	Map respData = aesSyncPost(baseUrl, cmdBody)
	if (respData.status == 200) {
		String deviceKey = respData.data.result.key
		def cookieHeader = respData.headers["set-cookie"].toString()
		def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
		Map aesArray = aesReadDeviceKey(deviceKey, rsaKeys.private)
		if (aesArraystatus == "ERROR") {
			handshakeData << [check: "privateKey"]
		} else {
			respStatus = "OK"
			handshakeData << [encKey: aesArray.cryptoArray[0..15], 
							  encIv: aesArray.cryptoArray[16..31], cookie: cookie]
		}
	} else {
		handshakeData << [errorData: respData]
	}
	handshakeData << [respStatus: respStatus]
	return handshakeData
}

def aesReadDeviceKey(deviceKey, privateKey) {
	def status = "ERROR"
	def respData = [method: "aesReadDeviceKey"]
	try {
		byte[] privateKeyBytes = privateKey.decodeBase64()
		byte[] deviceKeyBytes = deviceKey.getBytes("UTF-8").decodeBase64()
    	Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
		instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
		byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
		respData << [cryptoArray: cryptoArray]
		status = "OK"
	} catch (err) {
		respData << [errorData: err]
	}
	respData << [keyStatus: status]
	return respData
}

def aesLoginDevice(uri, cookie, encKey, encIv, encPassword, encUsername) {
	Map tokenData = [protocol: "aes"]
	Map logData = [method: "aesLoginDevice"]
	Map cmdBody = [method: "login_device",
				   params: [password: encPassword,
							username: encUsername],
				   requestTimeMils: 0]
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	def encrString = aesEncrypt(cmdStr, encKey, encIv)
	Map reqBody = [method: "securePassthrough", params: [request: encrString]]
	def respData = aesSyncPost(uri, reqBody, cookie)
	if (respData.status == 200) {
		if (respData.data.error_code == 0) {
			try {
				def cmdResp = aesDecrypt(respData.data.result.response, encKey, encIv)
				cmdResp = new JsonSlurper().parseText(cmdResp)
				if (cmdResp.error_code == 0) {
					tokenData << [respStatus: "OK", token: cmdResp.result.token]
				} else {
					tokenData << [respStatus: "ERROR", error_code: cmdResp.error_code,
								  check: "cryptoArray, credentials", data: cmdResp]
				}
			} catch (err) {
				tokenData << [respStatus: "ERROR", error: err]
			}
		} else {
			tokenData << [respStatus: "ERROR", data: respData.data]
		}
	} else {
		tokenData << [respStatus: "ERROR", data: respData]
	}
	logData << [tokenData: tokenData]
	if (tokenData.respStatus == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return tokenData
}

//	===== Protocol specific encrytion/decryption =====
def klapEncrypt(byte[] request, encKey, encIv, encSig) {
	int seqNo = state.seqNo + 1
	state.seqNo = seqNo
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()

	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	byte[] cipherRequest = cipher.doFinal(request)

	byte[] payload = [encSig, encSeqNo, cipherRequest].flatten()
	byte[] signature = mdEncode("SHA-256", payload)
	cipherRequest = [signature, cipherRequest].flatten()
	return [cipherData: cipherRequest, seqNumber: seqNo]
}

def aesEncrypt(request, encKey, encIv) {
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	String result = cipher.doFinal(request.getBytes("UTF-8")).encodeBase64().toString()
	return result.replace("\r\n","")
}

def klapDecrypt(cipherResponse, encKey, encIv) {
	byte[] encSeq = integerToByteArray(state.seqNo)
	byte[] ivEnc = [encIv, encSeq].flatten()

	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	byte[] byteResponse = cipher.doFinal(cipherResponse)
	return new String(byteResponse, "UTF-8")
}

def aesDecrypt(cipherResponse, encKey, encIv) {
    byte[] decodedBytes = cipherResponse.decodeBase64()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	String result = new String(cipher.doFinal(decodedBytes), "UTF-8")
	return result
}

//	===== RSA Key Methods =====
def getRsaKeys() {
	def keyNo = Math.round(5 * Math.random()).toInteger()
	def keyData = keyData()
	def RSAKeys = keyData.find { it.keyNo == keyNo }
	return RSAKeys
}

def keyData() {
	return [
		[
			keyNo: 0,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGr/mHBK8aqx7UAS+g+TuAvE3J2DdwsqRn9MmAkjPGNon1ZlwM6nLQHfJHebdohyVqkNWaCECGXnftnlC8CM2c/RujvCrStRA0lVD+jixO9QJ9PcYTa07Z1FuEze7Q5OIa6pEoPxomrjxzVlUWLDXt901qCdn3/zRZpBdpXzVZtQIDAQAB",
			private: "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMav+YcErxqrHtQBL6D5O4C8TcnYN3CypGf0yYCSM8Y2ifVmXAzqctAd8kd5t2iHJWqQ1ZoIQIZed+2eULwIzZz9G6O8KtK1EDSVUP6OLE71An09xhNrTtnUW4TN7tDk4hrqkSg/GiauPHNWVRYsNe33TWoJ2ff/NFmkF2lfNVm1AgMBAAECgYEAocxCHmKBGe2KAEkq+SKdAxvVGO77TsobOhDMWug0Q1C8jduaUGZHsxT/7JbA9d1AagSh/XqE2Sdq8FUBF+7vSFzozBHyGkrX1iKURpQFEQM2j9JgUCucEavnxvCqDYpscyNRAgqz9jdh+BjEMcKAG7o68bOw41ZC+JyYR41xSe0CQQD1os71NcZiMVqYcBud6fTYFHZz3HBNcbzOk+RpIHyi8aF3zIqPKIAh2pO4s7vJgrMZTc2wkIe0ZnUrm0oaC//jAkEAzxIPW1mWd3+KE3gpgyX0cFkZsDmlIbWojUIbyz8NgeUglr+BczARG4ITrTV4fxkGwNI4EZxBT8vXDSIXJ8NDhwJBAIiKndx0rfg7Uw7VkqRvPqk2hrnU2aBTDw8N6rP9WQsCoi0DyCnX65Hl/KN5VXOocYIpW6NAVA8VvSAmTES6Ut0CQQCX20jD13mPfUsHaDIZafZPhiheoofFpvFLVtYHQeBoCF7T7vHCRdfl8oj3l6UcoH/hXMmdsJf9KyI1EXElyf91AkAvLfmAS2UvUnhX4qyFioitjxwWawSnf+CewN8LDbH7m5JVXJEh3hqp+aLHg1EaW4wJtkoKLCF+DeVIgbSvOLJw"
		],[
			keyNo: 1,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCshy+qBKbJNefcyJUZ/3i+3KyLji6XaWEWvebUCC2r9/0jE6hc89AufO41a13E3gJ2es732vaxwZ1BZKLy468NnL+tg6vlQXaPkDcdunQwjxbTLNL/yzDZs9HRju2lJnupcksdJWBZmjtztMWQkzBrQVeSKzSTrKYK0s24EEXmtQIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKyHL6oEpsk159zIlRn/eL7crIuOLpdpYRa95tQILav3/SMTqFzz0C587jVrXcTeAnZ6zvfa9rHBnUFkovLjrw2cv62Dq+VBdo+QNx26dDCPFtMs0v/LMNmz0dGO7aUme6lySx0lYFmaO3O0xZCTMGtBV5IrNJOspgrSzbgQRea1AgMBAAECgYBSeiX9H1AkbJK1Z2ZwEUNF6vTJmmUHmScC2jHZNzeuOFVZSXJ5TU0+jBbMjtE65e9DeJ4suw6oF6j3tAZ6GwJ5tHoIy+qHRV6AjA8GEXjhSwwVCyP8jXYZ7UZyHzjLQAK+L0PvwJY1lAtns/Xmk5GH+zpNnhEmKSZAw23f7wpj2QJBANVPQGYT7TsMTDEEl2jq/ZgOX5Djf2VnKpPZYZGsUmg1hMwcpN/4XQ7XOaclR5TO/CJBJl3UCUEVjdrR1zdD8g8CQQDPDoa5Y5UfhLz4Ja2/gs2UKwO4fkTqqR6Ad8fQlaUZ55HINHWFd8FeERBFgNJzszrzd9BBJ7NnZM5nf2OPqU77AkBLuQuScSZ5HL97czbQvwLxVMDmLWyPMdVykOvLC9JhPgZ7cvuwqnlWiF7mEBzeHbBx9JDLJDd4zE8ETBPLgapPAkAHhCR52FaSdVQSwfNjr1DdHw6chODlj8wOp8p2FOiQXyqYlObrOGSpkH8BtuJs1sW+DsxdgR5vE2a2tRYdIe0/AkEAoQ5MzLcETQrmabdVCyB9pQAiHe4yY9e1w7cimsLJOrH7LMM0hqvBqFOIbSPrZyTp7Ie8awn4nTKoZQtvBfwzHw=="
		],[
			keyNo: 2,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCBeqRy4zAOs63Sc5yc0DtlFXG1stmdD6sEfUiGjlsy0S8aS8X+Qcjcu5AK3uBBrkVNIa8djXht1bd+pUof5/txzWIMJw9SNtNYqzSdeO7cCtRLzuQnQWP7Am64OBvYkXn2sUqoaqDE50LbSQWbuvZw0Vi9QihfBYGQdlrqjCPUsQIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIF6pHLjMA6zrdJznJzQO2UVcbWy2Z0PqwR9SIaOWzLRLxpLxf5ByNy7kAre4EGuRU0hrx2NeG3Vt36lSh/n+3HNYgwnD1I201irNJ147twK1EvO5CdBY/sCbrg4G9iRefaxSqhqoMTnQttJBZu69nDRWL1CKF8FgZB2WuqMI9SxAgMBAAECgYBBi2wkHI3/Y0Xi+1OUrnTivvBJIri2oW/ZXfKQ6w+PsgU+Mo2QII0l8G0Ck8DCfw3l9d9H/o2wTDgPjGzxqeXHAbxET1dS0QBTjR1zLZlFyfAs7WO8tDKmHVroUgqRkJgoQNQlBSe1E3e7pTgSKElzLuALkRS6p1jhzT2wu9U04QJBAOFr/G36PbQ6NmDYtVyEEr3vWn46JHeZISdJOsordR7Wzbt6xk6/zUDHq0OGM9rYrpBy7PNrbc0JuQrhfbIyaHMCQQCTCvETjXCMkwyUrQT6TpxVzKEVRf1rCitnNQCh1TLnDKcCEAnqZT2RRS3yNXTWFoJrtuEHMGmwUrtog9+ZJBlLAkEA2qxdkPY621XJIIO404mPgM7rMx4F+DsE7U5diHdFw2fO5brBGu13GAtZuUQ7k2W1WY0TDUO+nTN8XPDHdZDuvwJABu7TIwreLaKZS0FFJNAkCt+VEL22Dx/xn/Idz4OP3Nj53t0Guqh/WKQcYHkowxdYmt+KiJ49vXSJJYpiNoQ/NQJAM1HCl8hBznLZLQlxrCTdMvUimG3kJmA0bUNVncgUBq7ptqjk7lp5iNrle5aml99foYnzZeEUW6jrCC7Lj9tg+w=="
		],[
			keyNo: 3,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCFYaoMvv5kBxUUbp4PQyd7RoZlPompsupXP2La0qGGxacF98/88W4KNUqLbF4X5BPqxoEA+VeZy75qqyfuYbGQ4fxT6usE/LnzW8zDY/PjhVBht8FBRyAUsoYAt3Ip6sDyjd9YzRzUL1Q/OxCgxz5CNETYxcNr7zfMshBHDmZXMQIDAQAB",
			private: "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIVhqgy+/mQHFRRung9DJ3tGhmU+iamy6lc/YtrSoYbFpwX3z/zxbgo1SotsXhfkE+rGgQD5V5nLvmqrJ+5hsZDh/FPq6wT8ufNbzMNj8+OFUGG3wUFHIBSyhgC3cinqwPKN31jNHNQvVD87EKDHPkI0RNjFw2vvN8yyEEcOZlcxAgMBAAECgYA3NxjoMeCpk+z8ClbQRqJ/e9CC9QKUB4bPG2RW5b8MRaJA7DdjpKZC/5CeavwAs+Ay3n3k41OKTTfEfJoJKtQQZnCrqnZfq9IVZI26xfYo0cgSYbi8wCie6nqIBdu9k54nqhePPshi22VcFuOh97xxPvY7kiUaRbbKqxn9PFwrYQJBAMsO3uOnYSJxN/FuxksKLqhtNei2GUC/0l7uIE8rbRdtN3QOpcC5suj7id03/IMn2Ks+Vsrmi0lV4VV/c8xyo9UCQQCoKDlObjbYeYYdW7/NvI6cEntgHygENi7b6WFk+dbRhJQgrFH8Z/Idj9a2E3BkfLCTUM1Z/Z3e7D0iqPDKBn/tAkBAHI3bKvnMOhsDq4oIH0rj+rdOplAK1YXCW0TwOjHTd7ROfGFxHDCUxvacVhTwBCCw0JnuriPEH81phTg2kOuRAkAEPR9UrsqLImUTEGEBWqNto7mgbqifko4T1QozdWjI10K0oCNg7W3Y+Os8o7jNj6cTz5GdlxsHp4TS/tczAH7xAkBY6KPIlF1FfiyJAnBC8+jJr2h4TSPQD7sbJJmYw7mvR+f1T4tsWY0aGux69hVm8BoaLStBVPdkaENBMdP+a07u"
		],[
			keyNo: 4,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQClF0yuCpo3r1ZpYlGcyI5wy5nnvZdOZmxqz5U2rklt2b8+9uWhmsGdpbTv5+qJXlZmvUKbpoaPxpJluBFDJH2GSpq3I0whh0gNq9Arzpp/TDYaZLb6iIqDMF6wm8yjGOtcSkB7qLQWkXpEN9T2NsEzlfTc+GTKc07QXHnzxoLmwQIDAQAB",
			private: "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKUXTK4KmjevVmliUZzIjnDLmee9l05mbGrPlTauSW3Zvz725aGawZ2ltO/n6oleVma9Qpumho/GkmW4EUMkfYZKmrcjTCGHSA2r0CvOmn9MNhpktvqIioMwXrCbzKMY61xKQHuotBaRekQ31PY2wTOV9Nz4ZMpzTtBcefPGgubBAgMBAAECgYB4wCz+05RvDFk45YfqFCtTRyg//0UvO+0qxsBN6Xad2XlvlWjqJeZd53kLTGcYqJ6rsNyKOmgLu2MS8Wn24TbJmPUAwZU+9cvSPxxQ5k6bwjg1RifieIcbTPC5wHDqVy0/Ur7dt+JVMOHFseR/pElDw471LCdwWSuFHAKuiHsaUQJBANHiPdSU3s1bbJYTLaS1tW0UXo7aqgeXuJgqZ2sKsoIEheEAROJ5rW/f2KrFVtvg0ITSM8mgXNlhNBS5OE4nSD0CQQDJXYJxKvdodeRoj+RGTCZGZanAE1naUzSdfcNWx2IMnYUD/3/2eB7ZIyQPBG5fWjc3bGOJKI+gy/14bCwXU7zVAkAdnsE9HBlpf+qOL3y0jxRgpYxGuuNeGPJrPyjDOYpBwSOnwmL2V1e7vyqTxy/f7hVfeU7nuKMB5q7z8cPZe7+9AkEAl7A6aDe+wlE069OhWZdZqeRBmLC7Gi1d0FoBwahW4zvyDM32vltEmbvQGQP0hR33xGeBH7yPXcjtOz75g+UPtQJBAL4gknJ/p+yQm9RJB0oq/g+HriErpIMHwrhNoRY1aOBMJVl4ari1Ch2RQNL9KQW7yrFDv7XiP3z5NwNDKsp/QeU="
		],[
			keyNo: 5,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChN8Xc+gsSuhcLVM1W1E+e1o+celvKlOmuV6sJEkJecknKFujx9+T4xvyapzyePpTBn0lA9EYbaF7UDYBsDgqSwgt0El3gV+49O56nt1ELbLUJtkYEQPK+6Pu8665UG17leCiaMiFQyoZhD80PXhpjehqDu2900uU/4DzKZ/eywwIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKE3xdz6CxK6FwtUzVbUT57Wj5x6W8qU6a5XqwkSQl5yScoW6PH35PjG/JqnPJ4+lMGfSUD0RhtoXtQNgGwOCpLCC3QSXeBX7j07nqe3UQtstQm2RgRA8r7o+7zrrlQbXuV4KJoyIVDKhmEPzQ9eGmN6GoO7b3TS5T/gPMpn97LDAgMBAAECgYAy+uQCwL8HqPjoiGR2dKTI4aiAHuEv6m8KxoY7VB7QputWkHARNAaf9KykawXsNHXt1GThuV0CBbsW6z4U7UvCJEZEpv7qJiGX8UWgEs1ISatqXmiIMVosIJJvoFw/rAoScadCYyicskjwDFBVNU53EAUD3WzwEq+dRYDn52lqQQJBAMu30FEReAHTAKE/hvjAeBUyWjg7E4/lnYvb/i9Wuc+MTH0q3JxFGGMb3n6APT9+kbGE0rinM/GEXtpny+5y3asCQQDKl7eNq0NdIEBGAdKerX4O+nVDZ7PXz1kQ2ca0r1tXtY/9sBDDoKHP2fQAH/xlOLIhLaH1rabSEJYNUM0ohHdJAkBYZqhwNWtlJ0ITtvSEB0lUsWfzFLe1bseCBHH16uVwygn7GtlmupkNkO9o548seWkRpnimhnAE8xMSJY6aJ6BHAkEAuSFLKrqGJGOEWHTx8u63cxiMb7wkK+HekfdwDUzxO4U+v6RUrW/sbfPNdQ/FpPnaTVdV2RuGhg+CD0j3MT9bgQJARH86hfxp1bkyc7f1iJQT8sofdqqVz5grCV5XeGY77BNmCvTOGLfL5pOJdgALuOoP4t3e94nRYdlW6LqIVugRBQ=="
		]
	]
}

//	===== Encoding Methods =====
def mdEncode(hashMethod, byte[] data) {
	MessageDigest md = MessageDigest.getInstance(hashMethod)
	md.update(data)
	return md.digest()
}

String encodeUtf8(String message) {
	byte[] arr = message.getBytes("UTF8")
	return new String(arr)
}

int byteArrayToInteger(byte[] byteArr) {
	int arrayASInteger
	try {
		arrayAsInteger = ((byteArr[0] & 0xFF) << 24) + ((byteArr[1] & 0xFF) << 16) +
			((byteArr[2] & 0xFF) << 8) + (byteArr[3] & 0xFF)
	} catch (error) {
		Map errLog = [byteArr: byteArr, ERROR: error]
		logWarn("byteArrayToInteger: ${errLog}")
	}
	return arrayAsInteger
}

byte[] integerToByteArray(value) {
	String hexValue = hubitat.helper.HexUtils.integerToHexString(value, 4)
	byte[] byteValue = hubitat.helper.HexUtils.hexStringToByteArray(hexValue)
	return byteValue
}