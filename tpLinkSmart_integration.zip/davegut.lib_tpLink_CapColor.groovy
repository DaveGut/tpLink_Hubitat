library (
	name: "lib_tpLink_CapColor",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat Capability Color and ColorTemperature Methods for TPLink SMART devices.",
	category: "utilities",
	documentationLink: ""
)

def setColorTemperature(colorTemp, level = device.currentValue("level"), transTime=null) {
	logDebug("setColorTemperature: [level: ${level}, colorTemp: ${colorTemp}]")
	def lowCt = getDataValue("ctLow").toInteger()
	def highCt = getDataValue("ctHigh").toInteger()
	if (colorTemp < lowCt) { colorTemp = lowCt }
	else if (colorTemp > highCt) { colorTemp = highCt }
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			brightness: level,
			color_temp: colorTemp
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setColorTemperature", "deviceParse")
}

def setHue(hue){
	logDebug("setHue: ${hue}")
	hue = (3.6 * hue).toInteger()
	logInfo("setHue: ${hue}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setHue", "deviceParse")
}

def setSaturation(saturation) {
	logDebug("setSatiratopm: ${saturation}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			saturation: saturation,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setSaturation", "deviceParse")
}

def setColor(color) {
	def hue = (3.6 * color.hue).toInteger()
	logDebug("setColor: ${color}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			saturation: color.saturation,
			brightness: color.level,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setColor", "deviceParse")
}
