library (
	name: "lib_tpLink_CapSwitch",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat Capability Switch Methods for TPLink SMART devices.",
	category: "utilities",
	documentationLink: ""
)

capability "Switch"

def plugSwitchPreferences() {
	input ("autoOffEnable", "bool", title: "Enable Auto Off", defaultValue: false)
	input ("autoOffTime", "NUMBER", title: "Auto Off Time (minutes)", defaultValue: 120)
	input ("defState", "enum", title: "Power Loss Default State",
		   options: ["lastState", "on", "off"], defaultValue: "lastState")
}

def on() {
	setPower(true)
	if (autoOffEnable) {
		runIn(5 + 60 * autoOffTime.toInteger(), refresh)
	}
}

def off() {
	setPower(false)
	unschedule(off)
}

def setPower(onOff) {
	logDebug("setPower: [device_on: ${onOff}]")
	List requests = [[
		method: "set_device_info",
		params: [device_on: onOff]]]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "setPower", "deviceParse")
}

def setAutoOff() {
	List requests =  [[method: "set_auto_off_config",
					   params: [enable:autoOffEnable,
								delay_min: autoOffTime.toInteger()]]]
	requests << [method: "get_auto_off_config"]
	def devData = syncPassthrough(createMultiCmd(requests))
	Map retData = [cmdResp: "ERROR"]
	if (cmdResp != "ERROR") {
		def data = devData.result.responses.find { it.method == "get_auto_off_config" }
		device.updateSetting("autoOffTime", [type: "number", value: data.result.delay_min])
		device.updateSetting("autoOffEnable", [type: "bool", value: data.result.enable])
		retData = [enable: data.result.enable, time: data.result.delay_min]
	}
	return retData
}

def setDefaultState() {
	def type = "last_states"
	def state = []
	if (defState == "on") {
		type = "custom"
		state = [on: true]
	} else if (defState == "off") {
		type = "custom"
		state = [on: false]
	}
	List requests = [[method: "set_device_info",
					  params: [default_states: [type: type, state: state]]]]
	requests << [method: "get_device_info"]
	def devData = syncPassthrough(createMultiCmd(requests))
	Map retData = [cmdResp: "ERROR"]
	if (cmdResp != "ERROR") {
		def data = devData.result.responses.find { it.method == "get_device_info" }
		def defaultStates = data.result.default_states
		def newState = "lastState"
		if (defaultStates.type == "custom"){
			newState = "off"
			if (defaultStates.state.on == true) {
				newState = "on"
			}
		}
		device.updateSetting("defState", [type: "enum", value: newState])
		retData = [defState: newState]
	}
	return retData
}
