library (
	name: "lib_tpLink_child_common",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to tpLink child device drivers",
	category: "utilities",
	documentationLink: ""
)
capability "Refresh"
def version() { return parent.version() }
def label() { return device.displayName }

def refresh() {
	Map logData = [method: "refresh"]
	try {
		def cmdResp = getChildDeviceInfo().result.responseData
		logData << [status: parseDevData(cmdResp.result)]
	} catch (err) {
		logData << [status: "ERROR", error: err]
	}
	logDebug(logData)
}

def syncName() {
	Map logData = [syncName: nameSync]
	if (nameSync == "none") {
		logData << [status: "Label Not Updated"]
	} else {
		def cmdResp
		String nickname
		if (nameSync == "Hubitat") {
			nickname = device.getLabel().bytes.encodeBase64().toString()
			List requests = [[method: "set_device_info", params: [nickname: nickname]]]
			requests << [method: "get_device_info"]
			Map cmdBody = [method: "control_child",
						   params: [device_id: getDataValue("deviceId"),
									requestData: createMultiCmd(requests)]]
			def multiResp = parent.syncSend(cmdBody)
			cmdResp = getDeviceInfoData(multiResp).result
		} else {
			cmdResp = getChildDeviceInfo().result.responseData.result
		}
		nickname = cmdResp.nickname
		byte[] plainBytes = nickname.decodeBase64()
		String label = new String(plainBytes)
		device.setLabel(label)
		logData << [nickname: nickname, label: label, status: "Label Updated"]
	}
	device.updateSetting("nameSync", [type: "enum", value: "none"])
	return logData
}

def setDefaultState() {
	Map logData = [defState: defState]
	def type = "last_states"
	def state = []
	if (defState == "on") {
		type = "custom"
		state = [on: true]
	} else if (defState == "off") {
		type = "custom"
		state = [on: false]
	}
	List requests = [[method: "set_device_info", 
					  params: [default_states:[type: type, state: state]]]]
	requests << [method: "get_device_info"]
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: createMultiCmd(requests)]]
	def cmdResp = parent.syncSend(cmdBody)
	cmdResp = getDeviceInfoData(cmdResp).result
	def defaultStates = cmdResp.default_states
	def newState = "lastState"
	if (defaultStates.type == "custom"){
		newState = "off"
		if (defaultStates.state.on == true) {
			newState = "on"
		}
	}
	device.updateSetting("defState", [type: "enum", value: newState])
	if (newState == defState) {
		logData << [status: "OK"]
	} else {
		logData << [status: "FAILED"]
	}
	return logData
}

def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def getDeviceInfoData(cmdResp) {
	def responses = cmdResp.result.responseData.result.responses
	Map devInfo = responses.find { it.method == "get_device_info" }
	return devInfo
}	
	
def getDeveloperData() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	Date date = new Date()
	Map devData = [
		currentTime: date.toString(),
		name: device.getName(),
		status: device.getStatus(),
		dataValues: device.getData(),
		attributes: attrs,
		devInfo: getChildDeviceInfo(),
		compList: getDeviceComponents()
	]
	logWarn("DEVELOPER DATA: ${devData}")
}

def getDeviceComponents() {
	device.updateSetting("developerData",[type:"bool", value: false])
	Map logData = [:]
	Map cmdBody = [
		device_id: getDataValue("deviceId"),
		method: "get_child_device_component_list"
	]
	def compList = parent.syncSend(cmdBody)
	if (compList == "ERROR") {
		logWarn("getDeviceComponents: [ERROR: Error in Sysn Comms]")
	}
	return compList
}

def getChildDeviceInfo() {
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: [method: "get_device_info"]]]
	return parent.syncSend(cmdBody)
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}
