/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
def type() {return "tpLink_hub_tempHumidity" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: "tpLink_hub_tempHumidity", namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Sensor"
		capability "Temperature Measurement"
		attribute "humidity", "number"
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	childData = childData.find{ it.mac == device.getDeviceNetworkId() }
	if (device.currentValue("temperature") != childData.current_temperature ||
		device.currentValue("humidity") != childData.current_humidity) {
		sendEvent(name: "temperature", 
				  value: childData.current_temperature,
				  unit: childData.current_temp_unit)
		sendEvent(name: "humidity", childData.current_humidity)
	}
}

def parseTriggerLog(resp, data) {
}

//	Library Inclusion
#include davegut.lib_tpLink_sensors
#include davegut.Logging
