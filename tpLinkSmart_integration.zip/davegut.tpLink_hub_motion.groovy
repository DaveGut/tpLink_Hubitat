/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
def type() {return "tpLink_hub_motion" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: "tpLink_hub_motion", namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Motion Sensor"
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	childData = childData.find{ it.mac == device.getDeviceNetworkId() }
	def motion = "inactive"
	if (childData.detected) { motion = "active" }
	updateAttr("motion", motion)
}

def parseTriggerLog(resp, data) {
	//	Kept to preclude accidental error.  TriggerLogs not used for this type.
}

//	Library Inclusion
#include davegut.lib_tpLink_sensors
#include davegut.Logging
