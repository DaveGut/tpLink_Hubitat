/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Updates from previous version.
a.	Added Klap protocol with associated auto-use logic.
b.	Streamlined comms error processing and synched process to app find device.
c.	Added driver for Multi-plug to set.
d.	Added additional preferences (as appropriate) to child devices (sensors, multi-plug outlets)
e.	Added battery state attribute to sensors.
f.	Added setLed capability to preferences for plugs/switches/hub.
=================================================================================================*/

metadata {
	definition (name: "tpLink_hub", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub.groovy")
	{
		capability "Switch"
		command "configureAlarm", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		command "playAlarmConfig", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		attribute "alarmConfig", "JSON_OBJECT"
		attribute "connected", "string"
		attribute "commsError", "string"
	}
	preferences {
		input ("installChild", "bool", title: "Install Child Device", defaultValue: true)
		commonPreferences()
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["device", "always", "never", "night_mode"], defaultValue: "device")
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }
def delayedUpdates() {
	Map logData = [alarmConfig: getAlarmConfig()]
	logData << [setLedRule: setLedRule()]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
	runIn(5, installChildDevices)
}

def getAlarmConfig() {
	def cmdResp = syncSend([method: "get_alarm_configure"])
	def alarmData = cmdResp.result
	updateAttr("alarmConfig", alarmData)
	return alarmData
}

def on() {
	logDebug("on: play default alarm configuraiton")
	List requests = [[method: "play_alarm"]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "on", "alarmParse")
}

def off() {
	logDebug("off: stop alarm")
	List requests =[[method: "stop_alarm"]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "off", "alarmParse")
}

def configureAlarm(alarmType, volume, duration=30) {
	logDebug("configureAlarm: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "configureAlarm", "alarmParse")
}

def playAlarmConfig(alarmType, volume, duration=30) {
	logDebug("playAlarmConfig: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "play_alarm"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "playAlarmConfig", "alarmParse")
}

def alarmParse(resp, data) {
	def  devData = parseData(resp).cmdResp.result
	logDebug("alarmParse: ${devData}")
	if (devData && devData.responses) {
		def alarmData = devData.responses.find{it.method == "get_alarm_configure"}.result
		updateAttr("alarmConfig", alarmData)
		def devInfo = devData.responses.find{it.method == "get_device_info"}
		if (devInfo) {
			def inAlarm = devInfo.result.in_alarm
			def onOff = "off"
			if (inAlarm == true) {
				onOff = "on"
				runIn(alarmData.duration + 1, refresh)
			}
			updateAttr("switch", onOff)
		}
	} else {
		updateAttr("alarmConfig", devData)
	}
}

def alarmTypes() {
	 return [
		 "Doorbell Ring 1", "Doorbell Ring 2", "Doorbell Ring 3", "Doorbell Ring 4",
		 "Doorbell Ring 5", "Doorbell Ring 6", "Doorbell Ring 7", "Doorbell Ring 8",
		 "Doorbell Ring 9", "Doorbell Ring 10", "Phone Ring", "Alarm 1", "Alarm 2",
		 "Alarm 3", "Alarm 4", "Alarm 5", "Dripping Tap", "Connection 1", "Connection 2"
	 ] 
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		def devicesData = respData.cmdResp
		Map devData = [:]
		Map childData = [:]
		if (devicesData.result.responses) {
			devData = devicesData.result.responses.find{it.method == "get_device_info"}
			childData = devicesData.result.responses.find{it.method == "get_child_device_list"}
		}
		logData << [devData: devData, childData: childData]
		if (devData != null && devData.error_code == 0) {
			devData = devData.result
			def onOff = "off"
			if (devData.in_alarm == true) {
				onOff = "on" 
			}
			if (device.currentValue("switch") != onOff) {
				updateAttr("switch", onOff)
			}
		}
		if (childData != null && childData.error_code == 0) {
			childData = childData.result
			def children = getChildDevices()
			children.each { child ->
				child.devicePollParse(childData.child_device_list)
			}
		}
	}
	logDebug(logData)
}

//	===== Parent Install and Utilities =====
def distTriggerLog(resp, data) {
	def triggerData = parseData(resp)
	def child = getChildDevice(data.data)
	child.parseTriggerLog(triggerData)
}

def installChildDevices() {
	Map logData = [method: "installChildDevices"]
	def respData = syncSend([method: "get_child_device_list"])
	def children = respData.result.child_device_list
	children.each {
		String childDni = it.mac
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			logData << ["${alias}": "device already installed"]
		} else {
			String model = it.model
			String category = it.category
			String driver = getDriverId(category, model)
			String deviceId = it.device_id
			Map instData = [childDni: childDni, model: model, 
							category: category, driver: driver] 
			try {
				addChildDevice(nameSpace(), driver, childDni, 
							   [label: alias, name: model, deviceId : deviceId])
				instData << [status: "Installed"]
			} catch (e) {
				instData << [status: "FAILED", error: err]
			}
		}
	}
	device.updateSetting("installChild", [type: "bool", value: "false"])
	logDebug(logData)
//logInfo(logData)
}

def getDriverId(category, model) {
	def driver = "tpLink_hub-NewType"
	switch(category) {
		case "subg.trigger.contact-sensor":
			driver = "tpLink_hub_contact"
			break
		case "subg.trigger.motion-sensor":
			driver = "tpLink_hub_motion"
			break
		case "subg.trigger.button":
			if (model == "S200B") {
				driver = "tpLink_hub_button"
			}
			//	Note: Installing only sensor version for now.  Need data to install D version.
			break
		case "subg.trigger.temp-hmdt-sensor":
			driver = "tpLink_hub_tempHumidity"
			break
		case "subg.trigger":
		case "subg.trigger.water-leak-sensor":
		case "subg.plugswitch":
		case "subg.plugswitch.plug":
		case "subg.plugswitch.switch":
		case "subg.trv":
		default:
			driver = "tapoHub-NewType"
	}
	return driver
}

//	===== Install Methods Unique to Hub =====
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
