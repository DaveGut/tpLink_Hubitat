library (
	name: "lib_tpLink_discovery",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common tpLink Smart Discovery Methods",
	category: "utilities",
	documentationLink: ""
)

def getSmartLanData(response) {
	logDebug("getSmartLanData: responses returned from devices")
	def devIp
	List ipList = []
	def respData
	if (response instanceof Map) {
		devIp = getDeviceIp(response)
		if (devIp != "INVALID") {
			ipList << devIp
		}
	} else {
		response.each {
			devIp = getDeviceIp(it)
			if (devIp != "INVALID") {
				ipList << devIp
			}
			pauseExecution(100)
		}
	}
	getAllSmartDeviceData(ipList)
}

def getDeviceIp(response) {
	def brand = "KASA"
	if (appName() == "tapo_device_install") { brand = "TAPO" }
	def devIp = "INVALID"
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			Map payload = new JsonSlurper().parseText(payloadString).result
			if (payload.device_type.contains(brand)) {
				devIp = payload.ip
				logDebug("getDeviceIp: [status: found_${brand}_device, payload: ${payload}]")
			} else {
				logDebug("getDeviceIp: [status: not_${brand}_device, payload: ${payload}]")
			}
		}
	} catch (err) {
		logWarn("getDevIp: [status: ERROR, respData: ${resData}, error: ${err}]")
	}
	return devIp
}

def getAllSmartDeviceData(List ipList) {
	Map logData = [:]
	ipList.each { devIp ->
		Map devData = [:]
		def cmdResp = getSmartDeviceData([method: "get_device_info"], devIp)
		if (cmdResp == "ERROR") {
			devData << [status: "ERROR", data: "Failure in getSmartDeviceData"]
		} else {
			if (cmdResp.result.type.contains("SMART")) {
				devData << [status: "OK"]
				parseSmartDeviceData(cmdResp.result)
			} else {
				if (cmdResp.result.type) {
					devData << [status: "OK", devType: cmdResp.result.type, devIp: cmdResp.result.ip]
				} else {
					devData << [status: "ERROR", data: cmdResp]
				}
			}
		}
		logData << [devIp: devData]
		pauseExecution(200)
	}
	if (!logData.toString().contains("ERROR")) {
		logDebug("getSmartDeviceData: ${logData}")
	} else {
		logWarn("getSmartDeviceData: ${logData}")
	}
	pauseExecution(5000)
	state.findingDevices = "done"
}

def deviceLogin(devIp) {
	Map logData = [:]
	def handshakeData = handshake(devIp)
	if (handshakeData.respStatus == "OK") {
		Map credentials = [encUsername: encUsername, encPassword: encPassword]
		def tokenData = loginDevice(handshakeData.cookie, handshakeData.aesKey, 
									credentials, devIp)
		if (tokenData.respStatus == "OK") {
			logData << [rsaKeys: handshakeData.rsaKeys,
						cookie: handshakeData.cookie,
						aesKey: handshakeData.aesKey,
						token: tokenData.token]
		} else {
			logData << [tokenData: tokenData]
		}
	} else {
		logData << [handshakeData: handshakeData]
	}
	return logData
}

def getSmartDeviceData(cmdBody, devIp) {
	def cmdResp = "ERROR"
	def loginData = deviceLogin(devIp)
	Map logData = [cmdBody: cmdBody, devIp: devIp, token: loginData.token, aeskey: loginData.aesKey, cookie: loginData.cookie]
	if (loginData.token == null) {
		logData << [respStatus: "FAILED", reason: "Check Credentials"]
	} else {
		def uri = "http://${devIp}/app?token=${loginData.token}"
		cmdBody = JsonOutput.toJson(cmdBody).toString()
		Map reqBody = [method: "securePassthrough",
					   params: [request: encrypt(cmdBody, loginData.aesKey)]]
		def respData = syncPost(uri, reqBody, loginData.cookie)
		if (respData.status == "OK") {
			logData << [respStatus: "OK"]
			respData = respData.resp.data.result.response
			cmdResp = new JsonSlurper().parseText(decrypt(respData, loginData.aesKey))
		} else {
			logData << respData
		}
	}
	if (logData.respStatus == "OK") {
		logDebug("getSmartDeviceData: ${logData}")
	} else {
		logWarn("getSmartDeviceData: ${logData}")
	}
	return cmdResp
}
