library (
	name: "lib_tpLink_discovery",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common tpLink Smart Discovery Methods",
	category: "utilities",
	documentationLink: ""
)

def getSmartLanData(response) {
	logDebug("getSmartLanData: responses returned from devices")
	List discData = []
	if (response instanceof Map) {
		Map devData = getDiscData(response)
		if (devData.status == "OK") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	getAllSmartDeviceData(discData)
	updateDevices(discData)
}

def getDiscData(response) {
	Map devData = [method: "getDiscData"]
	def brand = "KASA"
	if (label().contains("tapo")) { brand = "TAPO" }
	def status = "INVALID"
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			Map payload = new JsonSlurper().parseText(payloadString).result
			List supported = supportedProducts()
			if (supported.contains(payload.device_type)) {
				def protocol = payload.mgt_encrypt_schm.encrypt_type
				def dni = payload.mac.replaceAll("-", "")
				def baseUrl = "http://${payload.ip}:${payload.mgt_encrypt_schm.http_port}/app"
				if (payload.device_type == "SMART.TAPOROBOVAC") {
					baseUrl = "https://${payload.ip}:${payload.mgt_encrypt_schm.http_port}"
					protocol = "vacAes"
				}
				devData << [
					type: payload.device_type, model: payload.device_model,
					baseUrl: baseUrl, dni: dni, devId: payload.device_id, 
					protocol: protocol, status: "OK"]
			} else {
				devData << [type: payload.device_type, model: payload.device_model, 
							status: "INVALID", reason: "Device not supported."]
			}
		}
		logDebug(devData)
	} catch (err) {
		devData << [status: "INVALID", respData: repsData, error: err]
		logWarn(devData)
	}
	return devData
}

def getAllSmartDeviceData(List discData) {
	Map logData = [method: "getAllSmartDeviceData"]
	discData.each { Map devData ->
		Map cmdResp = getSmartDeviceData(devData.baseUrl, devData.protocol)
		if (cmdResp == "ERROR" || cmdResp == null) {
			logData << [status: "ERROR", data: "response is ERROR or null"]
		} else {
			logData << [status: "OK"]
			addToDevices(devData, cmdResp.result)
		}
		pauseExecution(500)
	}
	if (!logData.toString().contains("ERROR")) {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	pauseExecution(2000)
	state.findingDevices = "done"
}

def getSmartDeviceData(baseUrl, protocol) {
	Map cmdResp = [:]
	if (protocol == "KLAP") {
		cmdResp = getKlapDeviceData(baseUrl)
	} else if (protocol == "AES") {
		cmdResp = getAesDeviceData(baseUrl)
	} else if (protocol == "vacAes") {
		cmdResp = getVacDeviceData(baseUrl)
	}
	return cmdResp
}

def getKlapDeviceData(baseUrl) {
	Map logData = [method: "getKlapDeviceData", baseUrl: baseUrl]
	def cmdResp = "ERROR"
	Map sessionData = klapLogin(baseUrl, localHash.decodeBase64())
	logData << [sessionData: sessionData]
	if (sessionData.status == "OK") {
		logData << [sessionDataStatus: sessionData.status]
		def cmdStr = JsonOutput.toJson([method: "get_device_info"]).toString()
		state.seqNo = sessionData.seqNo
		byte[] encKey = sessionData.encKey
		byte[] encIv = sessionData.encIv
		byte[] encSig = sessionData.encSig
		Map encryptedData = klapEncrypt(cmdStr.getBytes(), encKey, encIv, encSig)
		def uri = "${baseUrl}/request?seq=${encryptedData.seqNumber}"
		Map resp = klapSyncPost(uri, encryptedData.cipherData, sessionData.cookie)
		if (resp.status == 200) {
			try {
				byte[] cipherResponse = resp.data[32..-1]
				def clearResp =  klapDecrypt(cipherResponse, encKey, encIv)
				cmdResp = new JsonSlurper().parseText(clearResp)
				logData << [status: "OK"]
			} catch (err) {
				logData << [status: "cryptoError", error: "Error decrypting response", data: err]
			}
		} else {
			logData << [status: "postError", postJsonData: resp]
		}
	} else {
		logData << [respStatus: "FAILED", reason: "Login process failure.  Check credentials."]
	}
		
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def getAesDeviceData(baseUrl) {
	Map logData = [method: "getAesDeviceData", baseUrl: baseUrl]
	def cmdResp = "ERROR"
	Map sessionData = aesLogin(baseUrl, encPassword, encUsername)
	if (sessionData.status == "OK") {
		byte[] encKey = sessionData.encKey
		byte[] encIv = sessionData.encIv
		def cmdStr = JsonOutput.toJson([method: "get_device_info"]).toString()
		Map reqBody = [method: "securePassthrough",
					   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
		def uri = "${baseUrl}?token=${sessionData.token}"
		Map resp = aesSyncPost(uri, reqBody, sessionData.cookie)
		if (resp.status == 200) {
			try {
				def clearResp = aesDecrypt(resp.data.result.response, encKey, encIv)
				cmdResp = new JsonSlurper().parseText(clearResp)
				logData << [status: "OK"]
			} catch (err) {
				logData << [status: "cryptoError", error: "Error decrypting response", data: err]
			}
		} else {
			logData << [status: "postJsonError", postJsonData: resp]
		}
	} else {
		logData << [respStatus: "FAILED", reason: "Check Credentials"]
	}
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def getVacDeviceData(baseUrl) {
	Map logData = [method: "getVacDeviceData", baseUrl: baseUrl]
	def cmdResp = "ERROR"
	//	login to device
	Map loginData = vacLogin(baseUrl)
	logData << [loginData: loginData]
	if (loginData.token != "ERROR") {
		Map reqBody = [method: "get_device_info"]
		def uri = "${baseUrl}/?token=${loginData.token}"
		Map resp = aesSyncPost(uri, reqBody)
		if (resp.status == 200) {
			try {
				cmdResp = resp.data
				logData << [status: "OK"]
			} catch (err) {
				logData << [status: "responseError", error: "return data incomplete", data: err]
			}
		} else {
			logData << [status: "postJsonError", postJsonData: resp.properties]
		}
	} else {
		logData << [status: "tokenError"]
	}
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def vacLogin(baseUrl) {
	Map logData = [method: "deviceLogin", uri: baseUrl]
	Map cmdBody = [method: "login",
				   params: [hashed: true, 
							password: encPasswordVac,
							username: userName]]
	def loginResp = aesSyncPost(baseUrl, cmdBody)
	def token = "ERROR"
	if (loginResp.status == 200) {
		logData << [status: loginResp.status]
		token = loginResp.data.result.token
	} else {
		logData << [status: "FAILED", reason: "HTTP Response Status"]
	}
	logData << [token: token]
	return logData
}

def addToDevices(devData, cmdResp) {
	String dni = devData.dni
	Map deviceData = [:]
	String deviceType = devData.type
	byte[] plainBytes = cmdResp.nickname.decodeBase64()
	def alias = new String(plainBytes)
	if (alias == "") {
		alias = devData.model
	}
	deviceData << [protocol: devData.protocol]
	deviceData << [alias: alias]
	deviceData << [model: devData.model]
	deviceData << [baseUrl: devData.baseUrl]
	String capability = "newType"
	String feature
	if (deviceType.contains("BULB")) {
		capability = "bulb_dimmer"
		if (cmdResp.color_temp_range) {
			deviceData << [ctLow: cmdResp.color_temp_range[0]]
			deviceData << [ctHigh: cmdResp.color_temp_range[1]]
			if (cmdResp.color_temp_range[0] < cmdResp.color_temp_range[1]) {
				capability = "bulb_color"
			} else if (cmdResp.lighting_effect) {
				capability = "bulb_lightStrip"
			}
		}
	} else if (deviceType.contains("SWITCH") || deviceType.contains("PLUG")) {
		capability = "plug"
		if (cmdResp.brightness) {
			capability = "plug_dimmer"
		}
		if (cmdResp.power_protection_status) {
			capability = "plug_em"
		}
		if (!cmdResp.default_states) {		// parent plug does not have default_states
			capability = "plug_multi"
		}
	} else if (deviceType.contains("HUB")) {
		capability = "hub"
	} else if (deviceType.contains("ROBOVAC")) {
		capability = "robovac"
	}
	deviceData << [dni: dni]
	deviceData << [type: "tpLink_${capability}"]
	deviceData << [capability: capability]
	state.devices << ["${dni}": deviceData]
	logInfo("addToDevices <b>${deviceData.alias}</b>: [${dni}: ${deviceData}]")
}

//	===== Periodic Device Connectivity Check =====
def checkDevices() {
	//	Used by children to check for devices
	Map logData = [method: "parent.checkDevices"]
	if (state.manualChecked == true) {
		logData << [status: "noCheck", reason: "Already done within interval"]
	} else {
		logData << [checkForDevices: checkForDevices()]
		state.manualChecked = true
	}
	return logData
}

def appCheckDevices() {
	Map logData = [method: "appCheckDevices"]
	state.manualChecked = false
	logData << [checkForDevices: checkForDevices()]
	logDebug(logData)
}

def checkForDevices() {
	Map logData = [action: "Checking device connectivity and updating data for devices",
				   findDevices: findDevices("sendDataToDevice", 4)]
	return logData
}

def sendDataToDevice(response) {
	List discData = []
	if (response instanceof Map) {
		Map devdata = getDiscData(response)
		if (devData.status != "INVALID") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	updateDevices(discData)
}

def updateDevices(discData) {
	Map logData = [method: "updateDevices"]
	List children = getChildDevices()
	children.each { childDev ->
		Map childData = [:]
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (devData != null) {
			if (childDev.getDataValue("baseUrl") == devData.baseUrl &&
			    childDev.getDataValue("protocol") == devData.protocol &&
			    childDev.currentValue("connected") == "true") {
				childData << [status: "noChanges"]
			} else {
				childDev.updateDataValue("baseUrl", devData.baseUrl)
				childDev.updateDataValue("protocol", devData.protocol)
				childDev.updateAttr("connected", "true")
				childData << ["baseUrl": devData.baseUrl,
							  "protocol": devData.protocol,
							  "connected": "true"]
				childDev.deviceLogin()
			}
		} else {
			childDev.updateAttr("connected", "false")
			childData << [connected: "false", reason: "not Discovered By App"]
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
	
	
	
	
logInfo(logData)
}
