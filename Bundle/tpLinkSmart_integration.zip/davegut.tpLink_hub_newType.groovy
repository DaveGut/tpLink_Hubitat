/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

This driver is part of a set of drivers for TP-LINK SMART API plugs, switches, hubs,
sensors and thermostats.  The set encompasses the following:
a.	ALL TAPO devices except cameras and Robot Vacuum Cleaners.
b.	NEWER KASA devices using the SMART API except cameras.
	1.	MATTER devices
	2.	Kasa Hub
	3.	Kasa TRV
=================================================================================================*/
def type() {return "tpLink_hub_newType" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Contact Sensor"
		attribute "lowBattery", "string"
		attribute "status", "string"
	}
	preferences {
		input ("sensorReportInt", "enum", title: "Sensor report interval (secs) (impacts battery life)",
			   options: ["4", "8", "12", "16"], 
			   defaultValue: "8")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << [sensorReportInt: setReportInterval()]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
}

def parseTriggerLog(resp, data) {
}

//	Library Inclusion
#include davegut.lib_tpLink_sensors
#include davegut.Logging
