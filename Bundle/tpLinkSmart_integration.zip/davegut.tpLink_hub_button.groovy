/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
def type() {return "tpLink_hub_button" }
def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Sensor"
		attribute "lastTrigger", "string"
		attribute "lastTriggerNo", "number"
		attribute "triggerTimestamp", "number"
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	getTriggerLog()
}

def parseTriggerLog(triggerData, data=null) {
	if (triggerData.status == "OK" && triggerData.cmdResp.result.responseData.error_code == 0) {
		def triggerLog = triggerData.cmdResp.result.responseData.result
		if (device.currentValue("lastTriggerNo") != triggerLog.start_id) {
			updateAttr("lastTriggerNo", triggerLog.start_id)
			def thisTrigger = triggerLog.logs.find{ it.id == triggerLog.start_id }
			def trigger = thisTrigger.event
			if (trigger == "rotation") {
				trigger = thisTrigger.params.rotate_deg
			}
			sendEvent(name: "lastTrigger", value: trigger, isStateChange: true)
			updateAttr("triggerTimestamp", thisTrigger.timestamp)
		}
	} else {
		logWarn("parseTriggerLog: ${triggerData}")
	}
}

//	Library Inclusion
#include davegut.lib_tpLink_sensors
#include davegut.Logging
