library (
	name: "lib_tpLink_manInstall",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Library for manual install of a tpLink device",
	category: "utilities",
	documentationLink: ""
)

import java.security.MessageDigest

def manPreferences() {
	input ("devIp", "string", title: "Device IP",
		   defaultValue: "notEntered")
	input ("username", "string", title: "Kasa Username",
		   defaultValue: "notEntered")
	input ("password", "password", title: "Kasa Password",
		   defaultValue: "notEntered")
	input ("encUsername", "password", title: "Storage for the tpLink credentials",
		   defaultValue:"notEntered")
	input ("encPassword", "password", title: "Storage for the tpLink credentials",
		   defaultValue:"notEntered")
}

def manInstUpd() {
	def logData = [deviceIP: devIp, userName: username, password: password]
	if (devIp != "notEntered" && username != "notEntered" &&
		password != "notEntered") {
		//	trim and update user-entered data
		devIp = devIp.trim()
		device.updateSetting("devIp", [type:"string", value: devIp])
		username = username.trim()
		device.updateSetting("username", [type:"string", value: username])
		password = password.trim()
		device.updateSetting("password", [type:"password", value: password])
		
		updateDataValue("deviceIP", devIp)
		String encUsername = mdEncode(username).bytes.encodeBase64().toString()
		String encPassword = password.bytes.encodeBase64().toString()
		device.updateSetting("encUsername", [type:"password", value: encUsername])
		device.updateSetting("encPassword", [type:"password", value: encPassword])
		logData << [encUsername: encUsername, encPassword: encPassword]
		logData << [status: "OK"]
	} else {
		logData << [status: "ERROR", reason: "missingData"]
	}
	return logData
}

private String mdEncode(String message) {
	MessageDigest md = MessageDigest.getInstance("SHA-1")
	md.update(message.getBytes())
	byte[] digest = md.digest()
	return digest.encodeHex()
}

