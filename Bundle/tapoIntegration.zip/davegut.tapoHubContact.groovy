/*	Tapo Hub Trigger Contact Sensor Child Device
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
def type() {return "tapoHub-Contact" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Contact Sensor"
		attribute "reportInterval", "number"
		attribute "lowBattery", "string"
		attribute "status", "string"
	}
	preferences {
		input ("sensorReportInt", "enum", title: "Sensor report interval (secs) (impacts battery life)",
			   options: ["4", "8", "12", "16"], 
			   defaultValue: "8")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << [sensorReportInt: setReportInterval()]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	childData = childData.find{ it.mac == device.getDeviceNetworkId() }
	def contact = "closed"
	if (childData.open) { contact = "open" }
	if (device.currentValue("contact") != contact) {
		updateAttr("contact", contact)
	}
}

def parseTriggerLog(resp, data) {
//	def cmdResp = parseData(resp)
//	if (cmdResp.status == "OK") {
//		state.triggerLog = cmdResp.cmdResp.result.responseData.result
//	}
}

//	Library Inclusion
#include davegut.tapoSensorCommon
#include davegut.Logging
