library (
	name: "tapoCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to Tapo devices",
	category: "utilities",
	documentationLink: ""
)
def driverVer() { return "B.1.0" }

def setRefreshInterval() {
	runEvery10Minutes(refresh)
	return "10 mins"
}

def setLoginInterval() {
	runEvery3Hours(deviceLogin)
	return "3 hrs"
}

command "getDeveloperData"
def getDeveloperData() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	Date date = new Date()
	Map devData = [
		currentTime: date.toString(),
		lastLogin: state.lastSuccessfulLogin,
		name: device.getName(),
		status: device.getStatus(),
		aesKeyLen: aesKey.length(),
		cookieLen: deviceCookie.length(),
		tokenLen: deviceToken.length(),
		dataValues: device.getData(),
		attributes: attrs,
		cmdResp: securePassthrough([method: "get_device_info"], false),
		children: getChildDevices()
	]
	logWarn("DEVELOPER DATA: ${devData}")
}

//	===== Login Process =====
def deviceLogin() {
	Map logData = [:]
	def handshakeData = handshake()
	if (handshakeData.respStatus == "OK") {
		logData << [deviceCookie: "REDACTED for logs", 
				    aesKey: "REDACTED for logs"]
		def tokenData = loginDevice(handshakeData.cookie, handshakeData.aesKey)
		if (tokenData.respStatus == "OK") {
			device.updateSetting("aesKey", [type:"password", value: handshakeData.aesKey])
			device.updateSetting("deviceCookie", [type:"password", value: handshakeData.cookie])
			device.updateSetting("deviceToken", [type:"password", value: tokenData.token])
			Date date = new Date()
			state.lastSuccessfulLogin = date.toString()
			state.lastLogin = now()
			logData << [deviceToken: "REDACTED for logs"]
		} else {
			logData << [tokenData: tokenData]
		}
	} else {
		logData << [handshakeData: handshakeData]
	}
	pauseExecution(2000)
	return logData
}

def handshake() {
	Map handshakeData = [method: "handshakeData"]
	Map cmdBody = [ method: "handshake", params: [ key: publicPem()]]
	def uri = "http://${getDataValue("deviceIp")}/app"
	def respData = syncPost(uri, cmdBody)
	
	if (respData.respStatus == "OK") {
		if (respData.data.error_code == 0) {
			String deviceKey = respData.data.result.key
			def aesArray = readDeviceKey(deviceKey)
			if (aesArray == "ERROR") {
				logData: [readDeviceKey: "FAILED"]
				handshakeData << [respStatus: "Failed decoding deviceKey",
								  deviceKey: deviceKey]
			} else {
				handshakeData << [respStatus: "OK"]
				def cookieHeader = respData.headers["set-cookie"].toString()
				def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
				handshakeData << [cookie: cookie, aesKey: aesArray]
			}
		} else {
			handshakeData << [respStatus: "Command Error", data: respData.data]
		}
	} else {
		handshakeData << respData
	}
	return handshakeData
}

def readDeviceKey(deviceKey) {
	String privateKey = parent.privateKey()
	Map logData = [privateKey: privateKey]
	def response = "ERROR"
	try {
		byte[] privateKeyBytes = privateKey.decodeBase64()
		byte[] deviceKeyBytes = deviceKey.getBytes("UTF-8").decodeBase64()
    	Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
		instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
		byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
		response = cryptoArray
		logData << [cryptoArray: "REDACTED for logs", status: "OK"]
		logDebug("readDeviceKey: ${logData}")
	} catch (e) {
		logData << [status: "READ ERROR", data: e]
		logWarn("readDeviceKey: ${logData}")
	}
	return response
}

def loginDevice(cookie, cryptoArray) {
	Map tokenData = [method: "loginDevice"]
	def credentials = parent.getCredentials()
	def uri = "http://${getDataValue("deviceIp")}/app"
	String cmdBody = """{"method": "login_device", "params": {"password": "${credentials.encPassword}", "username": "${credentials.encUsername}"}, "requestTimeMils": 0}"""
	Map reqBody = [method: "securePassthrough", params: [request: encrypt(cmdBody, cryptoArray)]]
	def respData = syncPost(uri, reqBody, cookie)
	if (respData.respStatus == "OK") {
		if (respData.data.error_code == 0) {
			def cmdResp = decrypt(respData.data.result.response, cryptoArray)
			cmdResp = new JsonSlurper().parseText(cmdResp)
			if (cmdResp.error_code == 0) {
				tokenData << [respStatus: "OK", token: cmdResp.result.token]
			} else {
				tokenData << [respStatus: "Error in cmdResp", data: cmdResp]
			}
		} else {
			tokenData << [respStatus: "Error in respData,data", data: respData.data]
		}
	} else {
		tokenData << [respStatus: "Error in respData", data: respData]
	}
	return tokenData
}

def refresh() {
	logDebug("refresh")
	state.commsCheck = true
	runIn(10, checkForError)
	securePassthrough([method: "get_device_info"], true, "refresh")
}

def checkForError() {
	if (state.commsCheck && device.currentValue("commsError") == "OK") {
		updateDeviceIps(device.getDeviceNetworkId())
		//	Try device login to generate error.  Will only do this once.
		def loginStatus = deviceLogin()
		if (!loginStatus.cookie) {
			updateAttr("commsError", "failedHandshake")
			log.error "COMMS ERROR: <b>Check Public/Private keys and device IP</b>"
			state.COMMSERROR = "<b>Check Public/Private keys and device IP</b>"
		} else if (!loginStatus.deviceToken) {
			updateAttr("commsError", "failedLogin")
			log.error "COMMS ERROR: <b>Check login credentials</b>"
			state.COMMSERROR = "<b>Check login credentials</b>"
		} else {
//			updated()
		}
	} else if (state.commsCheck == false && device.currentValue("commsError") != "OK") {
		updateAttr("commsError", "OK")
		logInfo("checkForError: Executing updated() to assure login methods are properly scheduled")
		state.remove("COMMSERROR")
		//	Assure all scheduled events are properly scheduled.
		updated()
	}
}

//	===== Utilities =====
def getAesKey() {
	return new JsonSlurper().parseText(aesKey)
}

def publicPem() {
	def pem = "-----BEGIN PUBLIC KEY-----\n${parent.publicKey()}-----END PUBLIC KEY-----\n"
	return pem
}
