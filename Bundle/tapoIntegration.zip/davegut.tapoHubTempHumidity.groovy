/*	Tapo Hub Temperature Humidity Sensor Child Device
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
def type() {return "tapoHub-TempHumidity" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Sensor"
		capability "Temperature Measurement"
		attribute "humidity", "number"
		attribute "reportInterval", "number"
		attribute "lowBattery", "string"
		attribute "status", "string"
	}
	preferences {
		input ("sensorReportInt", "enum", title: "Sensor report interval (secs) (impacts battery life)",
			   options: ["4", "8", "12", "16"], 
			   defaultValue: "8")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << [sensorReportInt: setReportInterval()]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	childData = childData.find{ it.mac == device.getDeviceNetworkId() }
	if (device.currentValue("temperature") != childData.current_temperature ||
		device.currentValue("humidity") != childData.current_humidity) {
		sendEvent(name: "temperature", 
				  value: childData.current_temperature,
				  unit: childData.current_temp_unit)
		sendEvent(name: "humidity", childData.current_humidity)
	}
}
	
def parseTriggerLog(resp, data) {
}

//	Library Inclusion
#include davegut.tapoSensorCommon
#include davegut.Logging
