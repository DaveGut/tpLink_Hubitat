/*	Tapo Hub Trigger Contact Sensor Child Device
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
def type() {return "tapoHub-Button" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Sensor"
		attribute "lastTrigger", "string"
		attribute "lastTriggerNo", "number"
		attribute "triggerTimestamp", "number"
		attribute "reportInterval", "number"
		attribute "lowBattery", "string"
		attribute "status", "string"
	}
	preferences {
		input ("buttonPollInt", "enum", title: "Poll interval for button (seconds)",
			   options: ["5 sec", "10 sec", "15 sec", "30 sec", "1 min", "5 min"], 
			   defaultValue: "30 sec")
		input ("sensorReportInt", "enum", title: "Sensor report interval (secs) (impacts battery life)",
			   options: ["4", "8", "12", "16"], 
			   defaultValue: "8")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << [buttonPollInt: setButtonPoll()]
	logData << [sensorReportInt: setReportInterval()]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

def setButtonPoll() {
	if (buttonPollInt.contains("sec")) {
		def pollInterval = buttonPollInt.replace(" sec", "").toInteger()
		schedule("3/${pollInterval} * * * * ?", "getTriggerLog")
	} else if (buttonPollInt == "1 min") {
		runEvery1Minute(pollChildren)
	} else {
		runEvery5Minutes(pollChildren)
	}
	return buttonPollInt
}

//	Parse Methods
def devicePollParse(childData, data=null) {
}

def parseTriggerLog(triggerData, data=null) {
	if (triggerData.status == "OK") {
		def triggerLog = triggerData.cmdResp.result.responseData.result
		if (device.currentValue("lastTriggerNo") != triggerLog.start_id) {
			updateAttr("lastTriggerNo", triggerLog.start_id)
			def thisTrigger = triggerLog.logs.find{ it.id == triggerLog.start_id }
			def trigger = thisTrigger.event
			if (trigger == "rotation") {
				trigger = thisTrigger.params.rotate_deg
			}
			sendEvent(name: "lastTrigger", value: trigger, isStateChange: true)
			updateAttr("triggerTimestamp", thisTrigger.timestamp)
		}
	} else {
		logWarn("parseTriggerLog: ${triggerData}")
	}
}

//	Library Inclusion
#include davegut.tapoSensorCommon
#include davegut.Logging
