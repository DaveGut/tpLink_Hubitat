/*	TAPO Hub
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

===================================================================================================*/
def type() {return "tapoHub" }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Refresh"
		command "stopAlarm"
		command "playAlarm"
		attribute "alarmConfig", "JSON_OBJECT"
		attribute "commsError", "string"
		command "installChildDevices"
		command "deviceLogin"
	}
	preferences {
//INPUT		command "configureAlarm"	Work in progress
		input ("aesKey", "password", title: "Storage for the AES Key")
		input ("deviceCookie", "password", title: "Storage for the cookie")
		input ("deviceToken", "password", title: "Storage for the token")
		input ("sensorPollInt", "enum", title: "Poll interval for sensors (seconds)",
			   options: ["5 sec", "10 sec", "15 sec", "30 sec", "1 min", "5 min"], 
			   defaultValue: "30 sec")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	Map logData = [:]
	logData << [loginResults: deviceLogin()]
	logData << [login: setLoginInterval()]
	logData << [refresh: setRefreshInterval()]
	logData << [sensorPollInt: setSensorPoll()]
	logData << setLogsOff()
//	logData << [alarms: getAlarmTypes()]
//	logData << [alarmConfig: getAlarmConfig()]
	logData << [status: "OK"]
	runIn(1, getAlarmTypes)
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

def setSensorPoll() {
	if (sensorPollInt.contains("sec")) {
		def pollInterval = sensorPollInt.replace(" sec", "").toInteger()
		schedule("3/${pollInterval} * * * * ?", "pollChildren")
	} else if (sensorPollInt == "1 min") {
		runEvery1Minute(pollChildren)
	} else {
		runEvery5Minutes(pollChildren)
	}
	return sensorPollInt
}

def getAlarmTypes() {
	Map logData = [:]
	Map cmdBody =[method: "get_support_alarm_type_list"]
	def cmdResp = securePassthrough(cmdBody, false)
	if (cmdResp != "ERROR") {
		updateDataValue("alarmTypes", cmdResp.result.alarm_type_list.toString())
		logInfo("getAlarmTypes: ${cmdResp.result.alarm_type_list.toString()}")
	} else {
		logWarn("getAlarmTypes: FAILED")
	}
	getAlarmConfig()
}

def getAlarmConfig() {
	Map logData = [:]
	Map cmdBody =[method: "get_alarm_configure"]
	def cmdResp = securePassthrough(cmdBody, false)
	if (cmdResp != "ERROR") {
		updateAttr("alarmConfig", cmdResp)
		logInfo("getAlarmConfig: ${cmdResp}")
	} else {
		logWarn("getAlarmConfig: FAILED")
	}
}

//	Alarm Commands
def stopAlarm() {
	logDebug("stopAlarm")
	Map cmdBody =[
		method: "stop_alarm"
	]
	sendMultiCmd(cmdBody, true, "stopAlarm")
}

def playAlarm() {
	logDebug("playAlarm")
	Map cmdBody =[
		method: "play_alarm"
	]
	sendMultiCmd(cmdBody, true, "playAlarm", "playAlarmParse")
}

def playAlarmParse(resp, data) {
	//	No parsing required at this time.  May add in_alarm status.
}

//	Work in progress.  Currently fails
def configureAlarm() {
	Map cmdBody =[
		method: "set_alarm_configure",
		params: [
			type: "Doorbell Ring 4",
			volume: "normal",
			duration: "300"
		]
	]
	sendMultiCmd(cmdBody, true, "configureAlarm")
}

//	poll/refresh children
def pollChildren() {
	Map cmdBody = [
		method: "get_child_device_list"
	]
	securePassthrough(cmdBody, true, "pollChildren")
}
def childPollParse(childData) {
	def children = getChildDevices()
	children.each { child ->
		child.devicePollParse(childData)
	}
}

def refreshChildren() {
	Map cmdBody = [
		method: "get_child_device_list"
	]
	securePassthrough(cmdBody, true, "refreshChildren")
}
def childRefreshParse(childData, data=null) {
	childData.each {
		def children = getChildDevices()
		children.each { child ->
			child.deviceRefreshParse(childData)
		}
	}
}

def distTriggerLog(resp, data) {
	def triggerData = parseData(resp)
	def child = getChildDevice(data.data)
	child.parseTriggerLog(triggerData)
}

//	Parse Method
def deviceParse(devData, reqDni = null) {
	//	for Hub, no dynamic data from this command.
	refreshChildren()
}

//	===== Install Methods =====
def installChildDevices() {
	def logData = [:]
	def respData = securePassthrough([method: "get_child_device_list"], false)
	def childSensors = respData.result.child_device_list
	childSensors.each {
		String sensorDni = it.mac
		logData << [sensorDni: sensorDni]
		def isChild = getChildDevice(dni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			logInfo("installChildDevices: [${alias}: device already installed]")
		} else {
			String model = it.model
			String category = it.category
			String driver = getDriverId(category, model)
			String deviceId = it.device_id
			def instData = [sensorDni: sensorDni, model: model, category: category, driver: driver] 
			try {
				addChildDevice("davegut", driver, sensorDni, 
							   [label: alias, name: model, deviceId : deviceId])
				logInfo("installChildDevices: [${alias}: Installed, data: ${instData}]")
			} catch (e) {
				logWarn("installChildDevices: [${alias}: FAILED, data: ${instData}, error: ${e}]")
			}
		}
		logData << ["${alias}": "complete"]
	}
	if (logData.status == "Failed") {
		logWarn("installChildDevices: <b>${logData}</b>")
	} else {
		logInfo("installChildDevices: ${logData}")
	}
}

def getDriverId(category, model) {
	def driver = "tapoHub-NewType"
	switch(category) {
		case "subg.trigger.contact-sensor":
			driver = "tapoHub-Contact"
			break
		case "subg.trigger.motion-sensor":
			driver = "tapoHub-Motion"
			break
		case "subg.trigger.button":
			if (model == "S200B") {
				driver = "tapoHub-Button"
			}
			//	Note: Installing only sensor version for now.  Need data to install D version.
			break
		case "subg.trigger.temp-hmdt-sensor":
			driver = "tapoHub-TempHumidity"
			break
		case "subg.trigger":
		case "subg.trigger.water-leak-sensor":
		case "subg.plugswitch":
		case "subg.plugswitch.plug":
		case "subg.plugswitch.switch":
		case "subg.trv":
			break
		default:
			driver = "tapoHub-NewType"
	}
	return driver
}

//	Library Inclusion
#include davegut.tapoCommon
#include davegut.tapoComms
#include davegut.Logging
