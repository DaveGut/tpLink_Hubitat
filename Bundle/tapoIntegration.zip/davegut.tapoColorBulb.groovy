/*	Tapo Color Bulb
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

===================================================================================================*/
def type() {return "tapoColorBulb" }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Switch"
		capability "Light"
		capability "Switch Level"
		capability "Change Level"
		capability "Color Temperature"
		capability "Color Mode"
		capability "Color Control"
		capability "Refresh"
		attribute "commsError", "string"
		command "deviceLogin"
	}
	preferences {
		input ("gradualOnOff", "bool", title: "Set Bulb to Gradual ON/OFF", defaultValue: false)
		input ("aesKey", "password", title: "Storage for the AES Key")
		input ("deviceCookie", "password", title: "Storage for the cookie")
		input ("deviceToken", "password", title: "Storage for the token")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}
def updated() {
	unschedule()
	Map logData = [:]
	logData << [loginResults: deviceLogin()]
	logData << [login: setLoginInterval()]
	logData << [refresh: setRefreshInterval()]
	runIn(3, setGradualOnOff)
	logData << [status: "OK"]
	logData << setLogsOff()
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

def setGradualOnOff() {
	Map cmdBody = [
		method: "multipleRequest",
		params: [
			requests:[
				[method: "set_on_off_gradually_info", params: [enable: gradualOnOff]],
				[method: "get_on_off_gradually_info"]]]]
	def cmdResp = securePassthrough(cmdBody, false).result.responses
	def resp = cmdResp.find { it.method == "get_on_off_gradually_info" }
	device.updateSetting("gradualOnOff",[type:"bool", value: resp.result.enable])
	if (cmdResp[0].error_code != 0) {
		newGradualOnOff = "Failed"
	}
	logInfo("setGradualOnOff: [gradulaOnOff: ${resp.result.enable}]")
}

//	Switch and Light
def on() { setPower(true) }
def off() { setPower(false) }
def setPower(onOff) {
	logDebug("setPower: [device_on: ${onOff}]")
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: onOff
		]]
	sendMultiCmd(cmdBody, true, "setPower")
}

//	Switch Level
def setLevel(level, transTime=null) {
	//	Note: Tapo Devices do not support transition time.  Set preference "Set Bulb to Gradual ON/OFF"
	logDebug("setLevel: [brightness: ${level}]")
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: true,
			brightness: level
		]]
	sendMultiCmd(cmdBody, true, "setLevel")
}

//	Change Level
def startLevelChange(direction) {
	logDebug("startLevelChange: [level: ${device.currentValue("level")}, direction: ${direction}]")
	if (direction == "up") { levelUp() }
	else { levelDown() }
}
def stopLevelChange() {
	logDebug("stopLevelChange: [level: ${device.currentValue("level")}]")
	unschedule(levelUp)
	unschedule(levelDown)
}
def levelUp() {
	def curLevel = device.currentValue("level").toInteger()
	if (curLevel != 100) {
		def newLevel = curLevel + 4
		if (newLevel > 100) { newLevel = 100 }
		setLevel(newLevel)
		runIn(1, levelUp)
	}
}
def levelDown() {
	def curLevel = device.currentValue("level").toInteger()
	if (device.currentValue("switch") == "on") {
		def newLevel = curLevel - 4
		if (newLevel <= 0) { off() }
		else {
			setLevel(newLevel)
			runIn(1, levelDown)
		}
	}
}

//	Color Temperature
def setColorTemperature(colorTemp, level = device.currentValue("level"), transTime=null) {
	//	Note: Tapo Devices do not support transition time.  Set preference "Set Bulb to Gradual ON/OFF"
	logDebug("setColorTemperature: [level: ${level}, colorTemp: ${colorTemp}]")
	def lowCt = getDataValue("ctLow").toInteger()
	def highCt = getDataValue("ctHigh").toInteger()
	if (colorTemp < lowCt) { colorTemp = lowCt }
	else if (colorTemp > highCt) { colorTemp = highCt }
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: true,
			brightness: level,
			color_temp: colorTemp
		]]
	sendMultiCmd(cmdBody, true, "setColorTemperature")
}

//	Color Control
def setHue(hue){
	logDebug("setHue: ${hue}")
	hue = (3.6 * hue).toInteger()
	logInfo("setHue: ${hue}")
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			color_temp: 0
		]]
	sendMultiCmd(cmdBody, true, "setHue")
}
def setSaturation(saturation) {
	logDebug("setSatiratopm: ${saturation}")
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: true,
			saturation: saturation,
			color_temp: 0
		]]
	sendMultiCmd(cmdBody, true, "setSaturation")
}
def setColor(color) {
	def hue = (3.6 * color.hue).toInteger()
	logDebug("setColor: ${color}")
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			saturation: color.saturation,
			brightness: color.level,
			color_temp: 0
		]]
	sendMultiCmd(cmdBody, true, "setColor")
}

//	Parse Method
def deviceParse(devData, data=null) {
	logDebug("deviceParse: ${devData}")
	def onOff = "off"
	if (devData.device_on == true) { onOff = "on" }
	updateAttr("switch", onOff)
	updateAttr("level", devData.brightness)
	if (devData.color_temp == 0) {
		updateAttr("colorMode", "COLOR")
		def hubHue = (devData.hue / 3.6).toInteger()
		updateAttr("hue", hubHue)
		updateAttr("saturation", devData.saturation)
		updateAttr("color", "[hue: ${hubHue}, saturation: ${devData.saturation}]")
		updateAttr("colorName", colorName = convertHueToGenericColorName(hubHue))
		def rgb = hubitat.helper.ColorUtils.hsvToRGB([hubHue,
													  devData.saturation,
													  devData.brightness])
		updateAttr("RGB", rgb)
		updateAttr("colorTemperature", 0)
	} else {
		updateAttr("colorMode", "CT")
		updateAttr("colorTemperature", devData.color_temp)
		updateAttr("colorName", convertTemperatureToGenericColorName(devData.color_temp.toInteger()))
		updateAttr("color", "[:]")
		updateAttr("RGB", "[]")
	}
}

//	Library Inclusion
#include davegut.tapoCommon
#include davegut.tapoComms
#include davegut.Logging
