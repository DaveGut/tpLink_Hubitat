/*	Tapo Switch
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
 
=================================================================================================*/
def type() {return "tapoSwitch" }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Switch"
		capability "Refresh"
		attribute "commsError", "string"
		command "deviceLogin"
	}
	preferences {
		input ("aesKey", "password", title: "Storage for the AES Key")
		input ("deviceCookie", "password", title: "Storage for the cookie")
		input ("deviceToken", "password", title: "Storage for the token")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}
def updated() {
	unschedule()
	Map logData = [:]
	logData << [loginResults: deviceLogin()]
	logData << [login: setLoginInterval()]
	logData << [refresh: setRefreshInterval()]
	logData << [status: "OK"]
	logData << setLogsOff()
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Switch and Light
def on() { setPower(true) }
def off() { setPower(false) }
def setPower(onOff) {
	logDebug("setPower: [device_on: ${onOff}]")
	Map cmdBody = [
		method: "set_device_info",
		params: [
			device_on: onOff
		]]
	sendMultiCmd(cmdBody, true, "setPower")
}

//	Parse Method
def deviceParse(devData, data=null) {
	logDebug("deviceParse: ${devData}")
	def onOff = "off"
	if (devData.device_on == true) { onOff = "on" }
	updateAttr("switch", onOff)
}

//	Library Inclusion
#include davegut.tapoCommon
#include davegut.tapoComms
#include davegut.Logging
