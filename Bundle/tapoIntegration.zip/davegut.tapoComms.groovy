library (
	name: "tapoComms",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Tapo Communications",
	category: "utilities",
	documentationLink: ""
)
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.Cipher
import java.security.KeyFactory

def sendMultiCmd(request, async, method=null, action="distData") {
	Map cmdBody = [
		method: "multipleRequest",
		params: [
			requests:[
				request,
				[method: "get_device_info"]]]]
	securePassthrough(cmdBody, async, method, action)
}

def securePassthrough(cmdBody, async=true, reqData=null, action = "distData") {
	logDebug("securePassthrough: [cmdBody: ${cmdBody}, async: ${async}]")
	cmdBody = JsonOutput.toJson(cmdBody).toString()
	def uri = "http://${getDataValue("deviceIp")}/app?token=${deviceToken}"
	Map reqBody = [method: "securePassthrough", params: [request: encrypt(cmdBody, getAesKey())]]
	if (async) {
		asyncPost(uri, reqBody, action, deviceCookie, reqData)	
	} else {
		def respData = syncPost(uri, reqBody, deviceCookie)
		Map logData = [reqDni: reqDni]
		def cmdResp = "ERROR"
		if (respData.respStatus == "OK") {
			logData << [respStatus: "OK"]
			respData = respData.data.result.response
			cmdResp = new JsonSlurper().parseText(decrypt(respData, getAesKey()))
		} else {
			logData << respData
		}
		if (logData.respStatus == "OK") {
			logDebug("securePassthrough - SYNC: ${logData}")
		} else {
			logWarn("securePassthrough - SYNC: ${logData}")
		}
		return cmdResp
	}
}

//	===== AES Methods =====
def encrypt(plainText, keyData) {
	byte[] keyenc = keyData[0..15]
	byte[] ivenc = keyData[16..31]
	
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(keyenc, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivenc)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	String result = cipher.doFinal(plainText.getBytes("UTF-8")).encodeBase64().toString()
	return result.replace("\r\n","")
}

def decrypt(cypherText, keyData) {
	byte[] keyenc = keyData[0..15]
	byte[] ivenc = keyData[16..31]

    byte[] decodedBytes = cypherText.decodeBase64()
    def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(keyenc, "AES")
    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivenc))
	String result = new String(cipher.doFinal(decodedBytes), "UTF-8")
	return result
}

//	===== Sync comms for device update =====
def syncPost(uri, reqBody, cookie=null) {
	def reqParams = [
		uri: uri,
		headers: [
			Cookie: cookie
		],
		body : new JsonBuilder(reqBody).toString()
	]
	logDebug("syncPost: [cmdParams: ${reqParams}]")
	Map respData = [:]
	try {
		httpPostJson(reqParams) {resp ->
			respData << [status: resp.status, data: resp.data]
			if (resp.status == 200) {
				respData << [respStatus: "OK", headers: resp.headers]
			} else {
				respData << [respStatus: "Return Error"]
			}
		}
	} catch (e) {
		respData << [status: "HTTP Failed", data: e]
	}
	return respData
}

def asyncPost(uri, reqBody, parseMethod, cookie=null, reqData=null) {
	Map logData = [:]
	def reqParams = [
		uri: uri,
		requestContentType: 'application/json',
		contentType: 'application/json',
		headers: [
			Cookie: cookie
		],
		timeout: 5,
		body : new groovy.json.JsonBuilder(reqBody).toString()
	]
	try {
		asynchttpPost(parseMethod, reqParams, [data: reqData])
//		asynchttpPost(parseMethod, reqParams, reqData)
		logData << [status: "OK"]
	} catch (e) {
		logData << [status: e, reqParams: reqParams]
	}
	if (logData.status == "OK") {
		logDebug("asyncPost: ${logData}")
	} else {
		logWarn("asyncPost: ${logData}")
	}
}

//	===== Initial Parse Methods =====

def distData(resp, data) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		switch(data.data) {
			case "pollChildren":
				childPollParse(cmdResp.cmdResp.result.child_device_list)
				break
			case "refreshChildren":
				childRefreshParse(cmdResp.cmdResp.result.child_device_list)
				break
			default:
				def devData = cmdResp.cmdResp.result
				if (devData.responses) {
					devData = devData.responses.find{it.method == "get_device_info"}.result
					deviceParse(devData, data.data)
				}
		}
	}
}

def parseData(resp) {
	def logData = [:]
	try {
		logData << [respDataLength: resp.data.length()]
		resp = new JsonSlurper().parseText(resp.data)
		def cmdResp = new JsonSlurper().parseText(decrypt(resp.result.response, getAesKey()))
		logData << [cmdResp: cmdResp]
		if (cmdResp.error_code == 0) {
			logData << [status: "OK"]
		} else {
			logData << [status: "Error from device response"]
		}
		state.commsCheck = false
	} catch (e) {
		logData << [status: e, data: resp]
	}
	if (logData.status == "OK") {
		logDebug("parseData: ${logData}")
	} else {
		logWarn("parseData: ${logData}")
	}
	return logData
}
