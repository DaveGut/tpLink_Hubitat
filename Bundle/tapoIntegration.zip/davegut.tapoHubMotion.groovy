/*	Tapo Hub Trigger Motion Sensor Child Device
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
def type() {return "tapoHub-Motion" }
def driverVer() { return parent.driverVer() }

metadata {
	definition (name: type(), namespace: "davegut", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tapoHubitat/main/Drivers/${type()}.groovy")
	{
		capability "Motion Sensor"
		attribute "reportInterval", "number"
		attribute "lowBattery", "string"
		attribute "status", "string"
	}
	preferences {
		input ("sensorReportInt", "enum", title: "Sensor report interval (secs) (impacts battery life)",
			   options: ["4", "8", "12", "16"], 
			   defaultValue: "8")
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << [sensorReportInt: setReportInterval()]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

//	Parse Methods
def devicePollParse(childData, data=null) {
	childData = childData.find{ it.mac == device.getDeviceNetworkId() }
	def motion = "inactive"
	if (childData.detected) { motion = "active" }
	if (device.currentValue("motion") != motion) {
		updateAttr("motion", motion)
	}
}

def parseTriggerLog(resp, data) {
	//	Kept to preclude accidental error.  TriggerLogs not used for this type.
}

//	Library Inclusion
#include davegut.tapoSensorCommon
#include davegut.Logging
