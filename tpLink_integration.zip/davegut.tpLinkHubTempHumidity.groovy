/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/

metadata {
	definition (name: "tpLink Hub TempHumidity", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_tempHumidity.groovy")
	{
		capability "Refresh"
		capability "Sensor"
		capability "Temperature Measurement"
		attribute "humidity", "number"
		attribute "lowBattery", "string"
	}
	preferences {
		input ("getTriggerLogs", "bool", title: "Get Device's last 20 trigger logs", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { runIn(1, updated) }

def updated() {
	if (getTriggerLogs == true) {
		getTriggerLog(20)
	} else {
		unschedule()
		def logData = [method: "updated"]
		logData << setLogsOff()
		logData << [status: "OK"]
		logInfo(logData)
	}
	pauseExecution(5000)
}

def refresh() { parent.refresh() }

//	Parse Methods
def parseDevData(childData) {
	try {
		if (device.currentValue("temperature") != childData.current_temperature ||
			device.currentValue("humidity") != childData.current_humidity) {
			sendEvent(name: "temperature", value: childData.current_temperature,
					  unit: childData.current_temp_unit)
			sendEvent(name: "humidity", value: childData.current_humidity)
		}
		updateAttr("lowBattery", childData.at_low_battery.toString())
	} catch (err) {
		Map logData = [method: "devicePollParse", status: "ERROR",
					   childData: childData, error: err]
		logWarn(logData)
	}
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

def getTriggerLog(count = 1) {
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_trigger_logs",
				params: [page_size: count,"start_id": 0]
			]
		]
	]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "distTriggerLog")
}

def parseTriggerLog(triggerData, data=null) {
	def triggerLog = triggerData.result.responseData.result
	log.info "<b>TRIGGERLOGS</b>: ${triggerLog.logs}"
	device.updateSetting("getTriggerLogs", [type:"bool", value: false])
}

#include davegut.Logging
