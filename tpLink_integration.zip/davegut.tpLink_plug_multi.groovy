/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_plug_multi", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug_multi.groovy")
	{
		attribute "commsError", "string"
	}
	preferences {
		commonPreferences()
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
		input ("installChild", "bool", title: "Install Child Device (unusual)", defaultValue: true)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() {
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [method: "delayedUpdates"]
	logData << [ledRule: ledRule]
	List requests = [[method: "get_led_info"]]

	logData << [nameSync: nameSync]
	def nickname = device.getLabel().bytes.encodeBase64().toString()
	requests << [method: "set_device_info", params: [nickname: nickname]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "delayedUpdates", "parseUpdates")
	if (installChild) {
		runIn(5, installChildDevices)
	}
	logInfo(logData)
	runIn(10, refresh)
}

def deviceParse(resp, data=null) {
	Map logData = [method: "deviceParse"]
	def respData = parseData(resp)
	try {
		def childrenData = respData.cmdResp.result.responses.find { it.method == "get_child_device_list" }
		def children = getChildDevices()
		children.each { child ->
			def devId = child.getDataValue("deviceId")
			def childData = childrenData.result.child_device_list.find{ it.device_id == devId }
			child.parseDevData(childData)
		}
		logData << [status: "OK"]
	} catch (err) {
		logData << [status: "ERROR", error: err]
	}
	logDebug(logData)
}

//	===== Child Command Response =====
def childRespDist(resp, data) {
	def respData = parseData(resp)
	def child = getChildDevice(data.data)
	respData.cmdResp.result.responseData.result.responses.each {
		if (it.method == "get_device_info") {
			child.parseDevData(it.result)
		}
	}
}

def childSettingsDist(resp, data) {
	def respData = parseData(resp)
	def child = getChildDevice(data.data)
	respData.cmdResp.result.responseData.result.responses.each {
		if (it.method == "get_device_info") {
			child.childSettingsParse(it.result)
		}
	}
}

//	===== Child Installation =====
def installChildDevices() {
	Map logData = [method: "installChildDevices"]
	asyncSend([method: "get_child_device_list"], "installChildDevices", "installChildren")
	logInfo(logData)
}

def installChildren(resp, data=null) {
	Map logData = [method: "installChildren"]
	def respData = parseData(resp)
	def children = respData.cmdResp.result.child_device_list
	children.each {
		String childDni = "${it.mac}-${it.position}"
		Map instData = [childDni: childDni]
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			instData << [status: "device already installed"]
		} else {
			String model = it.model
			String category = it.category
			String driver = "tpLink_plug_multi_child"
			String deviceId = it.device_id
			instData << [model: model, category: category, driver: driver] 
			try {
				addChildDevice(nameSpace(), driver, childDni, 
							   [label: alias, name: model, deviceId : deviceId])
				instData << [status: "Installed"]
			} catch (err) {
				instData << [status: "FAILED", error: err]
			}
		}
		logData << ["${alias}": instData]
		pauseExecution(2000)
	}
	device.updateSetting("instChildren", [type: "bool", value: false])
	logInfo(logData)
}

//	===== Include Libraries =====
#include davegut.lib_tpLink_common
#include davegut.Logging
