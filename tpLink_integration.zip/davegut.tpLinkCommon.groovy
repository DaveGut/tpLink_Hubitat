library (
	name: "tpLinkCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common driver methods including capability Refresh and Configuration methods",
	category: "utilities",
	documentationLink: ""
)

capability "Refresh"
capability "Configuration"
attribute "commsError", "string"

def commonPreferences() {
	List pollOptions = ["5 sec", "10 sec", "30 sec", "5 min", "10 min", "15 min", "30 min"]
	input ("pollInterval", "enum", title: "Poll/Refresh Interval",
		   options: pollOptions, defaultValue: "30 min")
	input ("rebootDev", "bool", title: "Reboot Device then run Save Preferences", defaultValue: false)
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	updateAttr("commsError", "false")
	state.errorCount = 0
	state.lastCmd = ""
	state.eventType = "digital"
	Map logData = [configure: configure(false)]
	return logData
}

def commonUpdated() {
	def commsErr = device.currentValue("commsError")
	Map logData = [commsError: commsErr]
	if (commsErr == "true") {
		logData << [configure: configure(true)]
	}
	if (rebootDev == true) {
		runIn(1, rebootDevice)
		device.updateSetting("rebootDev",[type:"bool", value: false])
		pauseExecution(15000)
	}
	updateAttr("commsError", "false")
	state.lastCmd = ""
	logData << [pollInterval: setPollInterval()]
	logData << [logging: setLogsOff()]
	logData << [updateDevSettings: updDevSettings()]
	pauseExecution(5000)
	return logData
}

def rebootDevice() {
	asyncSend([method: "device_reboot"], "rebootDevice", "rebootParse")
}
def rebootParse(resp, data=null) {
	def respData = parseData(resp).cmdResp
	Map logData = [method: "rebootParse", data: data, respData: respData]
	logInfo(logData)
}

def updDevSettings() {
	Map logData = [method: "updDevSettings"]
	List requests = []
	if (ledRule != null) {
		logData << [ledRule: ledRule]
		requests << [method: "get_led_info"]
	}
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "updDevSettings", "parseUpdates")
	pauseExecution(5000)
	return logData
}

//	===== Capability Configuration =====
def configure(checkApp = true) {
	Map logData = [method: "configure", checkApp: checkApp]
	if (checkApp == true) {
		logData << [updateData: parent.tpLinkCheckForDevices(5)]
	}
	def action = updateDeviceData()
	unschedule()
	logData << [handshake: deviceHandshake()]
	runEvery3Hours(deviceHandshake)
	logData << [handshakeInterval: "3 Hours"]
	logData << [pollInterval: setPollInterval()]
	logData << [logging: setLogsOff()]
	runIn(2, initSettings)
	logInfo(logData)
	return logData
}

def initSettings() {
	Map logData = [method: "initSettings"]
	Map prefs = state.compData
	List requests = []
	if (ledRule) {
		requests << [method: "get_led_info"]
	}
	if (getDataValue("type") == "Plug EM") { requests << [method: "get_energy_usage"] }
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "initSettings", "parseUpdates")
	return logData
}

def setPollInterval(pInterval = pollInterval) {
	String devType = getDataValue("type")
	def pollMethod = "minRefresh"
	if (devType == "Plug EM") {
		pollMethod = "plugEmRefresh"
	} else if (devType == "Hub"|| devType == "Parent") {
		pollMethod = "parentRefresh"
	}
	
	if (pInterval.contains("sec")) {
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", pollMethod)
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", pollMethod)
	}
	return pInterval
}

//	===== Data Distribution (and parse) =====
def parseUpdates(resp, data = null) {
	Map logData = [method: "parseUpdates", data: data]
	def respData = parseData(resp)
	def cmdResp = parseData(resp).cmdResp
	if (cmdResp != null && cmdResp.error_code == 0) {
		cmdResp.result.responses.each {
			if (it.error_code == 0) {
				if (!it.method.contains("set_")) {
					distGetData(it, data)
				} else {
					logData << [devMethod: it.method]
					logDebug(logData)
				}
			} else {
				logData << ["${it.method}": [status: "cmdFailed", data: it]]
				logWarn(logData)
			}
		}
	} else {
		logData << [status: "invalidRequest", respData: respData,
					respProps: [headers: resp.headers, status: resp.status,
								warningMessages: resp.warningMessages]]
		logWarn(logData)				
	}
}

def distGetData(devResp, data) {
	switch(devResp.method) {
		case "get_device_info":
			parse_get_device_info(devResp.result, data)
			break
		case "get_energy_usage":
			parse_get_energy_usage(devResp.result, data)
			break
		case "get_child_device_list":
			parse_get_child_device_list(devResp.result, data)
			break
		case "get_alarm_configure":
			parse_get_alarm_configure(devResp.result, data)
			break
		case "get_led_info":
			parse_get_led_info(devResp.result, data)
			break
		default:
			Map logData = [method: "distGetData", data: data,
						   devMethod: devResp.method, status: "unprocessed"]
			logDebug(logData)
	}
}

def parse_get_led_info(result, data) {
	Map logData = [method: "parse_get_led_info", data: data]
	if (ledRule != result.led_rule) {
		Map request = [
			method: "set_led_info",
			params: [
				led_rule: ledRule,
				night_mode: [
					night_mode_type: result.night_mode.night_mode_type,
					sunrise_offset: result.night_mode.sunrise_offset, 
					sunset_offset:result.night_mode.sunset_offset,
					start_time: result.night_mode.start_time,
					end_time: result.night_mode.end_time
				]]]
		asyncSend(request, "delayedUpdates", "parseUpdates")
		device.updateSetting("ledRule", [type:"enum", value: ledRule])
		logData << [status: "updatingLedRule"]
	}
	logData << [ledRule: ledRule]
	logDebug(logData)
}

//	===== Capability Refresh =====
def refresh() {
	def type = getDataValue("type")
	if (type == "Plug EM") {
		plugEmRefresh()
	} else if (type == "Hub" || type == "Parent") {
		parentRefresh()
	} else {
		minRefresh()
	}
}

def plugEmRefresh() {
	List requests = [[method: "get_device_info"]]
	requests << [method:"get_energy_usage"]
	asyncSend(createMultiCmd(requests), "plugEmRefresh", "parseUpdates")
}

def parentRefresh() {
	List requests = [[method: "get_device_info"]]
	requests << [method:"get_child_device_list"]
	asyncSend(createMultiCmd(requests), "parentRefresh", "parseUpdates")
}

def minRefresh() {
	List requests = [[method: "get_device_info"]]
	asyncSend(createMultiCmd(requests), "minRefresh", "parseUpdates")
}

def emUpdate() { }
def emRefresh() { plugEmRefresh() }
def commonRefresh() { minRefresh() }
def deviceLogin() { deviceHandshake() }

def sendDevCmd(requests, data, action) {
	asyncSend(createMultiCmd(requests), data, action)
}

def sendSingleCmd(request, data, action) {
	asyncSend(request, data, action)
}

def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def nullParse(resp, data) { }

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

//	===== Check/Update device data =====
//	Called if Driver/App version has changed from app or from configure.
def updateDeviceData() {
	def currVer = getDataValue("version")
	Map logData = [method: "updateDeviceData", currentVersion: currVer, 
				   newVersion: version()]
	if (currVer != version()) {
	//	The below data must be updated on each major version change.
		def devData = parent.getChildDevice(device.getDeviceNetworkId())
		logData << [capability: devData.data.capability]
		if (devData != null && devData.data.capability != null) {
			String tpLinkType
			String type
			switch (devData.data.capability) {
				case "bulb_dimmer":
					tpLinkType = "SMART.TAPOBULB"
					type = "Dimmer"
					break
				case "bulb_color":
					tpLinkType = "SMART.TAPOBULB"
					type = "Color Bulb"
					break
				case "bulb_lightStrip":
					tpLinkType = "SMART.TAPOBULB"
					type = "Light Strip"
					break
				case "plug":
					tpLinkType = "SMART.TAPOPLUG"
					type = "Plug"
					break
				case "plug_dimmer":
					tpLinkType = "SMART.TAPOPLUG"
					type = "Dimmer"
					break
				case "plug_multi":
					tpLinkType = "SMART.TAPOPLUG"
					type = "Parent"
					break
				case "plug_em":
					tpLinkType = "SMART.TAPOPLUG"
					type = "Plug EM"
					break
				case "hub":
					tpLinkType = "SMART.TAPOHUB"
					type = "Hub"
					break
				case "robovac":
					tpLinkType = "SMART.TAPOROBOVAC"
					type = "Robovac"
					break
				default:
					break
			}
			updateDataValue("tpLinkType", tpLinkType)
			updateDataValue("type", type)
			removeDataValue("capability")
		} else {
			logData << [status: "noUpdates"]
		}
		updateDataValue("version", version())	
	}
	logInfo(logData)
	return
}

//	===== Device Handshake =====
def deviceHandshake() {
	def protocol = getDataValue("protocol")
	Map logData = [method: "deviceHandshake", protocol: protocol]
	if (protocol == "KLAP") {
		klapHandshake()
	} else if (protocol == "AES") {
		aesHandshake()
	} else {
		logData << [ERROR: "Protocol not supported"]
	}
	pauseExecution(5000)
	logDebug(logData)
	return logData
}
