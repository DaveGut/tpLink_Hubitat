/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Verified on T300 Leak Sensor.
=================================================================================================*/

metadata {
	definition (name: "TpLink Hub Leak", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_leak.groovy")
	{
		capability "Refresh"
		capability "Water Sensor"
		capability "Battery"
		attribute "lowBattery", "string"
	}
	preferences {
		input ("getTriggerLogs", "bool", title: "Get Device's last 20 trigger logs", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { runIn(1, updated) }

def updated() {
	if (getTriggerLogs == true) {
		getTriggerLog(20)
	} else {
		unschedule()
		def logData = [method: "updated"]
		logData << setLogsOff()
		logInfo(logData)
	}
	pauseExecution(5000)
}

def refresh() { parent.refresh() }

def parseDevData(childData) {
	try {
		def wetDry = "wet"
		if (childData.water_leak_status == "water_dry") { wetDry = "dry" }
		updateAttr("water", wetDry)
		updateAttr("lowBattery", childData.at_low_battery.toString())
		updateAttr("battery", childData.battery_percentage)
	} catch (err) {
		logWarn([method: "parseDevData", status: "FAILED", error: err])
	}
}

def getTriggerLog(count = 1) {
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_trigger_logs",
				params: [page_size: count,"start_id": 0]
			]
		]
	]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "distTriggerLog")
}

def parseTriggerLog(triggerData, data=null) {
	def triggerLog = triggerData.result.responseData.result
	log.info "<b>TRIGGERLOGS</b>: ${triggerLog.logs}"
	device.updateSetting("getTriggerLogs", [type:"bool", value: false])
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

#include davegut.Logging
