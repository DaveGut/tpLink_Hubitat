/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Name Change to TpLink Parent.

Verified on TP25(US) and P306(US)
=================================================================================================*/

metadata {
	definition (name: "TpLink Parent", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_parent.groovy")
	{
	}
	preferences {
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
		input ("installChild", "bool", title: "Install Child Devices", defaultValue: true)
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	if (installChild) {
		logData << [children: "installing"]
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def updated() { 
	Map logData = [method: updated, installChild: installChild,
				   commonUpdated: commonUpdated()]
	if (installChild) {
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data]
	logDebug(logData)
}

//	===== Child Command Response =====
def parse_get_child_device_list(result, data) {
	Map logData = [method: "get_child_device_list",data: data]
	def children = getChildDevices()
	children.each { child ->
		def devId = child.getDataValue("deviceId")
		def childData = result.child_device_list.find{ it.device_id == devId }
		child.parse_get_device_info(childData, data)
	}
	logData << [status: "OK"]
	logDebug(logData)
}

def childRespDist(resp, data) {
	def respData = parseData(resp).cmdResp
	if (respData.error_code== 0) {
		def child = getChildDevice(data.data)
		if (child != null) {
			child.distChildData(respData.result.responseData.result.responses, data)
		} else {
			logWarn([method: "childRespDist", data: data, status: "notChild"])
		}
	} else {
		logWarn([method: "childRespDist", data: data, error: respData.error_code, status: "errorInResp"])
	}
}

//	===== Include Libraries =====
#include davegut.tpLinkCommon
#include davegut.tpLinkChildInst
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.Logging
