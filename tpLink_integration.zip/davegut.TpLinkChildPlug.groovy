/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Verified on TP25(US) and P306(US)
=================================================================================================*/

metadata {
	definition (name: "TpLink Child Plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_child_plug.groovy")
	{ }
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed"]
	logData << [commonInst: commonInstalled()]
	logInfo(logData)
	runIn(1, updated)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(devData, data = null) {
	Map logData = [method: "parse_get_device_info"]
	try {
		def onOff = "off"
		if (devData.device_on == true) { onOff = "on" }
		if (device.currentValue("switch") != onOff) {
			sendEvent(name: "switch", value: onOff, type: state.eventType)
			state.eventType = "physical"
		}
		logData << [onOff: onOff, status: "OK"]
		logDebug(logData)
	} catch (err) {
		logData << [status: "FAILED", error: err]
		logWarn(logData)
	}
}

#include davegut.tpLinkCapSwitch
#include davegut.tpLinkChildCommon
#include davegut.Logging
