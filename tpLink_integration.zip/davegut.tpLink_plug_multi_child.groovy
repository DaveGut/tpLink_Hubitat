/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_plug_multi_child", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug_multi_child.groovy")
	{
		capability "Refresh"
		capability "Switch"
	}
	preferences {
		input ("nameSync", "enum", title: "Synchronize Names",
			   options: ["none": "Don't synchronize",
						 "device" : "TP-Link device name master",
						 "Hubitat" : "Hubitat label master"],
			   defaultValue: "none")
		input ("defState", "enum", title: "Power Loss Default State",
			   options: ["lastState", "on", "off"], defaultValue: "lastState")
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { runIn(5, updated) }

def updated() {
	unschedule()
	Map logData = [method: "updated"]
	setDevPreferences()
	logInfo(logData)
}

def on() { setPower(true) }

def off() { setPower(false) }

def setPower(onOff) {
	Map logData = [method: "setPower", onOff: onOff]
	state.eventType = "digital"
	List requests = [[method: "set_device_info", params: [device_on: onOff]]]
	requests << [method: "get_device_info"]
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: createMultiCmd(requests)]]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "childRespDist")
	logDebug(logData)
}

def parseDevData(devData) {
	Map logData = [method: "parseDevData"]
	try {
		def onOff = "off"
		if (devData.device_on == true) { onOff = "on" }
		if (device.currentValue("switch") != onOff) {
			sendEvent(name: "switch", value: onOff, type: state.eventType)
			state.eventType = "physical"
		}
		logData << [onOff: onOff, status: "OK"]
	} catch (err) {
		logData << [status: "FAILED", error: err]
	}
	logDebug(logData)
}

def refresh() { parent.refresh() }

//	===== Device Preferences =====
def setDevPreferences() {
	Map logData = [method: "setDevPreferences"]
	List requests = []
	logData << [defState: defState]
	def type = "last_states"
	def state = []
	if (defState == "on") {
		type = "custom"
		state = [on: true]
	} else if (defState == "off") {
		type = "custom"
		state = [on: false]
	}
	logData << [nameSync: nameSync]
	if (nameSync == "Hubitat") {
		def nickname = device.getLabel().bytes.encodeBase64().toString()
		requests << [method: "set_device_info",
					 params: [
						 default_states: [type: type, state: state],
						 nickname: nickname]]
	} else {
		requests << [method: "set_device_info",
					 params: [
						 default_states: [type: type, state: state]]]
	}
	requests << [method: "get_device_info"]
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: createMultiCmd(requests)]]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "childSettingsDist")
	logInfo(logData)
}

def childSettingsParse(devData) {
	Map logData = [method: "childSettingsParse"]
	def defaultStates = devData.default_states
	def newState = "lastState"
	if (defaultStates.type == "custom"){
		newState = "off"
		if (defaultStates.state.on == true) {
			newState = "on"
		}
	}
	device.updateSetting("defState", [type: "enum", value: newState])
	logData << [defState: newState]

	if (nameSync == "device") {
		byte[] plainBytes = devData.nickname.decodeBase64()
		String label = new String(plainBytes)
		device.setLabel(label)
		logData << [nickname: devData.nickname, label: label]
	}
	device.updateSetting("nameSync", [type: "enum", value: "none"])
	logInfo(logData)
	parseDevData(devData)
}

def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

#include davegut.Logging
