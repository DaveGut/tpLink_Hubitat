library (
	name: "lib_tpLink_discovery",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common tpLink Smart Discovery Methods",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.Cipher
import java.security.KeyFactory
import java.util.Random
import java.security.MessageDigest

//	===== UPDATED =====
def findTpLinkDevices(action, timeout) {
	Map logData = [method: "findTpLinkDevices", action: action, timeOut: timeout]
	def start = state.hostArray.min().toInteger()
	def finish = state.hostArray.max().toInteger() + 1
	logData << [hostArray: state.hostArray, pollSegment: state.segArray]
	List deviceIPs = []
	state.segArray.each {
		def pollSegment = it.trim()
		for(int i = start; i < finish; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
		sendLanCmd(deviceIPs.join(','), "20002", cmdData, action, timeout)
	}
	pauseExecution(2000 * timeout)
	return logData
}

def getSmartLanData(response) {
	logDebug("getSmartLanData: responses returned from devices")
	List discData = []
	if (response instanceof Map) {
		Map devData = getDiscData(response)
		if (devData.status == "OK") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	getAllSmartDeviceData(discData)
}

def getDiscData(response) {
	Map devData = [method: "getDiscData"]
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			Map payload = new JsonSlurper().parseText(payloadString).result
			List supported = supportedProducts()
			if (supported.contains(payload.device_type)) {
				def protocol = payload.mgt_encrypt_schm.encrypt_type
				def port = payload.mgt_encrypt_schm.http_port
				def dni = payload.mac.replaceAll("-", "")
				def baseUrl = "http://${payload.ip}:${payload.mgt_encrypt_schm.http_port}/app"
				if (payload.device_type == "SMART.TAPOROBOVAC") {
					baseUrl = "https://${payload.ip}:${payload.mgt_encrypt_schm.http_port}"
					protocol = "vacAes"
				}
				devData << [
					type: payload.device_type, model: payload.device_model,
					baseUrl: baseUrl, dni: dni, devId: payload.device_id, 
					ip: payload.ip, port: port, protocol: protocol, status: "OK"]
			} else {
				devData << [type: payload.device_type, model: payload.device_model, 
							status: "INVALID", reason: "Device not supported."]
			}
		}
		logDebug(devData)
	} catch (err) {
		devData << [status: "INVALID", respData: repsData, error: err]
		logWarn(devData)
	}
	return devData
}

def getAllSmartDeviceData(List discData) {
	Map logData = [method: "getAllSmartDeviceData"]
	discData.each { Map devData ->
		Map cmdResp = getSmartDeviceData(devData.baseUrl, devData.protocol)
		if (cmdResp.error || cmdResp == null) {
			logData << [status: "respError", data: cmdResp]
			logWarn(logData)
		} else {
			addToDevices(devData, cmdResp.result)
		}
		pauseExecution(200)
	}
}

def getSmartDeviceData(baseUrl, protocol) {
	Map cmdResp = [:]
	if (protocol == "KLAP") {
		cmdResp = getKlapDeviceData(baseUrl)
	} else if (protocol == "AES") {
		cmdResp = getAesDeviceData(baseUrl)
	} else if (protocol == "vacAes") {
		cmdResp = getVacDeviceData(baseUrl)
	}
	return cmdResp
}

def getKlapDeviceData(baseUrl) {
	Map logData = [method: "getKlapDeviceData", baseUrl: baseUrl]
	Map cmdResp = [:]
	Map sessionData = klapLogin(baseUrl, localHash.decodeBase64())
	logData << [sessionData: sessionData]
	if (sessionData.status == "OK") {
		logData << [sessionDataStatus: sessionData.status]
		def cmdStr = JsonOutput.toJson([method: "get_device_info"]).toString()
		state.seqNo = sessionData.seqNo
		byte[] encKey = sessionData.encKey
		byte[] encIv = sessionData.encIv
		byte[] encSig = sessionData.encSig
		Map encryptedData = klapEncrypt(cmdStr.getBytes(), encKey, encIv, encSig)
		def uri = "${baseUrl}/request?seq=${encryptedData.seqNumber}"
		Map resp = klapSyncPost(uri, encryptedData.cipherData, sessionData.cookie)
		if (resp.status == 200) {
			try {
				byte[] cipherResponse = resp.data[32..-1]
				def clearResp =  klapDecrypt(cipherResponse, encKey, encIv)
				cmdResp = new JsonSlurper().parseText(clearResp)
			} catch (err) {
				cmdResp = [error: "cryptoError", method: "getKlapDeviceData"]
				logData << [status: "cryptoError", error: "Error decrypting response", data: err]
				logWarn(logData)
			}
		} else {
			cmdResp = [error: "postError", method: "getKlapDeviceData"]
			logData << [status: "postError", postJsonData: resp]
			logWarn(logData)
		}
	} else {
		cmdResp = [error: "credentialError", method: "getKlapDeviceData"]
		logData << [respStatus: "FAILED", reason: "Login process failure.  Check credentials."]
		logWarn(logData)
	}
	return cmdResp
}

def getAesDeviceData(baseUrl) {
	Map logData = [method: "getAesDeviceData", baseUrl: baseUrl]
	Map cmdResp = [:]
	Map sessionData = aesLogin(baseUrl, encPassword, encUsername)
	if (sessionData.status == "OK") {
		byte[] encKey = sessionData.encKey
		byte[] encIv = sessionData.encIv
		def cmdStr = JsonOutput.toJson([method: "get_device_info"]).toString()
		Map reqBody = [method: "securePassthrough",
					   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
		def uri = "${baseUrl}?token=${sessionData.token}"
		Map resp = aesSyncPost(uri, reqBody, sessionData.cookie)
		if (resp.status == 200) {
			try {
				def clearResp = aesDecrypt(resp.data.result.response, encKey, encIv)
				cmdResp = new JsonSlurper().parseText(clearResp)
			} catch (err) {
				cmdResp = [error: "cryptoError", method: "getAesDeviceData"]
				logData << [status: "cryptoError", error: "Error decrypting response", data: err]
				logWarn(logData)
			}
		} else {
			cmdResp = [error: "postError", method: "getAesDeviceData"]
			logData << [status: "postError", postJsonData: resp]
			logWarn(logData)
		}
	} else {
		cmdResp = [error: "credentialError", method: "getAesDeviceData"]
		logData << [respStatus: "FAILED", reason: "Check Credentials"]
		logWarn(logData)
	}
	return cmdResp
}

def getVacDeviceData(baseUrl) {
	Map logData = [method: "getVacDeviceData", baseUrl: baseUrl]
	Map cmdResp = [:]
	Map loginData = vacLogin(baseUrl)
	logData << [loginData: loginData]
	if (loginData.token != "ERROR") {
		Map reqBody = [method: "get_device_info"]
		def uri = "${baseUrl}/?token=${loginData.token}"
		Map resp = aesSyncPost(uri, reqBody)
		if (resp.status == 200) {
			try {
				if (resp.data.error_code == 0) {
					cmdResp = resp.data
				} else {
					cmdResp = [error: "respError", method: "getVacDeviceData"]
					logData << [status: "responseError", error: "most like credentials", data: resp.data]
					logWarn(logData)
				}
			} catch (err) {
				cmdResp = [error: "response", method: "getVacDeviceData"]
				logData << [status: "responseError", error: "return data incomplete", data: err]
				logWarn(logData)
			}
		} else {
			cmdResp = [error: "response", method: "getVacDeviceData"]
			logData << [status: "postError", postJsonData: resp.properties]
			logWarn(logData)
		}
	} else {
		cmdResp = [error: "tokenError", method: "getVacDeviceData"]
		logData << [status: "tokenError"]
		logWarn(logData)
	}
	return cmdResp
}

def vacLogin(baseUrl) {
	Map logData = [method: "deviceLogin", uri: baseUrl]
	Map cmdBody = [method: "login",
				   params: [hashed: true, 
							password: encPasswordVac,
							username: userName]]
	def loginResp = aesSyncPost(baseUrl, cmdBody)
	def token = [token: "ERROR"]
	if (loginResp.status == 200 && loginResp.data && loginResp.data.error_code == 0) {
		logData << [status: loginResp.status]
		token = loginResp.data.result.token
	} else {
		logData << [status: "FAILED", reason: "HTTP Response Status"]
	}
	logData << [token: token]
	return logData
}

def addToDevices(devData, cmdResp) {
	String dni = devData.dni
	Map deviceData = [:]
	String deviceType = devData.type
	byte[] plainBytes = cmdResp.nickname.decodeBase64()
	def alias = new String(plainBytes)
	if (alias == "") {
		alias = devData.model
	}
	deviceData << [protocol: devData.protocol]
	deviceData << [ip: devData.ip]
	deviceData << [port: devData.port]
	deviceData << [alias: alias]
	deviceData << [model: devData.model]
	deviceData << [baseUrl: devData.baseUrl]
	String capability = "newType"
	String feature
	if (deviceType.contains("BULB")) {
		capability = "bulb_dimmer"
		if (cmdResp.color_temp_range) {
			deviceData << [ctLow: cmdResp.color_temp_range[0]]
			deviceData << [ctHigh: cmdResp.color_temp_range[1]]
			if (cmdResp.color_temp_range[0] < cmdResp.color_temp_range[1]) {
				capability = "bulb_color"
			} else if (cmdResp.lighting_effect) {
				capability = "bulb_lightStrip"
			}
		}
	} else if (deviceType.contains("SWITCH") || deviceType.contains("PLUG")) {
		capability = "plug"
		if (cmdResp.brightness) {
			capability = "plug_dimmer"
		}
		if (cmdResp.power_protection_status) {
			capability = "plug_em"
		}
		if (!cmdResp.default_states) {		// parent plug does not have default_states
			capability = "plug_multi"
		}
	} else if (deviceType.contains("HUB")) {
		capability = "hub"
	} else if (deviceType.contains("ROBOVAC")) {
		capability = "robovac"
	}
	deviceData << [dni: dni]
	deviceData << [type: "tpLink_${capability}"]
	deviceData << [capability: capability]
	state.devices << ["${dni}": deviceData]
	logInfo("[method: addToDevices, <b>${deviceData.alias}</b>: [${dni}: ${deviceData}]]")
}

//	===== tpLink Communications
def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def syncSend(cmdBody) {
	Map cmdResp = [:]
	if (getDataValue("protocol") == "KLAP") {
		cmdResp = klapSyncSend(cmdBody)
	} else {
		cmdResp = aesSyncSend(cmdBody)
	}
	return cmdResp
}

def klapSyncSend(cmdBody) {
	Map logData = [method: "klapSyncSend", cmdBody: cmdBody]
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	byte[] encSig = new JsonSlurper().parseText(encSig)
	String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()
	Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv, encSig)
	def uri = "${getDataValue("baseUrl")}/request?seq=${encryptedData.seqNumber}"
	def resp = klapSyncPost(uri, encryptedData.cipherData, cookie)
	Map cmdResp = [status: "ERROR"]
	if (resp.status == 200) {
		try {
			byte[] cipherResponse = resp.data[32..-1]
			def clearResp =  klapDecrypt(cipherResponse, encKey, encIv)
			cmdResp = new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [status: "cryptoError", error: "Error decrypting response", data: err]
		}
	} else {
		logData << [status: "postJsonError", postJsonData: resp]
	}
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def aesSyncSend(cmdBody) {
	Map logData = [method: "aesSyncSend", cmdBody: cmdBody]
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	def uri = "${getDataValue("baseUrl")}?token=${token}"
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
	def resp = aesSyncPost(uri, reqBody, cookie)
	Map cmdResp = [status: "ERROR"]
	if (resp.status == 200) {
		try {
			def clearResp = aesDecrypt(resp.data.result.response, encKey, encIv)
			cmdResp = new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [status: "cryptoError", error: "Error decrypting response", data: err]
		}
	} else {
		logData << [status: "postJsonError", postJsonData: resp]
	}
	if (logData.status == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return cmdResp
}

def xxxxxxxxasyncSend(cmdBody, method, action) {
	Map cmdData = [cmdBody: cmdBody, method: method, action: action]
	state.lastCmd = cmdData
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	if (getDataValue("protocol") == "KLAP") {
		byte[] encSig = new JsonSlurper().parseText(encSig)
		String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv, encSig)
		def uri = "${getDataValue("baseUrl")}/request?seq=${encryptedData.seqNumber}"
		asyncPost(uri, encryptedData.cipherData, "application/octet-stream",
					  action, cookie, method)
	} else {
		def uri = "${getDataValue("baseUrl")}?token=${token}"
		def cmdStr = JsonOutput.toJson(cmdBody).toString()
		Map reqBody = [method: "securePassthrough",
					   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
		def body = new groovy.json.JsonBuilder(reqBody).toString()
		asyncPost(uri, body, "application/json", 
					  action, cookie, method)
	}
}

//	===== HTTP POST Methods =====
def klapSyncPost(uri, byte[] body, cookie = null) {
	def reqParams = [
		uri: uri,
		body: body,
		contentType: "application/octet-stream",
		requestContentType: "application/octet-stream",
		headers: [
			"Cookie": cookie,
		],
		ignoreSSLIssues: true,
		timeout: 8
	]
	Map respData = [method: "klapSyncPost", uri: uri, cookie: cookie]
	try {
		httpPost(reqParams) { resp ->
			respData << [status: resp.status]
			if (resp.status == 200) {
				byte[] data = []
				if (resp.data != null) {
					data = parseInputStream(resp.data)
				}
				respData << [data: data, headers: resp.headers]
			} else {
				respData << [properties: resp.properties]
			}
		}
	} catch (err) {
		respData << [status: "HTTP Failed", data: err]
	}
	return respData
}
def parseInputStream(data) {
	def dataSize = data.available()
	byte[] dataArr = new byte[dataSize]
	data.read(dataArr, 0, dataSize)
	return dataArr
}

def aesSyncPost(uri, reqBody, cookie=null) {
	def reqParams = [
		uri: uri,
		headers: [
			Cookie: cookie,
		],
		//	body: reqBody,
		body : new JsonBuilder(reqBody).toString(),
		ignoreSSLIssues: true,
		timeout: 8
	]
	Map respData = [method: "aesSyncPost", uri: uri, cookie: cookie]
	try {
		httpPostJson(reqParams) {resp ->
			respData << [status: resp.status]
			if (resp.status == 200 && resp.data.error_code == 0) {
				respData << [data: resp.data, headers: resp.headers]
			} else {
				respData << [properties: resp.properties]
			}
		}
	} catch (err) {
		respData << [status: "HTTP Failed", data: err]
	}
	return respData
}

def xxxxxasyncPost(uri, body, contentType, parseMethod, cookie=null, reqData=null) {
	def reqParams = [
		uri: uri,
		body: body,
		contentType: contentType,
		requestContentType: contentType,
		headers: [
			"Cookie": cookie,
		],
		timeout: 8
	]
	Map logData = [method: "asyncPost", uri: uri, 
				   parseMethod: parseMethod, cookie: cookie, reqData: reqData]
	try {
		asynchttpPost(parseMethod, reqParams, [data: reqData])
		logData << [status: "OK"]
		logDebug(logData)
	} catch (err) {
		logData << [status: "FAILED", error: err, ]
		logWarn(logData)
	}
}
def xxxxxparseData(resp) {
	def logData = [method: "parseData"]
	if (resp.status == 200) {
		try {
			Map cmdResp
			byte[] encKey = new JsonSlurper().parseText(encKey)
			byte[] encIv = new JsonSlurper().parseText(encIv)
			if (getDataValue("protocol") == "KLAP") {
				byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
				cmdResp =  new JsonSlurper().parseText(klapDecrypt(cipherResponse, encKey, encIv))
			} else {
				cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response, encKey, encIv))
			}
			logData << [status: "OK", cmdResp: cmdResp]
			state.errorCount = 0
			setCommsError(false)
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			runIn(1, handleCommsError, [data: "deviceDataParseError"])
		}
	} else {
		logData << [status: "httpFailure(timeout)", data: resp.properties]
		runIn(1, handleCommsError, [data: "httpFailure(timeout)"])
	}
	logDebug(logData)
	return logData
}

//	===== Error Handling =====
def xxxxxhandleCommsError(retryReason) {
	Map logData = [method: "handleCommsError", retryReason: retryReason]
	if (state.lastCmd != "") {
		def count = state.errorCount + 1
		state.errorCount = count
		def cmdData = new JSONObject(state.lastCmd)
		def cmdBody = parseJson(cmdData.cmdBody.toString())
		Map data = [cmdBody: cmdBody, method: cmdData.method, action: cmdData.action]
		logData << [count: count, command: cmdData]
		switch (count) {
			case 1:
				pauseExecution(2000)
				Map loginData = deviceLogin()
				logData << [retryLogin: loginData.loginStatus, action: "retryCommand"]
				runIn(1, delayedPassThrough, [data:data])
				break
			case 2:
				logData << [updateData: parent.tpLinkCheckForDevices(5), action: "retryCommand"]
				runIn(3, delayedPassThrough, [data:data])
			case 3:
				logData << [status: setCommsError(true)]
				logWarn(logData)
				break
			default:
				logData << [status: "retriesDisabled"]
				break
		}
	} else {
		logData << [status: "noCommandToRetry"]
	}
	logInfo(logData)
}

def xxxxxxxdelayedPassThrough(data) {
	asyncSend(data.cmdBody, data.method, data.action)
}

def xxxxxsetCommsError(status) {
	Map logData = [method: "setCommsError", status: status]
	if (device.currentValue("commsError") != status) {
		sendEvent(name: "commsError", value: status)
		if (status == true) {
			logData << [pollInterval: setPollInterval("15 min")]
		} else {
			logData << [pollInterval: setPollInterval()]
		}
	}
	return logData
}

//	===== tpLink Security =====
//	===== KLAP Handshake and Login =====
def klapLogin(baseUrl, localHash) {
	Map logData = [method: "klapLogin"]
	Map sessionData = [protocol: "KLAP"]
	byte[] localSeed = new byte[16]
	new Random().nextBytes(localSeed)
	def status = "ERROR"
	Map handshakeData = klapHandshake(localSeed, localHash, "${baseUrl}/handshake1")
	logData << [handshake: handshakeData]
	sessionData << [handshakeValidated: handshakeData.validated]
	if (handshakeData.validated == true) {
		sessionData << klapCreateSessionData(localSeed, handshakeData.remoteSeed,
											 localHash, handshakeData.cookie)
		Map loginData = klapLoginDevice("${baseUrl}/handshake2", localHash, localSeed, 
										handshakeData.remoteSeed, handshakeData.cookie)
		logData << [loginData: loginData]
		if (loginData.loginSuccess == true) {
			status = "OK"
		}
	}
	sessionData << [status: status]
	if (status != "OK") {
		logInfo(logData)
	}
	return sessionData
}

def klapHandshake(localSeed, localHash, uri) {
	Map handshakeData = [method: "klapHandshake", localSeed: localSeed, uri: uri, localHash: localHash]
	def validated = false
	Map respData = klapSyncPost(uri, localSeed)
	if (respData.status == 200 && respData.data != null) {
		byte[] data = respData.data
		def cookieHeader = respData.headers["set-cookie"].toString()
		def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
		//	Validate data
		byte[] remoteSeed = data[0 .. 15]
		byte[] serverHash = data[16 .. 47]
		byte[] authHashes = [localSeed, remoteSeed, localHash].flatten()
		byte[] localAuthHash = mdEncode("SHA-256", authHashes)
		if (localAuthHash == serverHash) {
			validated = true
			handshakeData << [cookie : cookie]
			handshakeData << [remoteSeed: remoteSeed]
		} else {
			handshakeData << [errorData: "Failed Hash Validation"]
		}
	} else {
		handshakeData << [errorData: respData]
	}
	handshakeData << [validated: validated]
	return handshakeData
}

def klapCreateSessionData(localSeed, remoteSeed, localHash, cookie) {
	Map sessionData = [method: "klapCreateSessionData"]
	//	seqNo and encIv
	byte[] payload = ["iv".getBytes(), localSeed, remoteSeed, localHash].flatten()
	byte[] fullIv = mdEncode("SHA-256", payload)
	byte[] byteSeqNo = fullIv[-4..-1]
	int seqNo = byteArrayToInteger(byteSeqNo)
	sessionData << [seqNo: seqNo]
	sessionData << [encIv: fullIv[0..11], cookie: cookie]
	//	KEY
	payload = ["lsk".getBytes(), localSeed, remoteSeed, localHash].flatten()
	sessionData << [encKey: mdEncode("SHA-256", payload)[0..15]]
	//	SIG
	payload = ["ldk".getBytes(), localSeed, remoteSeed, localHash].flatten()
	sessionData << [encSig: mdEncode("SHA-256", payload)[0..27]]
	return sessionData
}

def klapLoginDevice(uri, localHash, localSeed, remoteSeed, cookie) {
	Map loginData = [method: "klapLoginDevice"]
	byte[] authHashes = [remoteSeed, localSeed, localHash].flatten()
	byte[] body = mdEncode("SHA-256", authHashes)
	Map respData = klapSyncPost(uri, body, cookie)
	def loginSuccess = false
	if (respData.status == 200) {
		loginSuccess = true 
	} else {
		LoginData << [errorData: respData]
	}
	loginData << [loginSuccess: loginSuccess]
	return loginData
}

//	===== Legacy (AES) Handshake and Login =====
def aesLogin(baseUrl, encPassword, encUsername) {
	Map logData = [method: "aesLogin"]
	Map sessionData = [protocol: "AES"]
	Map handshakeData = aesHandshake(baseUrl)
	def status = "ERROR"
	logData << [handshakeData: handshakeData]
	if (handshakeData.respStatus == "OK") {
		byte[] encKey = handshakeData.encKey
		byte[] encIv = handshakeData.encIv
		def tokenData = aesLoginDevice(baseUrl, handshakeData.cookie, 
									   encKey, encIv,
									   encPassword, encUsername)
		logData << [tokenData: tokenData]
		if (tokenData.respStatus == "OK") {
			sessionData << [encKey: handshakeData.encKey,
							encIv: handshakeData.encIv,
							token: tokenData.token,
							cookie: handshakeData.cookie,
						    status: "OK"]
			status = "OK"
		} else {
			sessionData << [status: "ERROR"]
		}
	} else {
		sessionData << [status: "ERROR"]
	}
	logData << [status: status]
	if (logData.status != "OK") {
		logInfo(logData)
	}
	return sessionData
}

def aesHandshake(baseUrl) {
	def rsaKeys = getRsaKeys()
	Map handshakeData = [method: "aesHandshake", rsaKeyNo: rsaKeys.keyNo]
	def pubPem = "-----BEGIN PUBLIC KEY-----\n${rsaKeys.public}-----END PUBLIC KEY-----\n"
	Map cmdBody = [ method: "handshake", params: [ key: pubPem]]
	def respStatus = "ERROR"
	Map respData = aesSyncPost(baseUrl, cmdBody)
	if (respData.status == 200 && respData.data != null) {
		String deviceKey = respData.data.result.key
		def cookieHeader = respData.headers["set-cookie"].toString()
		def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
		Map aesArray = aesReadDeviceKey(deviceKey, rsaKeys.private)
		if (aesArraystatus == "ERROR") {
			handshakeData << [check: "privateKey"]
		} else {
			respStatus = "OK"
			handshakeData << [encKey: aesArray.cryptoArray[0..15], 
							  encIv: aesArray.cryptoArray[16..31], cookie: cookie]
		}
	} else {
		handshakeData << [errorData: respData]
	}
	handshakeData << [respStatus: respStatus]
	return handshakeData
}

def aesReadDeviceKey(deviceKey, privateKey) {
	def status = "ERROR"
	def respData = [method: "aesReadDeviceKey"]
	try {
		byte[] privateKeyBytes = privateKey.decodeBase64()
		byte[] deviceKeyBytes = deviceKey.getBytes("UTF-8").decodeBase64()
    	Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
		instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
		byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
		respData << [cryptoArray: cryptoArray]
		status = "OK"
	} catch (err) {
		respData << [errorData: err]
	}
	respData << [keyStatus: status]
	return respData
}

def aesLoginDevice(uri, cookie, encKey, encIv, encPassword, encUsername) {
	Map tokenData = [protocol: "aes"]
	Map logData = [method: "aesLoginDevice"]
	Map cmdBody = [method: "login_device",
				   params: [password: encPassword,
							username: encUsername],
				   requestTimeMils: 0]
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	def encrString = aesEncrypt(cmdStr, encKey, encIv)
	Map reqBody = [method: "securePassthrough", params: [request: encrString]]
	def respData = aesSyncPost(uri, reqBody, cookie)
	if (respData.status == 200) {
		if (respData.data.error_code == 0) {
			try {
				def cmdResp = aesDecrypt(respData.data.result.response, encKey, encIv)
				cmdResp = new JsonSlurper().parseText(cmdResp)
				if (cmdResp.error_code == 0) {
					tokenData << [respStatus: "OK", token: cmdResp.result.token]
				} else {
					tokenData << [respStatus: "ERROR", error_code: cmdResp.error_code,
								  check: "cryptoArray, credentials", data: cmdResp]
				}
			} catch (err) {
				tokenData << [respStatus: "ERROR", error: err]
			}
		} else {
			tokenData << [respStatus: "ERROR", data: respData.data]
		}
	} else {
		tokenData << [respStatus: "ERROR", data: respData]
	}
	logData << [tokenData: tokenData]
	if (tokenData.respStatus == "OK") {
		logDebug(logData)
	} else {
		logWarn(logData)
	}
	return tokenData
}

//	===== Protocol specific encrytion/decryption =====
def klapEncrypt(byte[] request, encKey, encIv, encSig) {
	int seqNo = state.seqNo + 1
	state.seqNo = seqNo
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()

	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	byte[] cipherRequest = cipher.doFinal(request)

	byte[] payload = [encSig, encSeqNo, cipherRequest].flatten()
	byte[] signature = mdEncode("SHA-256", payload)
	cipherRequest = [signature, cipherRequest].flatten()
	return [cipherData: cipherRequest, seqNumber: seqNo]
}

def aesEncrypt(request, encKey, encIv) {
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	String result = cipher.doFinal(request.getBytes("UTF-8")).encodeBase64().toString()
	return result.replace("\r\n","")
}

def klapDecrypt(cipherResponse, encKey, encIv) {
	byte[] encSeq = integerToByteArray(state.seqNo)
	byte[] ivEnc = [encIv, encSeq].flatten()

	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	byte[] byteResponse = cipher.doFinal(cipherResponse)
	return new String(byteResponse, "UTF-8")
}

def aesDecrypt(cipherResponse, encKey, encIv) {
    byte[] decodedBytes = cipherResponse.decodeBase64()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	String result = new String(cipher.doFinal(decodedBytes), "UTF-8")
	return result
}

//	===== RSA Key Methods =====
def getRsaKeys() {
	def keyNo = Math.round(5 * Math.random()).toInteger()
	def keyData = keyData()
	def RSAKeys = keyData.find { it.keyNo == keyNo }
	return RSAKeys
}

def keyData() {
	//	Keys used for discovery.
	return [
		[
			keyNo: 0,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGr/mHBK8aqx7UAS+g+TuAvE3J2DdwsqRn9MmAkjPGNon1ZlwM6nLQHfJHebdohyVqkNWaCECGXnftnlC8CM2c/RujvCrStRA0lVD+jixO9QJ9PcYTa07Z1FuEze7Q5OIa6pEoPxomrjxzVlUWLDXt901qCdn3/zRZpBdpXzVZtQIDAQAB",
			private: "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMav+YcErxqrHtQBL6D5O4C8TcnYN3CypGf0yYCSM8Y2ifVmXAzqctAd8kd5t2iHJWqQ1ZoIQIZed+2eULwIzZz9G6O8KtK1EDSVUP6OLE71An09xhNrTtnUW4TN7tDk4hrqkSg/GiauPHNWVRYsNe33TWoJ2ff/NFmkF2lfNVm1AgMBAAECgYEAocxCHmKBGe2KAEkq+SKdAxvVGO77TsobOhDMWug0Q1C8jduaUGZHsxT/7JbA9d1AagSh/XqE2Sdq8FUBF+7vSFzozBHyGkrX1iKURpQFEQM2j9JgUCucEavnxvCqDYpscyNRAgqz9jdh+BjEMcKAG7o68bOw41ZC+JyYR41xSe0CQQD1os71NcZiMVqYcBud6fTYFHZz3HBNcbzOk+RpIHyi8aF3zIqPKIAh2pO4s7vJgrMZTc2wkIe0ZnUrm0oaC//jAkEAzxIPW1mWd3+KE3gpgyX0cFkZsDmlIbWojUIbyz8NgeUglr+BczARG4ITrTV4fxkGwNI4EZxBT8vXDSIXJ8NDhwJBAIiKndx0rfg7Uw7VkqRvPqk2hrnU2aBTDw8N6rP9WQsCoi0DyCnX65Hl/KN5VXOocYIpW6NAVA8VvSAmTES6Ut0CQQCX20jD13mPfUsHaDIZafZPhiheoofFpvFLVtYHQeBoCF7T7vHCRdfl8oj3l6UcoH/hXMmdsJf9KyI1EXElyf91AkAvLfmAS2UvUnhX4qyFioitjxwWawSnf+CewN8LDbH7m5JVXJEh3hqp+aLHg1EaW4wJtkoKLCF+DeVIgbSvOLJw"
		],[
			keyNo: 1,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCshy+qBKbJNefcyJUZ/3i+3KyLji6XaWEWvebUCC2r9/0jE6hc89AufO41a13E3gJ2es732vaxwZ1BZKLy468NnL+tg6vlQXaPkDcdunQwjxbTLNL/yzDZs9HRju2lJnupcksdJWBZmjtztMWQkzBrQVeSKzSTrKYK0s24EEXmtQIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKyHL6oEpsk159zIlRn/eL7crIuOLpdpYRa95tQILav3/SMTqFzz0C587jVrXcTeAnZ6zvfa9rHBnUFkovLjrw2cv62Dq+VBdo+QNx26dDCPFtMs0v/LMNmz0dGO7aUme6lySx0lYFmaO3O0xZCTMGtBV5IrNJOspgrSzbgQRea1AgMBAAECgYBSeiX9H1AkbJK1Z2ZwEUNF6vTJmmUHmScC2jHZNzeuOFVZSXJ5TU0+jBbMjtE65e9DeJ4suw6oF6j3tAZ6GwJ5tHoIy+qHRV6AjA8GEXjhSwwVCyP8jXYZ7UZyHzjLQAK+L0PvwJY1lAtns/Xmk5GH+zpNnhEmKSZAw23f7wpj2QJBANVPQGYT7TsMTDEEl2jq/ZgOX5Djf2VnKpPZYZGsUmg1hMwcpN/4XQ7XOaclR5TO/CJBJl3UCUEVjdrR1zdD8g8CQQDPDoa5Y5UfhLz4Ja2/gs2UKwO4fkTqqR6Ad8fQlaUZ55HINHWFd8FeERBFgNJzszrzd9BBJ7NnZM5nf2OPqU77AkBLuQuScSZ5HL97czbQvwLxVMDmLWyPMdVykOvLC9JhPgZ7cvuwqnlWiF7mEBzeHbBx9JDLJDd4zE8ETBPLgapPAkAHhCR52FaSdVQSwfNjr1DdHw6chODlj8wOp8p2FOiQXyqYlObrOGSpkH8BtuJs1sW+DsxdgR5vE2a2tRYdIe0/AkEAoQ5MzLcETQrmabdVCyB9pQAiHe4yY9e1w7cimsLJOrH7LMM0hqvBqFOIbSPrZyTp7Ie8awn4nTKoZQtvBfwzHw=="
		],[
			keyNo: 2,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCBeqRy4zAOs63Sc5yc0DtlFXG1stmdD6sEfUiGjlsy0S8aS8X+Qcjcu5AK3uBBrkVNIa8djXht1bd+pUof5/txzWIMJw9SNtNYqzSdeO7cCtRLzuQnQWP7Am64OBvYkXn2sUqoaqDE50LbSQWbuvZw0Vi9QihfBYGQdlrqjCPUsQIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIF6pHLjMA6zrdJznJzQO2UVcbWy2Z0PqwR9SIaOWzLRLxpLxf5ByNy7kAre4EGuRU0hrx2NeG3Vt36lSh/n+3HNYgwnD1I201irNJ147twK1EvO5CdBY/sCbrg4G9iRefaxSqhqoMTnQttJBZu69nDRWL1CKF8FgZB2WuqMI9SxAgMBAAECgYBBi2wkHI3/Y0Xi+1OUrnTivvBJIri2oW/ZXfKQ6w+PsgU+Mo2QII0l8G0Ck8DCfw3l9d9H/o2wTDgPjGzxqeXHAbxET1dS0QBTjR1zLZlFyfAs7WO8tDKmHVroUgqRkJgoQNQlBSe1E3e7pTgSKElzLuALkRS6p1jhzT2wu9U04QJBAOFr/G36PbQ6NmDYtVyEEr3vWn46JHeZISdJOsordR7Wzbt6xk6/zUDHq0OGM9rYrpBy7PNrbc0JuQrhfbIyaHMCQQCTCvETjXCMkwyUrQT6TpxVzKEVRf1rCitnNQCh1TLnDKcCEAnqZT2RRS3yNXTWFoJrtuEHMGmwUrtog9+ZJBlLAkEA2qxdkPY621XJIIO404mPgM7rMx4F+DsE7U5diHdFw2fO5brBGu13GAtZuUQ7k2W1WY0TDUO+nTN8XPDHdZDuvwJABu7TIwreLaKZS0FFJNAkCt+VEL22Dx/xn/Idz4OP3Nj53t0Guqh/WKQcYHkowxdYmt+KiJ49vXSJJYpiNoQ/NQJAM1HCl8hBznLZLQlxrCTdMvUimG3kJmA0bUNVncgUBq7ptqjk7lp5iNrle5aml99foYnzZeEUW6jrCC7Lj9tg+w=="
		],[
			keyNo: 3,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCFYaoMvv5kBxUUbp4PQyd7RoZlPompsupXP2La0qGGxacF98/88W4KNUqLbF4X5BPqxoEA+VeZy75qqyfuYbGQ4fxT6usE/LnzW8zDY/PjhVBht8FBRyAUsoYAt3Ip6sDyjd9YzRzUL1Q/OxCgxz5CNETYxcNr7zfMshBHDmZXMQIDAQAB",
			private: "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIVhqgy+/mQHFRRung9DJ3tGhmU+iamy6lc/YtrSoYbFpwX3z/zxbgo1SotsXhfkE+rGgQD5V5nLvmqrJ+5hsZDh/FPq6wT8ufNbzMNj8+OFUGG3wUFHIBSyhgC3cinqwPKN31jNHNQvVD87EKDHPkI0RNjFw2vvN8yyEEcOZlcxAgMBAAECgYA3NxjoMeCpk+z8ClbQRqJ/e9CC9QKUB4bPG2RW5b8MRaJA7DdjpKZC/5CeavwAs+Ay3n3k41OKTTfEfJoJKtQQZnCrqnZfq9IVZI26xfYo0cgSYbi8wCie6nqIBdu9k54nqhePPshi22VcFuOh97xxPvY7kiUaRbbKqxn9PFwrYQJBAMsO3uOnYSJxN/FuxksKLqhtNei2GUC/0l7uIE8rbRdtN3QOpcC5suj7id03/IMn2Ks+Vsrmi0lV4VV/c8xyo9UCQQCoKDlObjbYeYYdW7/NvI6cEntgHygENi7b6WFk+dbRhJQgrFH8Z/Idj9a2E3BkfLCTUM1Z/Z3e7D0iqPDKBn/tAkBAHI3bKvnMOhsDq4oIH0rj+rdOplAK1YXCW0TwOjHTd7ROfGFxHDCUxvacVhTwBCCw0JnuriPEH81phTg2kOuRAkAEPR9UrsqLImUTEGEBWqNto7mgbqifko4T1QozdWjI10K0oCNg7W3Y+Os8o7jNj6cTz5GdlxsHp4TS/tczAH7xAkBY6KPIlF1FfiyJAnBC8+jJr2h4TSPQD7sbJJmYw7mvR+f1T4tsWY0aGux69hVm8BoaLStBVPdkaENBMdP+a07u"
		],[
			keyNo: 4,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQClF0yuCpo3r1ZpYlGcyI5wy5nnvZdOZmxqz5U2rklt2b8+9uWhmsGdpbTv5+qJXlZmvUKbpoaPxpJluBFDJH2GSpq3I0whh0gNq9Arzpp/TDYaZLb6iIqDMF6wm8yjGOtcSkB7qLQWkXpEN9T2NsEzlfTc+GTKc07QXHnzxoLmwQIDAQAB",
			private: "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKUXTK4KmjevVmliUZzIjnDLmee9l05mbGrPlTauSW3Zvz725aGawZ2ltO/n6oleVma9Qpumho/GkmW4EUMkfYZKmrcjTCGHSA2r0CvOmn9MNhpktvqIioMwXrCbzKMY61xKQHuotBaRekQ31PY2wTOV9Nz4ZMpzTtBcefPGgubBAgMBAAECgYB4wCz+05RvDFk45YfqFCtTRyg//0UvO+0qxsBN6Xad2XlvlWjqJeZd53kLTGcYqJ6rsNyKOmgLu2MS8Wn24TbJmPUAwZU+9cvSPxxQ5k6bwjg1RifieIcbTPC5wHDqVy0/Ur7dt+JVMOHFseR/pElDw471LCdwWSuFHAKuiHsaUQJBANHiPdSU3s1bbJYTLaS1tW0UXo7aqgeXuJgqZ2sKsoIEheEAROJ5rW/f2KrFVtvg0ITSM8mgXNlhNBS5OE4nSD0CQQDJXYJxKvdodeRoj+RGTCZGZanAE1naUzSdfcNWx2IMnYUD/3/2eB7ZIyQPBG5fWjc3bGOJKI+gy/14bCwXU7zVAkAdnsE9HBlpf+qOL3y0jxRgpYxGuuNeGPJrPyjDOYpBwSOnwmL2V1e7vyqTxy/f7hVfeU7nuKMB5q7z8cPZe7+9AkEAl7A6aDe+wlE069OhWZdZqeRBmLC7Gi1d0FoBwahW4zvyDM32vltEmbvQGQP0hR33xGeBH7yPXcjtOz75g+UPtQJBAL4gknJ/p+yQm9RJB0oq/g+HriErpIMHwrhNoRY1aOBMJVl4ari1Ch2RQNL9KQW7yrFDv7XiP3z5NwNDKsp/QeU="
		],[
			keyNo: 5,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChN8Xc+gsSuhcLVM1W1E+e1o+celvKlOmuV6sJEkJecknKFujx9+T4xvyapzyePpTBn0lA9EYbaF7UDYBsDgqSwgt0El3gV+49O56nt1ELbLUJtkYEQPK+6Pu8665UG17leCiaMiFQyoZhD80PXhpjehqDu2900uU/4DzKZ/eywwIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKE3xdz6CxK6FwtUzVbUT57Wj5x6W8qU6a5XqwkSQl5yScoW6PH35PjG/JqnPJ4+lMGfSUD0RhtoXtQNgGwOCpLCC3QSXeBX7j07nqe3UQtstQm2RgRA8r7o+7zrrlQbXuV4KJoyIVDKhmEPzQ9eGmN6GoO7b3TS5T/gPMpn97LDAgMBAAECgYAy+uQCwL8HqPjoiGR2dKTI4aiAHuEv6m8KxoY7VB7QputWkHARNAaf9KykawXsNHXt1GThuV0CBbsW6z4U7UvCJEZEpv7qJiGX8UWgEs1ISatqXmiIMVosIJJvoFw/rAoScadCYyicskjwDFBVNU53EAUD3WzwEq+dRYDn52lqQQJBAMu30FEReAHTAKE/hvjAeBUyWjg7E4/lnYvb/i9Wuc+MTH0q3JxFGGMb3n6APT9+kbGE0rinM/GEXtpny+5y3asCQQDKl7eNq0NdIEBGAdKerX4O+nVDZ7PXz1kQ2ca0r1tXtY/9sBDDoKHP2fQAH/xlOLIhLaH1rabSEJYNUM0ohHdJAkBYZqhwNWtlJ0ITtvSEB0lUsWfzFLe1bseCBHH16uVwygn7GtlmupkNkO9o548seWkRpnimhnAE8xMSJY6aJ6BHAkEAuSFLKrqGJGOEWHTx8u63cxiMb7wkK+HekfdwDUzxO4U+v6RUrW/sbfPNdQ/FpPnaTVdV2RuGhg+CD0j3MT9bgQJARH86hfxp1bkyc7f1iJQT8sofdqqVz5grCV5XeGY77BNmCvTOGLfL5pOJdgALuOoP4t3e94nRYdlW6LqIVugRBQ=="
		]
	]
}

//	===== Encoding Methods =====
def mdEncode(hashMethod, byte[] data) {
	MessageDigest md = MessageDigest.getInstance(hashMethod)
	md.update(data)
	return md.digest()
}

String encodeUtf8(String message) {
	byte[] arr = message.getBytes("UTF8")
	return new String(arr)
}

int byteArrayToInteger(byte[] byteArr) {
	int arrayASInteger
	try {
		arrayAsInteger = ((byteArr[0] & 0xFF) << 24) + ((byteArr[1] & 0xFF) << 16) +
			((byteArr[2] & 0xFF) << 8) + (byteArr[3] & 0xFF)
	} catch (error) {
		Map errLog = [byteArr: byteArr, ERROR: error]
		logWarn("byteArrayToInteger: ${errLog}")
	}
	return arrayAsInteger
}

byte[] integerToByteArray(value) {
	String hexValue = hubitat.helper.HexUtils.integerToHexString(value, 4)
	byte[] byteValue = hubitat.helper.HexUtils.hexStringToByteArray(hexValue)
	return byteValue
}
