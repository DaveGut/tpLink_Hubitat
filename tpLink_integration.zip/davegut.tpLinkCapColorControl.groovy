library (
	name: "tpLinkCapColorControl",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat capability ColorControl, Color Mode, and Color Temperature Methods.",
	category: "utilities",
	documentationLink: ""
)

capability "Color Control"
capability "Color Temperature"
capability "Color Mode"

def setHue(hue){
	logDebug("setHue: ${hue}")
	hue = (3.6 * hue).toInteger()
	logDebug("setHue: ${hue}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setHue", "parseUpdates")
}

def setSaturation(saturation) {
	logDebug("setSatiratopm: ${saturation}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			saturation: saturation,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setSaturation", "parseUpdates")
}

def setColor(color) {
	logDebug("setColor: ${color}")
	def level = color.level
	if (level == 0) { level = device.currentValue("level") }
	def hue = (3.6 * color.hue).toInteger()
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			saturation: color.saturation,
			brightness: level,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setColor", "parseUpdates")
}

def setColorTemperature(colorTemp, level = device.currentValue("level").toInteger(), transTime = 0) {
	logDebug([method: "setColorTemperature", level: level, colorTemp: colorTemp, transTime: transTime])
	def lowCt = getDataValue("ctLow").toInteger()
	def highCt = getDataValue("ctHigh").toInteger()
	if (colorTemp < lowCt) { colorTemp = lowCt }
	else if (colorTemp > highCt) { colorTemp = highCt }
	if (level == null) { level = device.currentValue("level") toInteger() }
	if (transTime < 0) { transTime = 0 }
	if (getDataValue("type") == "Color Bulb" && transTime > 0) {
		def ctRange = highCt - lowCt
		startCtTransition(colorTemp, ctRange, level, transTime)
	} else {
		if (level == 0) {
			off()
		} else {
			List requests = [[
				method: "set_device_info",
				params: [
					brightness: level,
					color_temp: colorTemp
				]]]
			requests << [method: "get_device_info"]
			asyncSend(createMultiCmd(requests), "setColorTemperature", "parseUpdates")
		}
	}
}

def startCtTransition(colorTemp, ctRange, level, transTime) {
	def startTime = (now()/1000).toInteger()
	def endTime = startTime + transTime
	Map transData = [endTime: endTime, targetLevel: level, targetCt: colorTemp, cmdIncr: 180]
	//	Command increment derived from experimentation with Tapo Lan devices.
	def totalIncrs = (transTime * 5).toInteger()

	//	CT Increment (based on total CT Change, cmdIncr, and transTime)
	def currCt = device.currentValue("colorTemperature").toInteger()
	def ctChange = colorTemp - currCt
	def ctIncr = (0.5 + (ctChange/totalIncrs)).toInteger()
	transData << [currCt: currCt, ctIncr: ctIncr]
	
	//	Level Increment (based on total level Change, cmdIncr, and transTime)
	def currLevel = device.currentValue("level").toInteger()
	def levelChange = level - currLevel
	def levelIncr = levelChange/totalIncrs
	if (levelIncr < 0 ) { levelIncr = (levelIncr - 0.5).toInteger() }
	else { levelIncr = (levelIncr + 0.5).toInteger() }
	transData << [currLevel: currLevel, levelIncr: levelIncr]

	logDebug([method: "startCtTransition", transData: transData])
	doCtTransition(transData)
}

def doCtTransition(Map transData) {
	def newLevel = transData.targetLevel
	def newCt = transData.targetCt
	def doAgain = true
	def curTime = (now()/1000).toInteger()
	if (newLevel == transData.currLevel && newCt == transData.currCt) {
		doAgain = false
	} else if (curTime >= transData.endTime) {
		doAgain = false
	} else {
		if (newLevel != transData.currLevel) {
			newLevel = transData.currLevel + transData.levelIncr
			if (transData.levelIncr >= 0 && newLevel > transData.targetLevel) {
				newLevel = transData.targetLevel
			} else if (transData.levelIncr < 0 && newLevel < transData.targetLevel) {
				newLevel = transData.targetLevel
			}
		}
		if (newCt != transData.currCt) {
			newCt = transData.currCt + transData.ctIncr
			if (transData.ctIncr >= 0 && newCt > transData.targetCt) {
				newCt = transData.targetCt
			} else if (transData.ctIncr < 0 && newCt < transData.targetCt) {
				newCt = transData.targetCt
			}
		}
	}
	transData << [currLevel: newLevel, currCt: newCt]
	if (currLevel != 0) {
		asyncSend([method: "set_device_info", params: [brightness: newLevel, color_temp: newCt]],
				  "doCtTransition", "nullParse")
		if (doAgain == true) {
			runInMillis(transData.cmdIncr, doCtTransition, [data: transData])
		} else {
			runInMillis(500, setLevel, [data: transData.targetLevel])
		}
	} else {
		off()
	}
}
