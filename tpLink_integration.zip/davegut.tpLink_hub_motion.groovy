/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_hub_motion", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_motion.groovy")
	{
		capability "Refresh"
		capability "Motion Sensor"
		attribute "lowBattery", "string"
	}
	preferences {
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	updateAttr("commsError", "OK")
	runIn(1, updated)
}

def updated() {
	unschedule()
	def logData = [:]
	logData << setLogsOff()
	logData << [status: "OK"]
	if (logData.status == "ERROR") {
		logError("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
}

def refresh() { parent.refresh() }

//	Parse Methods
def devicePollParse(childData) {
	try {
		def motion = "inactive"
		if (childData.detected) { motion = "active" }
		updateAttr("motion", motion)
		updateAttr("lowBattery", childData.at_low_battery.toString())
	} catch (err) {
		Map logData = [method: "devicePollParse", status: "ERROR",
					   childData: childData, error: err]
		logWarn(logData)
	}
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

//	Library Inclusion
#include davegut.Logging
