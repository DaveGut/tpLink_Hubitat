library (
	name: "tpLinkChildInst",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Child Installation Methods",
	category: "utilities",
	documentationLink: ""
)

def installChildDevices() {
	Map request = [method: "get_child_device_list"]
	asyncSend(request, "installChildDevices", "installChildren")
}

def installChildren(resp, data=null) {
	Map logData = [method: "installChildren"]
	def respData = parseData(resp)
	def children = respData.cmdResp.result.child_device_list
	children.each {
		String childDni = it.mac
		if (it.position) {
			childDni = childDni + "-" + it.position
		}
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		Map instData = [alias: alias, childDni: childDni]
		if (isChild) {
			instData << [status: "device already installed"]
		} else {
			String devType = getDeviceType(it.category)
			instData << [label: alias, name: it.model, type: devType, deviceId: 
						 it.device_id, category: it.category]
			if (devType == "Child Undefined") {
				instData << [status: "notInstalled", error: "Currently Unsupported"]
				logWarn(instData)
			} else {
				try {
					addChildDevice(
						nameSpace(), 
						"TpLink ${devType}",
						childDni,
						[
							"label": alias,
							"name": it.model,
							category: it.category,
							deviceId: it.device_id,
							type: devType
						])
					instData << [status: "Installed"]
				} catch (e) {
					instData << [status: "FAILED", error: err]
					logWarn(instData)
				}
			}
		}
		logData << ["${alias}": instData]
		pauseExecution(2000)
	}
	device.updateSetting("installChild", [type: "bool", value: "false"])
	logInfo(logData)
}

def getDeviceType(category) {
	String deviceType
	switch(category) {
		case "subg.trigger.contact-sensor":
			deviceType = "Hub Contact"; break
		case "subg.trigger.motion-sensor":
			deviceType = "Hub Motion"; break
		case "subg.trigger.button":
			deviceType = "Hub Button"; break
		case "subg.trigger.temp-hmdt-sensor":
logWarn("TEMP-HUMIDITY Sensor not supported.  Requires TEST Volunteer to finish")
			deviceType = "Child Undefined"; break
//			deviceType = "Hub TempHumidity"; break
		case "subg.trigger.water-leak-sensor":
			deviceType = "Hub Leak"; break
		case "subg.trv":
logWarn("TRV not supported.  Requires TEST Volunteer to finish")
			deviceType = "Child Undefined"; break
//			deviceType = "Hub Trv"; break
		case "plug.powerstrip.sub-plug":
			deviceType = "Child Plug"; break
		case "kasa.switch.outlet.sub-fan":
			deviceType = "Child Fan"; break
		case "kasa.switch.outlet.sub-dimmer":
		case "plug.powerstrip.sub-bulb":
			deviceType = "Child Dimmer"; break
		default:
			deviceType = "Child Undefined"
	}
	return deviceType
}
