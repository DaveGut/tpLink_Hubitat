/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Supports:  Tapo Plugs and Switches, New and Matter Kasa Plugs and Switches.

Verified on P125M(US).
=================================================================================================*/

metadata {
	definition (name: "TpLink Plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug.groovy")
	{
	}
	preferences {
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data]
	if (result.device_on != null) {
		def onOff = "off"
		if (result.device_on == true) { onOff = "on" }
		sendEvent(name: "switch", value: onOff, type: state.eventType)
		state.eventType = "physical"
		logData << [switch: onOff]
	}
	logDebug(logData)
}

#include davegut.tpLinkCapSwitch
#include davegut.tpLinkCommon
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.Logging
