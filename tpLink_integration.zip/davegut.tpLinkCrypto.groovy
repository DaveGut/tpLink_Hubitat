library (
	name: "tpLinkCrypto",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Handshake methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.Cipher
import java.security.KeyFactory
import java.util.Random
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec
import java.security.MessageDigest

//	===== AES Handshake and Login =====
def aesHandshake(baseUrl = getDataValue("baseUrl"), devData = null) {
	Map reqData = [baseUrl: baseUrl, devData: devData]
	Map rsaKey = getRsaKey()
	def pubPem = "-----BEGIN PUBLIC KEY-----\n${rsaKey.public}-----END PUBLIC KEY-----\n"
	Map cmdBody = [ method: "handshake", params: [ key: pubPem]]
	Map reqParams = [uri: baseUrl,
					 body: new groovy.json.JsonBuilder(cmdBody).toString(),
					 requestContentType: "application/json",
					 timeout: 10]
	asyncPost(reqParams, "parseAesHandshake", reqData)
}

def parseAesHandshake(resp, data){
	Map logData = [method: "parseAesHandshake"]
	if (resp.status == 200 && resp.data != null) {
		try {
			Map reqData = [devData: data.data.devData, baseUrl: data.data.baseUrl]
			Map cmdResp =  new JsonSlurper().parseText(resp.data)
			//	cookie
			def cookieHeader = resp.headers["Set-Cookie"].toString()
			def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
			//	keys
			byte[] privateKeyBytes = getRsaKey().private.decodeBase64()
			byte[] deviceKeyBytes = cmdResp.result.key.getBytes("UTF-8").decodeBase64()
    		Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
			instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
			byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
			byte[] encKey = cryptoArray[0..15]
			byte[] encIv = cryptoArray[16..31]
			logData << [respStatus: "Cookies/Keys Updated", cookie: cookie,
						encKey: encKey, encIv: encIv]
			String password = encPassword
			String username = encUsername
			if (device) {
				password = parent.encPassword
				username = parent.encUsername
				device.updateSetting("cookie",[type:"password", value: cookie])
				device.updateSetting("encKey",[type:"password", value: encKey])
				device.updateSetting("encIv",[type:"password", value: encIv])
			} else {
				reqData << [cookie: cookie, encIv: encIv, encKey: encKey]
			}
			Map cmdBody = [method: "login_device",
						   params: [password: password,
									username: username],
						   requestTimeMils: 0]
			def cmdStr = JsonOutput.toJson(cmdBody).toString()
			Map reqBody = [method: "securePassthrough",
						   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
			Map reqParams = [uri: reqData.baseUrl,
							  body: reqBody,
							  timeout:10, 
							  headers: ["Cookie": cookie],
							  contentType: "application/json",
							  requestContentType: "application/json"]
			asyncPost(reqParams, "parseAesLogin", reqData)
			logDebug(logData)
		} catch (err) {
			logData << [respStatus: "ERROR parsing HTTP resp.data",
						respData: resp.data, error: err]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

def parseAesLogin(resp, data) {
	if (device) {
		Map logData = [method: "parseAesLogin"]
		if (resp.status == 200) {
			if (resp.json.error_code == 0) {
				try {
					byte[] encKey = new JsonSlurper().parseText(encKey)
					byte[] encIv = new JsonSlurper().parseText(encIv)
					def clearResp = aesDecrypt(resp.json.result.response, encKey, encIv)
					Map cmdResp = new JsonSlurper().parseText(clearResp)
					if (cmdResp.error_code == 0) {
						def token = cmdResp.result.token
						logData << [respStatus: "OK", token: token]
						device.updateSetting("token",[type:"password", value: token])
						state.errorCount = 0
						if (device.currentValue("commsError") == "true") {
							logData << [setCommsError: setCommsError(false)]
						}
						logDebug(logData)
					} else {
						logData << [respStatus: "ERROR code in cmdResp", 
									error_code: cmdResp.error_code,
									check: "cryptoArray, credentials", data: cmdResp]
						logWarn(logData)
					}
				} catch (err) {
					logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
								error: err]
					logWarn(logData)
				}
			} else {
				logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
							respJson: resp.json]
				logWarn(logData)
			}
		} else {
			logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
			logWarn(logData)
		}
	} else {
		getAesToken(resp, data.data)
	}
}

//	===== KLAP Handshake =====
def klapHandshake(baseUrl = getDataValue("baseUrl"), localHash = parent.localHash, devData = null) {
	byte[] localSeed = new byte[16]
	new Random().nextBytes(localSeed)
	Map reqData = [localSeed: localSeed, baseUrl: baseUrl, localHash: localHash, devData:devData]
	Map reqParams = [uri: "${baseUrl}/handshake1",
					 body: localSeed,
					 contentType: "application/octet-stream",
					 requestContentType: "application/octet-stream",
					 timeout:10]
	asyncPost(reqParams, "parseKlapHandshake", reqData)
}

def parseKlapHandshake(resp, data) {
	Map logData = [method: "parseKlapHandshake", data: data]
	if (resp.status == 200 && resp.data != null) {
		try {
			Map reqData = [devData: data.data.devData, baseUrl: data.data.baseUrl]
			byte[] localSeed = data.data.localSeed
			byte[] seedData = resp.data.decodeBase64()
			byte[] remoteSeed = seedData[0 .. 15]
			byte[] serverHash = seedData[16 .. 47]
			byte[] localHash = data.data.localHash.decodeBase64()
			byte[] authHash = [localSeed, remoteSeed, localHash].flatten()
			byte[] localAuthHash = mdEncode("SHA-256", authHash)
			if (localAuthHash == serverHash) {
				//	cookie
				def cookieHeader = resp.headers["Set-Cookie"].toString()
				def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
				logData << [cookie: cookie]
				//	seqNo and encIv
				byte[] payload = ["iv".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] fullIv = mdEncode("SHA-256", payload)
				byte[] byteSeqNo = fullIv[-4..-1]

				int seqNo = byteArrayToInteger(byteSeqNo)
				atomicState.seqNo = seqNo

				logData << [seqNo: seqNo, encIv: fullIv[0..11]]
				//	encKey
				payload = ["lsk".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] encKey = mdEncode("SHA-256", payload)[0..15]
				logData << [encKey: encKey]
				//	encSig
				payload = ["ldk".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] encSig = mdEncode("SHA-256", payload)[0..27]
				if (device) {
					device.updateSetting("cookie",[type:"password", value: cookie]) 
					device.updateSetting("encKey",[type:"password", value: encKey]) 
					device.updateSetting("encIv",[type:"password", value: fullIv[0..11]]) 
					device.updateSetting("encSig",[type:"password", value: encSig]) 
				} else {
					reqData << [cookie: cookie, seqNo: seqNo, encIv: fullIv[0..11], 
								encSig: encSig, encKey: encKey]
				}
				logData << [encSig: encSig]
				byte[] loginHash = [remoteSeed, localSeed, localHash].flatten()
				byte[] body = mdEncode("SHA-256", loginHash)
				Map reqParams = [uri: "${data.data.baseUrl}/handshake2",
								 body: body,
								 timeout:10,
								 headers: ["Cookie": cookie],
								 contentType: "application/octet-stream",
								 requestContentType: "application/octet-stream"]
				asyncPost(reqParams, "parseKlapHandshake2", reqData)
			} else {
				logData << [respStatus: "ERROR: locakAuthHash != serverHash",
							localAuthHash: localAuthHash, serverHash: serverHash]
				logWarn(logData)
			}
		} catch (err) {
			logData << [respStatus: "ERROR parsing 200 response", resp: resp.properties, error: err]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

def parseKlapHandshake2(resp, data) {
	Map logData = [method: "parseKlapHandshake2"]
	if (resp.status == 200 && resp.data == null) {
		logData << [respStatus: "Login OK"]
		state.errorCount = 0
		if (device && device.currentValue("commsError") == "true") {
			logData << [setCommsError: setCommsError(false)]
		}
		logDebug(logData)
	} else {
		logData << [respStatus: "LOGIN FAILED", reason: "ERROR in HTTP response",
					resp: resp.properties]
		logWarn(logData)
	}
	if (!device) { sendKlapDataCmd(logData, data) }
}

//	===== Comms Support =====
def getKlapParams(cmdBody) {
	Map reqParams = [timeout: 10, headers: ["Cookie": cookie]]
	int seqNo = state.seqNo + 1
	state.seqNo = seqNo
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	byte[] encSig = new JsonSlurper().parseText(encSig)
	String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()

	Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv,
									encSig, seqNo)
	reqParams << [uri: "${getDataValue("baseUrl")}/request?seq=${seqNo}",
				  body: encryptedData.cipherData,
				  contentType: "application/octet-stream",
				  requestContentType: "application/octet-stream"]
	return reqParams
}

def getAesParams(cmdBody) {
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
	Map reqParams = [uri: "${getDataValue("baseUrl")}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 headers: ["Cookie": cookie]]
	return reqParams
}

def parseKlapData(resp) {
	Map parseData = [parseMethod: "parseKlapData"]
	try {
		byte[] encKey = new JsonSlurper().parseText(encKey)
		byte[] encIv = new JsonSlurper().parseText(encIv)
		int seqNo = state.seqNo
		byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
		Map cmdResp =  new JsonSlurper().parseText(klapDecrypt(cipherResponse, encKey,
														   encIv, seqNo))
		parseData << [status: "OK", cmdResp: cmdResp]
		state.errorCount = 0
		if (device.currentValue("commsError") == "true") {
			parseData << [setCommsError: setCommsError(false)]
		}
	} catch (err) {
		parseData << [status: "deviceDataParseError", error: err]
		handleCommsError()
	}
	return parseData
}

def parseAesData(resp) {
	Map parseData = [parseMethod: "parseAesData"]
	try {
		byte[] encKey = new JsonSlurper().parseText(encKey)
		byte[] encIv = new JsonSlurper().parseText(encIv)
		Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
														 encKey, encIv))
		parseData << [status: "OK", cmdResp: cmdResp]
		state.errorCount = 0
		if (device && device.currentValue("commsError") == "true") {
			parseData << [setCommsError: setCommsError(false)]
		}
	} catch (err) {
		parseData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		handleCommsError()
	}
	return parseData
}

//	===== Crypto Methods =====
def klapEncrypt(byte[] request, encKey, encIv, encSig, seqNo) {
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	byte[] cipherRequest = cipher.doFinal(request)

	byte[] payload = [encSig, encSeqNo, cipherRequest].flatten()
	byte[] signature = mdEncode("SHA-256", payload)
	cipherRequest = [signature, cipherRequest].flatten()
	return [cipherData: cipherRequest, seqNumber: seqNo]
}

def klapDecrypt(cipherResponse, encKey, encIv, seqNo) {
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	byte[] byteResponse = cipher.doFinal(cipherResponse)
	return new String(byteResponse, "UTF-8")
}

def aesEncrypt(request, encKey, encIv) {
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	String result = cipher.doFinal(request.getBytes("UTF-8")).encodeBase64().toString()
	return result.replace("\r\n","")
}

def aesDecrypt(cipherResponse, encKey, encIv) {
    byte[] decodedBytes = cipherResponse.decodeBase64()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	return new String(cipher.doFinal(decodedBytes), "UTF-8")
}

//	===== Encoding Methods =====
def mdEncode(hashMethod, byte[] data) {
	MessageDigest md = MessageDigest.getInstance(hashMethod)
	md.update(data)
	return md.digest()
}

String encodeUtf8(String message) {
	byte[] arr = message.getBytes("UTF8")
	return new String(arr)
}

int byteArrayToInteger(byte[] byteArr) {
	int arrayASInteger
	try {
		arrayAsInteger = ((byteArr[0] & 0xFF) << 24) + ((byteArr[1] & 0xFF) << 16) +
			((byteArr[2] & 0xFF) << 8) + (byteArr[3] & 0xFF)
	} catch (error) {
		Map errLog = [byteArr: byteArr, ERROR: error]
		logWarn("byteArrayToInteger: ${errLog}")
	}
	return arrayAsInteger
}

byte[] integerToByteArray(value) {
	String hexValue = hubitat.helper.HexUtils.integerToHexString(value, 4)
	byte[] byteValue = hubitat.helper.HexUtils.hexStringToByteArray(hexValue)
	return byteValue
}

def getRsaKey() {
	return [public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGr/mHBK8aqx7UAS+g+TuAvE3J2DdwsqRn9MmAkjPGNon1ZlwM6nLQHfJHebdohyVqkNWaCECGXnftnlC8CM2c/RujvCrStRA0lVD+jixO9QJ9PcYTa07Z1FuEze7Q5OIa6pEoPxomrjxzVlUWLDXt901qCdn3/zRZpBdpXzVZtQIDAQAB",
			private: "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMav+YcErxqrHtQBL6D5O4C8TcnYN3CypGf0yYCSM8Y2ifVmXAzqctAd8kd5t2iHJWqQ1ZoIQIZed+2eULwIzZz9G6O8KtK1EDSVUP6OLE71An09xhNrTtnUW4TN7tDk4hrqkSg/GiauPHNWVRYsNe33TWoJ2ff/NFmkF2lfNVm1AgMBAAECgYEAocxCHmKBGe2KAEkq+SKdAxvVGO77TsobOhDMWug0Q1C8jduaUGZHsxT/7JbA9d1AagSh/XqE2Sdq8FUBF+7vSFzozBHyGkrX1iKURpQFEQM2j9JgUCucEavnxvCqDYpscyNRAgqz9jdh+BjEMcKAG7o68bOw41ZC+JyYR41xSe0CQQD1os71NcZiMVqYcBud6fTYFHZz3HBNcbzOk+RpIHyi8aF3zIqPKIAh2pO4s7vJgrMZTc2wkIe0ZnUrm0oaC//jAkEAzxIPW1mWd3+KE3gpgyX0cFkZsDmlIbWojUIbyz8NgeUglr+BczARG4ITrTV4fxkGwNI4EZxBT8vXDSIXJ8NDhwJBAIiKndx0rfg7Uw7VkqRvPqk2hrnU2aBTDw8N6rP9WQsCoi0DyCnX65Hl/KN5VXOocYIpW6NAVA8VvSAmTES6Ut0CQQCX20jD13mPfUsHaDIZafZPhiheoofFpvFLVtYHQeBoCF7T7vHCRdfl8oj3l6UcoH/hXMmdsJf9KyI1EXElyf91AkAvLfmAS2UvUnhX4qyFioitjxwWawSnf+CewN8LDbH7m5JVXJEh3hqp+aLHg1EaW4wJtkoKLCF+DeVIgbSvOLJw"]
}
