/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Verified on P306(US) night light.
=================================================================================================*/

metadata {
	definition (name: "TpLink Child Dimmer", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_child_dimmer.groovy")
	{ }
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed"]
	logData << [commonInst: commonInstalled()]
	logInfo(logData)
	runIn(1, updated)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(devData, data = null) {
	Map logData = [method: "parse_get_device_info"]
	try {
		def onOff = "off"
		if (devData.device_on == true) { onOff = "on" }
		if (device.currentValue("switch") != onOff) {
			sendEvent(name: "switch", value: onOff, type: state.eventType)
			state.eventType = "physical"
		}
		updateAttr("level", devData.brightness)
		logData << [onOff: onOff, level: devData.brightness, status: "OK"]
		logDebug(logData)
	} catch (err) {
		logData << [status: "FAILED", error: err]
		logWarn(logData)
	}
}

#include davegut.tpLinkCapSwitch
#include davegut.tpLinkCapSwitchLevel
#include davegut.tpLinkChildCommon
#include davegut.Logging
