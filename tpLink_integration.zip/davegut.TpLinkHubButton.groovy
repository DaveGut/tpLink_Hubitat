/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Verified on S200B Button.
=================================================================================================*/

metadata {
	definition (name: "TpLink Hub Button", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleInstance: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_button.groovy")
	{
		capability "Refresh"
		capability "Sensor"
		attribute "button", "STRING"
		attribute "lastTriggerNo", "NUMBER"
		attribute "lowBattery", "string"
	}
	preferences {
		input ("getTriggerLogs", "bool", title: "Get Device's last 20 trigger logs", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { runIn(1, updated) }

def updated() {
	if (getTriggerLogs == true) {
		getTriggerLog(20)
	} else {
		unschedule()
		def logData = [method: "updated"]
		logData << setLogsOff()
		def start = Math.round((5) * Math.random()).toInteger()
		schedule("${start}/5 * * * * ?", getTriggerLog)
		logData << [triggerLogInterval: "5 secs"]
		logInfo(logData)
	}
	pauseExecution(5000)
}

def refresh() { parent.refresh() }

//	Parse Methods
def parseDevData(childData) {
	try {
		updateAttr("lowBattery", childData.at_low_battery.toString())
	} catch (err) {
		logWarn([method: "parseDevData", status: "FAILED", error: err])
	}
}

def getTriggerLog(count = 1) {
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_trigger_logs",
				params: [page_size: count,"start_id": 0]
			]
		]
	]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "distTriggerLog")
}

def parseTriggerLog(Map triggerData, data=null) {
	Map triggerLog = triggerData.result.responseData
	if (triggerLog != null) {
		triggerLog = triggerLog.result
		if (triggerLog && device.currentValue("lastTriggerNo") != triggerLog.start_id) {
			updateAttr("lastTriggerNo", triggerLog.start_id)
			def thisTrigger = triggerLog.logs[0]
			def trigger = thisTrigger.event
			if (trigger == "rotation") {
				if (thisTrigger.params.rotate_deg >= 0) {
					trigger = "rotateCW"
				} else {
					trigger = "rotateCCW"
				}
			}
			sendEvent(name: "button", value: trigger, isStateChange: true)
		} else {
			Map logData = [method: "parseTriggerLog", status: "NEW DEVICE.  NO LOGS.",
						   triggerData: triggerData, error: err]
			logDebug(logData)
		}
		if (getTriggerLogs) {
			log.info "<b>TRIGGERLOGS</b>: ${triggerLog.logs}"
			device.updateSetting("getTriggerLogs", [type:"bool", value: false])
		}
	}
}

def devicePollParse(childData) {
	try {
		def contact = "closed"
		if (childData.open) { contact = "open" }
		updateAttr("contact", contact)
		updateAttr("lowBattery", childData.at_low_battery.toString())
	} catch (err) {
		Map logData = [method: "devicePollParse", status: "ERROR",
					   childData: childData, error: err]
		logWarn(logData)
	}
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

#include davegut.Logging
