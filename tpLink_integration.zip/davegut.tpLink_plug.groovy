/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug.groovy")
	{
		capability "Switch"
		attribute "commsError", "string"
	}
	preferences {
		commonPreferences()
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
		input ("autoOffEnable", "bool", title: "Enable Auto Off", defaultValue: false)
		input ("autoOffTime", "NUMBER", title: "Auto Off Time (minutes)", defaultValue: 120)
		input ("defState", "enum", title: "Power Loss Default State",
			   options: ["lastState", "on", "off"], defaultValue: "lastState")
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging", defaultValue: true)
	}
}

def installed() {
	runIn(5, updated)
}

def updated() { 
	commonUpdated() }

def delayedUpdates() {
	Map logData = [method: "delayedUpdates"]
	logData << [autoOff: [enable: autoOffEnable, delay: autoOffTime]]
	List requests =  [[method: "set_auto_off_config",
					   params: [enable:autoOffEnable,
								delay_min: autoOffTime.toInteger()]]]
	
	requests << [method: "get_auto_off_config"]

	logData << [ledRule: ledRule]
	requests << [method: "get_led_info"]

	logData << [defState: defState]
	def type = "last_states"
	def state = []
	if (defState == "on") {
		type = "custom"
		state = [on: true]
	} else if (defState == "off") {
		type = "custom"
		state = [on: false]
	}
	logData << [nameSync: nameSync]
	if (nameSync == "Hubitat") {
		def nickname = device.getLabel().bytes.encodeBase64().toString()
		requests << [method: "set_device_info",
					 params: [
						 default_states: [type: type, state: state],
						 nickname: nickname]]
	} else {
		requests << [method: "set_device_info",
					 params: [
						 default_states: [type: type, state: state]]]
	}
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "delayedUpdates", "parseUpdates")
	logInfo(logData)
	runIn(5, refresh)
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		def devData = respData.cmdResp
		if (devData.result.responses) {
			devData = devData.result.responses.find{it.method == "get_device_info"}
		}
		try {
			def onOff = "off"
			if (devData.result.device_on == true) { onOff = "on" }
			if (device.currentValue("switch") != onOff) {
				sendEvent(name: "switch", value: onOff, type: state.eventType)
				state.eventType = "physical"
			}
		} catch (err) {
			logData << [status: "parseError", devData: devData, error: err]
			logWarn(logData)
		}
	} else {
		logData << [status: "respERROR", respData: respData]
		logWarn(logData)
	}
	logDebug(logData)
}

#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.Logging
