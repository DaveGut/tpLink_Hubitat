library (
	name: "lib_tpLink_CapSwitch",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat Capability Switch Methods for TPLink SMART devices.",
	category: "utilities",
	documentationLink: ""
)

def on() {
	setPower(true)
}

def off() {
	setPower(false)
}

def setPower(onOff) {
	state.eventType = "digital"
	logDebug("setPower: [device_on: ${onOff}]")
	List requests = [[
		method: "set_device_info",
		params: [device_on: onOff]]]
	requests << [method: "get_device_info"]
	if (getDataValue("capability") == "plug_em") {
		requests << [method:"get_energy_usage"]
	}
	asyncSend(createMultiCmd(requests), "setPower", "deviceParse")
}

def setLevel(level, transTime=null) {
	//	Note: Tapo Devices do not support transition time.  Set preference "Set Bulb to Gradual ON/OFF"
	if (transTime != null) {
		logWarn("setLevel: Dimmer level duration not supported.  Use Preference Set Gradual On/Off.")
	}
	logDebug("setLevel: [brightness: ${level}]")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			brightness: level
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setLevel", "deviceParse")
}

def startLevelChange(direction) {
	logDebug("startLevelChange: [level: ${device.currentValue("level")}, direction: ${direction}]")
	if (direction == "up") { levelUp() }
	else { levelDown() }
}

def stopLevelChange() {
	logDebug("stopLevelChange: [level: ${device.currentValue("level")}]")
	unschedule(levelUp)
	unschedule(levelDown)
}

def levelUp() {
	def curLevel = device.currentValue("level").toInteger()
	if (curLevel != 100) {
		def newLevel = curLevel + 4
		if (newLevel > 100) { newLevel = 100 }
		setLevel(newLevel)
		runIn(1, levelUp)
	}
}

def levelDown() {
	def curLevel = device.currentValue("level").toInteger()
	if (device.currentValue("switch") == "on") {
		def newLevel = curLevel - 4
		if (newLevel <= 0) { off() }
		else {
			setLevel(newLevel)
			runIn(1, levelDown)
		}
	}
}
