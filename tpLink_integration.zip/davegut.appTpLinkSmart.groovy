library (
	name: "appTpLinkSmart",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Kasa IOT devices.",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def createTpLinkCreds() {
	Map SMARTCredData = [:]
	
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "password", value: encUsername])
	SMARTCredData << [encUsername: encUsername]
	
	String encPassword = userPassword.bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "password", value: encPassword])
	SMARTCredData << [encPassword: encPassword]

	String encPasswordVac = mdEncode("MD5", userPassword.bytes).encodeHex().toString().toUpperCase()
	app?.updateSetting("encPasswordVac", [type: "password", value: encPasswordVac])
	SMARTCredData << [encPasswordVac: encPasswordVac]

	def userHash = mdEncode("SHA-1", encodeUtf8(userName).getBytes())
	def passwordHash = mdEncode("SHA-1", encodeUtf8(userPassword).getBytes())
	byte[] klapLocalHash = [userHash, passwordHash].flatten()
	String localHash = mdEncode("SHA-256", klapLocalHash).encodeBase64().toString()
	app?.updateSetting("localHash", [type: "password", value: localHash])
	SMARTCredData << [localHash: localHash]

	return [SMARTDevCreds: SMARTCredData]
}

def findTpLinkDevices(action, timeout = 10) {
	Map logData = [method: "findTpLinkDevices", action: action, timeOut: timeout]
	def start = state.hostArray.min().toInteger()
	def finish = state.hostArray.max().toInteger() + 1
	logData << [hostArray: state.hostArray, pollSegment: state.segArray]
	List deviceIPs = []
	state.segArray.each {
		def pollSegment = it.trim()
		logData << [pollSegment: pollSegment]
           for(int i = start; i < finish; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
		await = sendLanCmd(deviceIPs.join(','), "20002", cmdData, action, timeout)
		
		logDebug("findTpLinkDevices: [startFinding:[segment: ${pollSegment}]]")
		app?.updateSetting("finding", true)
		int i
		for(i = 0; i < 30; i++) {
			if (i == 29) {
				logWarn("findTpLinkDevices: [findingError:[segment: ${pollSegment}]]")
			}
			pauseExecution(1000)
			if (finding == false) {
				pauseExecution(5000)
				i = 31
			}
		}
		logDebug("<b>findTpLinkDevices: [segment: ${pollSegment}, finding: complete]</b>")
	}
	app?.updateSetting("finding", false)
	return logData
}

def getTpLinkLanData(response) {
	Map logData = [method: "getTpLinkLanData", response: response.size()]
	logDebug(logData)
	List discData = []
	if (response instanceof Map) {
		Map devData = getDiscData(response)
		if (devData.status == "OK") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	getAllTpLinkDeviceData(discData)
	
	app?.updateSetting("finding", false)
	runIn(30, updateTpLinkDevices, [data: discData])
	logDebug(logData)
}

def getDiscData(response) {
	Map devData = [method: "getDiscData"]
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			if (payloadString.length() > 1007) {
				payloadString = payloadString + """"}}}"""
			}
			Map payload = new JsonSlurper().parseText(payloadString).result
			List supported = supportedProducts()
			if (supported.contains(payload.device_type)) {
				def protocol = payload.mgt_encrypt_schm.encrypt_type
				def port = payload.mgt_encrypt_schm.http_port
				def dni = payload.mac.replaceAll("-", "")
				def baseUrl = "http://${payload.ip}:${payload.mgt_encrypt_schm.http_port}/app"
				if (payload.device_type == "SMART.TAPOROBOVAC") {
					baseUrl = "https://${payload.ip}:${payload.mgt_encrypt_schm.http_port}"
					protocol = "vacAes"
				}
				devData << [
					type: payload.device_type, model: payload.device_model,
					baseUrl: baseUrl, dni: dni, devId: payload.device_id, 
					ip: payload.ip, port: port, protocol: protocol, status: "OK"]
			} else {
				devData << [type: payload.device_type, model: payload.device_model, 
							status: "INVALID", reason: "Device not supported."]
			}
		}
		logInfo(devData)
	} catch (err) {
		devData << [status: "INVALID", respData: repsData, error: err]
		logDebug(devData)
	}
	return devData
}

def getAllTpLinkDeviceData(List discData) {
	//	Modified to only get detailed data from new Hubitat devices.
	Map logData = [method: "getAllTpLinkDeviceData", discData: discData.size()]
	discData.each { Map devData ->
		def childDev = getChildDevice(devData.dni)
		if (!childDev) {
			logData << ["${devData.dni}": [model: devData.model, status: "addingToDevices"]]
			if (devData.protocol == "KLAP") {
				klapHandshake(devData.baseUrl, localHash, devData)
			} else if (devData.protocol == "AES") {
				aesHandshake(devData.baseUrl, devData)
			} else if (devData.protocol == "vacAes") {
				vacAesHandshake(devData.baseUrl, devData)
			}
			pauseExecution(500)
		} else {
			logData << ["${devData.dni}": [model: devData.model, status: "alreadyInstalled"]]
		}
	}
	logDebug(logData)
}

def getDataCmd() {
	List requests = [[method: "get_device_info"]]
	requests << [method: "component_nego"]
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def addToDevices(devData, cmdResp) {
	Map logData = [method: "addToDevices"]
	String dni = devData.dni
	def components = cmdResp.find { it.method == "component_nego" }
	cmdResp = cmdResp.find { it.method == "get_device_info" }
	cmdResp = cmdResp.result
	byte[] plainBytes = cmdResp.nickname.decodeBase64()
	def alias = new String(plainBytes)
	if (alias == "") { alias = cmdResp.model }
	def ctHigh
	def ctLow
	def driver = "Plug"
	def comps = components.result.component_list
	comps.each { cap ->
		switch(cap.id) {
			case "control_child":
				if (devData.type.contains("HUB")) {
					driver = "Hub"
				} else if (devData.type.contains("PLUG") || devData.type.contains("SWITCH")) {
					driver = "Parent"
				}
				break
			case "energy_monitoring":
				driver = "Plug EM"
				break
			case "brightness": 
				if (!cmdResp.color_temp_range) {
					driver = "Dimmer"
				}
				break
			case "color":
				if (comps.find {it.id == "light_strip" }) {
					driver = "Lightstrip"
				} else {
					driver = "Color Bulb"
				}
				break
			case "color_temperature":
				ctHigh = cmdResp.color_temp_range[1]
				ctLow = cmdResp.color_temp_range[0]
				break
			case "clean":
				driver = "Robovac"
				break
		}
	}
	def devicesData = atomicState.tpLinkDevices
	Map deviceData = [deviceType: devData.type, protocol: devData.protocol, 
					  model: devData.model, baseUrl: devData.baseUrl, alias: alias, 
					  type: driver]
	if (ctHigh != null) {
		deviceData << [ctHigh: ctHigh, ctLow: ctLow]
	}
	devicesData << ["${dni}": deviceData]
	
	atomicState.tpLinkDevices = devicesData
	logData << ["${deviceData.alias}": deviceData, dni: dni]
	logDebug(logData)
}

//	===== get Smart KLAP Protocol Data =====
def sendKlapDataCmd(handshakeData, data) {
	if (handshakeData.respStatus != "Login OK") {
		Map logData = [method: "sendKlapDataCmd", handshake: handshakeData]
		logWarn(logData)
	} else {
		Map reqParams = [timeout: 10, headers: ["Cookie": data.data.cookie]]
		def seqNo = data.data.seqNo + 1
		String cmdBodyJson = new groovy.json.JsonBuilder(getDataCmd()).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), data.data.encKey, 
										data.data.encIv, data.data.encSig, seqNo)
		reqParams << [uri: "${data.data.baseUrl}/request?seq=${encryptedData.seqNumber}",
					  body: encryptedData.cipherData,
					  contentType: "application/octet-stream",
					  requestContentType: "application/octet-stream"]
		asyncPost(reqParams, "parseKlapResp", data.data)
	}
}

def parseKlapResp(resp, data) {
	Map logData = [method: "parseKlapResp"]
	if (resp.status == 200) {
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse, data.data.encKey,
										data.data.encIv, data.data.seqNo + 1)
			Map cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== get Smart AES Protocol Data =====
def getAesToken(resp, data) {
	Map logData = [method: "getAesToken"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				def clearResp = aesDecrypt(resp.json.result.response, data.encKey, data.encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					logDebug(logData)
					sendAesDataCmd(token, data)
				} else {
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					logWarn(logData)
				}
			} catch (err) {
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				logWarn(logData)
			}
		} else {
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		logWarn(logData)
	}
}

def sendAesDataCmd(token, data) {
	def cmdStr = JsonOutput.toJson(getDataCmd()).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, data.encKey, data.encIv)]]
	Map reqParams = [uri: "${data.baseUrl}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10, 
					 headers: ["Cookie": data.cookie]]
	asyncPost(reqParams, "parseAesResp", data)
}

def parseAesResp(resp, data) {
	Map logData = [method: "parseAesResp"]
	if (resp.status == 200) {
		try {
			Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
																 data.data.encKey, data.data.encIv))
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== get Smart VAC Protocol Data =====
def vacAesHandshake(baseUrl, devData) {
	Map reqData = [baseUrl: baseUrl, devData: devData]
	Map cmdBody = [method: "login",
				   params: [hashed: true, 
							password: encPasswordVac,
							username: userName]]
	Map reqParams = [uri: baseUrl,
					 ignoreSSLIssues: true,
					 body: cmdBody,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10]
	asyncPost(reqParams, "parseVacAesLogin", reqData)
}

def parseVacAesLogin(resp, data) {
	Map logData = [method: "parseVacAesLogin", oldToken: token]
	if (resp.status == 200 && resp.json != null) {
		logData << [status: "OK"]
		logData << [token: resp.json.result.token]
		sendVacDataCmd(resp.json.result.token, data)
		logDebug(logData)
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

def sendVacDataCmd(token, data) {
	Map devData = data.data.devData
	Map reqParams = [uri: "${data.data.baseUrl}/?token=${token}",
					 body: getDataCmd(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 ignoreSSLIssues: true,
					 timeout: 10]
	asyncPost(reqParams, "parseVacResp", devData)
}

def parseVacResp(resp, devData) {
	Map logData = [parseMethod: "parseVacResp"]
	try {
		Map cmdResp = resp.json
		logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(devData.data, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
	} catch (err) {
		logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		logWarn(logData)
	}
	return parseData	
}

def tpLinkCheckForDevices(timeout = 5) {
	Map logData = [method: "tpLinkCheckForDevices"]
	if (state.tpLinkChecked == true) {
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		def findData = findTpLinkDevices("parseTpLinkCheck", timeout)
		logData << [status: "checking"]
	}
	return logData
}

def resetTpLinkChecked() { state.tpLinkChecked = false }

def parseTpLinkCheck(response) {
	List discData = []
	if (response instanceof Map) {
		Map devdata = getDiscData(response)
		if (devData.status != "INVALID") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	updateTpLinkDevices(discData)
}

def updateTpLinkDevices(discData) {
	Map logData = [method: "updateTpLinkDevices"]
	state.tpLinkChecked = true
	runIn(570, resetTpLinkChecked)
	List children = getChildDevices()
	children.each { childDev ->
		Map childData = [:]
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (childDev.getDataValue("baseUrl")) {
			if (devData != null) {
				if (childDev.getDataValue("baseUrl") == devData.baseUrl &&
				    childDev.getDataValue("protocol") == devData.protocol) {
					childData << [status: "noChanges"]
				} else {
					childDev.updateDataValue("baseUrl", devData.baseUrl)
					childDev.updateDataValue("protocol", devData.protocol)
					childData << ["baseUrl": devData.baseUrl,
								  "protocol": devData.protocol,
								  "connected": "true"]
				}
			} else {
				childData << [connected: "false", reason: "not Discovered By App"]
				logWarn(logData)
			}
			pauseExecution(500)
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
logInfo(logData)
}
