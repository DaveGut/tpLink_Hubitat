/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Verified on H100(US).
=================================================================================================*/
//	=====	NAMESPACE	in library davegut.Logging	============

metadata {
	definition (name: "TpLink Hub", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub.groovy")
	{
		capability "Alarm"
		command "configureAlarm", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		attribute "alarmConfig", "JSON_OBJECT"
	}
	preferences {
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
		commonPreferences()
		input ("installChild", "bool", title: "Install Child Device", defaultValue: true)
	}
}

def alarmTypes() {
	 return [
		 "Doorbell Ring 1", "Doorbell Ring 2", "Doorbell Ring 3", "Doorbell Ring 4",
		 "Doorbell Ring 5", "Doorbell Ring 6", "Doorbell Ring 7", "Doorbell Ring 8",
		 "Doorbell Ring 9", "Doorbell Ring 10", "Phone Ring", "Alarm 1", "Alarm 2",
		 "Alarm 3", "Alarm 4", "Alarm 5", "Dripping Tap", "Connection 1", "Connection 2"
	 ] 
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	if (installChild) {
		logData << [children: "installing"]
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def updated() { 
	Map logData = [method: updated, installChild: installChild,
				   commonUpdated: commonUpdated()]
	if (installChild) {
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def both() { siren() }
def strobe() { siren() }

def siren() {
	List requests = [[method: "play_alarm"]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "on", "parseUpdates")
}

def off() {
	List requests =[[method: "stop_alarm"]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "off", "parseUpdates")
}

def configureAlarm(alarmType, volume, duration=30) {
	logDebug("configureAlarm: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration.toInteger()
				 ]]]
	requests << [method: "get_alarm_configure"]
	sendDevCmd(requests, "configureAlarm", "parseUpdates")
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data]
	def alarm = result.in_alarm
	updateAttr("alarm", alarm)
	logData << [alarm: alarm]
	if (alarm == true) {
		runIn(5, refresh)
	}
	logDebug(logData)
}

def parse_get_alarm_configure(result, data) {
	Map logData = [method: "parse_get_alarm_configure", data: data]
	updateAttr("alarmConfig", result)
	logData << [alarmConfig: result]
	logDebug(logData)
}

//	===== Child Command Response =====
def parse_get_child_device_list(result, data) {
	Map logData = [method: "get_child_device_list",data: data]
	def children = getChildDevices()
	children.each { child ->
		def devId = child.getDataValue("deviceId")
		def childData = result.child_device_list.find{ it.device_id == devId }
		child.parseDevData(childData)
	}
	logData << [status: "OK"]
	logDebug(logData)
}

def distTriggerLog(resp, data) {
	def triggerData = parseData(resp).cmdResp
	def child = getChildDevice(data.data)
	child.parseTriggerLog(triggerData)
}

//	Code for version 2.3.9 only to allow transition
def sensorPoll() {
	asyncSend([method:"get_child_device_list"], "sensorPoll", "sensorParse")
}
def sensorParse(resp, data=null) {
	Map logData = [method: "sensorParse"]
	def respData = parseData(resp)
	try {
		def childrenData = respData.cmdResp.result.child_device_list
		def children = getChildDevices()
		children.each { child ->
			def devId = child.getDataValue("deviceId")
			def childData = childrenData.find{ it.device_id == devId }
			child.devicePollParse(childData)
		}
		logData << [status: "OK"]
	} catch (err) {
		logData << [status: "ERROR", error: err]
	}
	logDebug(logData)
}

//	===== Install Methods Unique to Hub =====
#include davegut.tpLinkCommon
#include davegut.tpLinkChildInst
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.Logging
