library (
	name: "tpLinkChildCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common Child driver methods including capability Refresh and Configuration methods",
	category: "utilities",
	documentationLink: ""
)

capability "Refresh"

def commonPreferences() {
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	state.eventType = "digital"
	return logData
}

def commonUpdated() {
	Map logData = [logging: setLogsOff()]
	refresh()
	return logData
}

//	===== Data Distribution (and parse) =====
def distChildData(respData, data) {
	respData.each {
		if (it.error_code == 0) {
			if (!it.method.contains("set_")) {
				distChildGetData(it, data)
			} else {
				logDebug([devMethod: it.method])
			}
		} else {
			logWarn(["${it.method}": [status: "cmdFailed", data: it]])
		}
	}
}

def distChildGetData(devData, data) {
	switch(devData.method) {
		case "get_device_info":
			parse_get_device_info(devData.result, data)
			break
		default: 
			Map logData = [method: "distGetData", data: data,
						   devMethod: devResp.method, status: "unprocessed"]
			logDebug(logData)
	}
}

//	===== Refresh /Misc =====
def refresh() { parent.refresh() }

def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def sendDevCmd(requests, data, action) {
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: createMultiCmd(requests)]]
	parent.asyncSend(cmdBody, device.getDeviceNetworkId(), "childRespDist")
}

def sendSingleCmd(request, data, action) {
	Map cmdBody = [method: "control_child",
				   params: [device_id: getDataValue("deviceId"),
							requestData: request]]
	parent.asyncSend(cmdBody, data, action)
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}
