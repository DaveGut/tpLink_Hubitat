/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_hub", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub.groovy")
	{
		capability "Switch"
		command "configureAlarm", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		command "playAlarmConfig", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		attribute "alarmConfig", "JSON_OBJECT"
		attribute "commsError", "string"
	}
	preferences {
		input ("sensorPollInterval", "enum", title: "Sensor Poll Interval",
			   options: ["5 sec", "10 sec", "30 sec", "1 min"], defaultValue: "1 min")
		commonPreferences()
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "device")
		input ("installChild", "bool", title: "Install Child Device", defaultValue: true)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [method: "delayedUpdates"]
	logData << [ledRule: ledRule]
	List requests = [[method: "get_led_info"]]
	
	logData << [updateAlarmConfig: device.currentValue("alarmConfig")]
	requests << [method: "get_alarm_configure"]

	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "delayedUpdates", "parseUpdates")
	logInfo(logData)
	if (installChild) {
		runIn(5, installChildDevices)
	}
	runIn(10, parentRefresh)
}

def setSensorPollInterval(pInterval = sensorPollInterval) {
	def logData = [method: "setSensorPollInterval", interval: pInterval]
	if (pInterval.contains("sec")) {
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", sensorPoll)
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", sensorPoll)
	}
	logInfo(logData)
}

def sensorPoll() {
	asyncSend([method:"get_child_device_list"], "sensorPoll", "sensorParse")
}

def sensorParse(resp, data=null) {
	Map logData = [method: "sensorParse"]
	def respData = parseData(resp)
	try {
		def childrenData = respData.cmdResp.result.child_device_list
		def children = getChildDevices()
		children.each { child ->
			def devId = child.getDataValue("deviceId")
			def childData = childrenData.find{ it.device_id == devId }
			child.devicePollParse(childData)
		}
		logData << [status: "OK"]
	} catch (err) {
		logData << [status: "ERROR", error: err]
	}
	logDebug(logData)
}

def on() {
	logDebug("on: play default alarm configuraiton")
	List requests = [[method: "play_alarm"]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "on", "alarmParse")
}

def off() {
	logDebug("off: stop alarm")
	List requests =[[method: "stop_alarm"]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "off", "alarmParse")
}

def configureAlarm(alarmType, volume, duration=30) {
	logDebug("configureAlarm: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "configureAlarm", "alarmParse")
}

def playAlarmConfig(alarmType, volume, duration=30) {
	logDebug("playAlarmConfig: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "play_alarm"]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "playAlarmConfig", "alarmParse")
}

def alarmParse(resp, data) {
	def  devData = parseData(resp).cmdResp.result
	logDebug("alarmParse: ${devData}")
	if (devData && devData.responses) {
		def alarmData = devData.responses.find{it.method == "get_alarm_configure"}.result
		updateAttr("alarmConfig", alarmData)
		def devInfo = devData.responses.find{it.method == "get_device_info"}
		if (devInfo) {
			def inAlarm = devInfo.result.in_alarm
			def onOff = "off"
			if (inAlarm == true) {
				onOff = "on"
				runIn(alarmData.duration + 1, refresh)
			}
			updateAttr("switch", onOff)
		}
	} else {
		updateAttr("alarmConfig", devData)
	}
}

def alarmTypes() {
	 return [
		 "Doorbell Ring 1", "Doorbell Ring 2", "Doorbell Ring 3", "Doorbell Ring 4",
		 "Doorbell Ring 5", "Doorbell Ring 6", "Doorbell Ring 7", "Doorbell Ring 8",
		 "Doorbell Ring 9", "Doorbell Ring 10", "Phone Ring", "Alarm 1", "Alarm 2",
		 "Alarm 3", "Alarm 4", "Alarm 5", "Dripping Tap", "Connection 1", "Connection 2"
	 ] 
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		Map devData = respData.cmdResp.result
		try {
			def onOff = "off"
			if (devData.in_alarm == true) { onOff = "on" }
			updateAttr("switch", onOff)
			logData << [switch: onOff]
			logDebug(logData)
		} catch (err) {
			logData << [status: "parseError", devData: devData, error: err]
			logWarn(logData)
		}
	} else {
		logData << [status: "respERROR", respData: respData]
		logWarn(logData)
	}
}

//	===== Parent Install and Utilities =====
def distTriggerLog(resp, data) {
	def triggerData = parseData(resp)
	def child = getChildDevice(data.data)
	child.parseTriggerLog(triggerData)
}

def installChildDevices() {
	Map logData = [method: "installChildDevices"]
	asyncSend([method: "get_child_device_list"], "installChildDevices", "installChildren")
	logInfo(logData)
}
def installChildren(resp, data=null) {
	Map logData = [method: "installChildren"]
	def respData = parseData(resp)
	def children = respData.cmdResp.result.child_device_list
	children.each {
		String childDni = it.mac
		Map instData = [childDni: childDni]
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			instData << [status: "device already installed"]
		} else {
			String model = it.model
			String category = it.category
			String driver = getDriverId(category, model)
			String deviceId = it.device_id
			instData << [model: model, category: category, driver: driver] 
			try {
				addChildDevice(nameSpace(), driver, childDni,
							   [label: alias, category: it.category, 
								name: model, deviceId : deviceId])
				instData << [status: "Installed"]
			} catch (e) {
				instData << [status: "FAILED", error: err]
			}
		}
		logData << ["${alias}": instData]
		pauseExecution(2000)
	}
	device.updateSetting("installChild", [type: "bool", value: "false"])
	logInfo(logData)
}

def getDriverId(category, model) {
	def driver = "tpLink_hub-NewType"
	switch(category) {
		case "subg.trigger.contact-sensor":
			driver = "tpLink_hub_contact"
			break
		case "subg.trigger.motion-sensor":
			driver = "tpLink_hub_motion"
			break
		case "subg.trigger.button":
			if (model == "S200B") {
				driver = "tpLink_hub_button"
			}
			//	Note: Installing only sensor version for now.  Need data to install D version.
			break
		case "subg.trigger.temp-hmdt-sensor":
			driver = "tpLink_hub_tempHumidity"
			break
		case "subg.trigger":
		case "subg.trigger.water-leak-sensor":
		case "subg.plugswitch":
		case "subg.plugswitch.plug":
		case "subg.plugswitch.switch":
		case "subg.trv":
		default:
			driver = "tapoHub-NewType"
	}
	return driver
}

//	===== Install Methods Unique to Hub =====
#include davegut.lib_tpLink_common
#include davegut.Logging
