library (
	name: "tpLinkCapSwitch",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat capability Switch methods",
	category: "utilities",
	documentationLink: ""
)

capability "Switch"

def on() { setPower(true) }

def off() { setPower(false) }

def setPower(onOff) {
	state.eventType = "digital"
	logDebug("setPower: [device_on: ${onOff}]")
	List requests = [[
		method: "set_device_info",
		params: [device_on: onOff]]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, "setPower", "parseUpdates") 
	if (getDataValue("type") == "Plug EM") {
		runIn(5, plugEmRefresh)
	}
}
