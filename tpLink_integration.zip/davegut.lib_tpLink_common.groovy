library (
	name: "lib_tpLink_common",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to tpLink device DRIVERS",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.Cipher
import java.security.KeyFactory
import java.util.Random
import java.security.MessageDigest

capability "Refresh"
capability "Configuration"

def commonPreferences() {
	input ("nameSync", "enum", title: "Synchronize Names",
		   options: ["none": "Don't synchronize",
					 "device" : "TP-Link device name master",
					 "Hubitat" : "Hubitat label master"],
		   defaultValue: "none")
	input ("pollInterval", "enum", title: "Poll Interval (< 1 min can cause issues)",
		   options: ["5 sec", "10 sec", "30 sec", "1 min", "10 min", "15 min", "30 min"],
		   defaultValue: "30 min")
	input ("rebootDev", "bool", title: "Reboot Device then run Save Preferences", defaultValue: false)

	input ("encKey", "password", title: "Crypto key. Do not edit.")
	input ("encIv", "password", title: "Crypto vector. Do not edit.")
	input ("cookie", "password", title: "Session cookie. Do not edit.")
	if (getDataValue("protocol") == "KLAP") {
		input ("encSig", "password", title: "KLAP signature. Do not edit.")
	} else {
		input ("token", "password", title: "AES token. Do not edit.")
	}
}

def commonUpdated() {
	unschedule()
	Map logData = [:]
	if (rebootDev == true) {
		runIn(1, rebootDevice)
		device.updateSetting("rebootDev",[type:"bool", value: false])
		pauseExecution(15000)
	}
	updateAttr("commsError", "false")
	state.errorCount = 0
	state.lastCmd = ""
	logData << [pollInterval: setPollInterval()]
	logData << [loginInterval: setLoginInterval()]
	logData << setLogsOff()
	logData << [deviceLogin: deviceLogin()]
	if (logData.status == "ERROR") {
		logWarn("updated: ${logData}")
	} else {
		logInfo("updated: ${logData}")
	}
	runIn(10, delayedUpdates)
}

def rebootDevice() {
	asyncSend([method: "device_reboot"], "rebootDevice", "rebootParse")
}
def rebootParse(resp, data=null) {
	def respData = parseData(resp).cmdResp
	Map logData = [method: "rebootParse", data: data, respData: respData]
	logInfo(logData)
}

def setPollInterval(pInterval = pollInterval) {
	def method = "commonRefresh"
	if (getDataValue("capability") == "plug_multi") {
		method = "parentRefresh"
	} else if (getDataValue("capability") == "plug_em") {
		method = "emRefresh"
	}
	if (pInterval.contains("sec")) {
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", method)
		logInfo("setPollInterval: Polling intervals of less than one minute " +
				"can take high resources and may impact hub performance.")
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", method)
	}
	if (getDataValue("capability") == "hub") {
		def sInterval = pInterval
		if (sInterval == pollInterval) {
			sInterval = sensorPollInterval
		}
		setSensorPollInterval(sInterval)
	}
	return pInterval
}

def setLoginInterval() {
	def startS = Math.round((59) * Math.random()).toInteger()
	def startM = Math.round((59) * Math.random()).toInteger()
	def startH = Math.round((11) * Math.random()).toInteger()
	schedule("${startS} ${startM} ${startH}/12 * * ?", "deviceLogin")
	return "12 hrs"
}

def parseUpdates(resp, data= null) {
	Map logData = [method: "parseUpdates"]
	def respData = parseData(resp).cmdResp
	if (respData.error_code == 0) {
		respData.result.responses.each {
			if (it.error_code == 0) {
				switchParse(it)
			} else {
				logData << ["${it.method}": [status: "cmdFailed", data: it]]
			}
		}
	} else {
		logData << [status: "invalidRequest", data: respData]
	}
	logInfo(logData)
}
	
def switchParse(devResp) {
	Map logData = [method: switchParse]
	def doLog = true
	switch(devResp.method) {
		case "get_device_info":
			if (devResp.result.default_states) {
				def defaultStates = devResp.result.default_states
				def newState = "lastState"
				if (defaultStates.type == "custom"){
					newState = "off"
					if (defaultStates.state.on == true) {
						newState = "on"
					}
				}
				device.updateSetting("defState", [type: "enum", value: newState])
				logData << [deviceMethod: devResp.method, defState: newState]
			}

			if (nameSync == "device") {
				byte[] plainBytes = devResp.result.nickname.decodeBase64()
				String label = new String(plainBytes)
				device.setLabel(label)
				logData << [deviceMethod: devResp.method, 
							nickname: devResp.result.nickname, label: label]
			}
			device.updateSetting("nameSync", [type: "enum", value: "none"])
			break
		
		case "get_led_info":
			logData << [deviceMethod: devResp.method]
			if (ledRule != devResp.result.led_rule) {
				Map requests = [
					method: "set_led_info",
					params: [
						led_rule: ledRule,
						//	Uses mode data from device.  This driver does not update these.
						night_mode: [
							night_mode_type: devResp.result.night_mode.night_mode_type,
							sunrise_offset: devResp.result.night_mode.sunrise_offset, 
							sunset_offset:devResp.result.night_mode.sunset_offset,
							start_time: devResp.result.night_mode.start_time,
							end_time: devResp.result.night_mode.end_time
						]]]
				asyncSend(requests, "delayedUpdates", "parseUpdates")
				device.updateSetting("ledRule", [type:"enum", value: ledRule])
				logData << [status: "updatingLedRule"]
			}
			logData << [ledRule: ledRule]
			break

		case "get_auto_off_config":
			device.updateSetting("autoOffTime", [type: "number", value: devResp.result.delay_min])
			device.updateSetting("autoOffEnable", [type: "bool", value: devResp.result.enable])
			logData << [deviceMethod: devResp.method, autoOffTime: devResp.result.delay_min,
						autoOffEnable: devResp.result.enable]
			break

		case "get_on_off_gradually_info":
			def newGradualOnOff = devResp.result.enable
			device.updateSetting("gradualOnOff",[type:"bool", value: newGradualOnOff])
			logData << [deviceMethod: devResp.method, gradualOnOff: newGradualOnOff]
			break

		case "get_protection_power":
			def protectPower = devResp.result.protection_power
			def enabled = devResp.result.enabled
			device.updateSetting("pwrProtectWatts", [type: "number", 
													 value: protectPower])
			device.updateSetting("powerProtect", [type: "bool", value: enabled])
			logData << [powerProtect: enabled, pwrProtectWatts: protectPower]
			break

		case "get_alarm_configure":
			updateAttr("alarmConfig", devResp.result)
			logData << [alarmConfig: devResp.result]
			break

		case "set_led_info":
		case "set_device_info":
		case "set_auto_off_config":
		case "set_on_off_gradually_info":
			doLog = false
			break
		default:
			logData << [status: "unhandled", devResp: devResp]
	}

	if (doLog) { logInfo(logData) }
}

//	===== Capability Refresh =====
def refresh() {
	if (getDataValue("capability") == "plug_multi") {
		parentRefresh()
	} else if (getDataValue("capability") == "plug_em") {
		emRefresh()
	} else {
		commonRefresh()
	}
}

def commonRefresh() {
	asyncSend([method: "get_device_info"], "commonRefresh", "deviceParse")
}

def emRefresh() {
	List requests = [[method: "get_device_info"]]
	requests << [method:"get_energy_usage"]
	asyncSend(createMultiCmd(requests), "emRefresh", "deviceParse")
}

def parentRefresh() {
	List requests = [[method: "get_device_info"]]
	requests << [method:"get_child_device_list"]
	asyncSend(createMultiCmd(requests), "parentRefresh", "deviceParse")
}

//	===== Capability Configuration =====
def configure() {
	Map logData = [method: "configure", updateData: parent.tpLinkCheckForDevices(5)]
	device.updateSetting("rebootDev",[type:"bool", value: true])
	updated()
	logData << [action: "updated"]
	logInfo(logData)
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

//	===== Login =====
def deviceLogin() {
	Map logData = [protocol: getDataValue("protocol")]
	if (getDataValue("protocol") == "KLAP") {
		def uri = "${getDataValue("baseUrl")}/handshake1"
		byte[] localSeed = new byte[16]
		new Random().nextBytes(localSeed)
		def body = localSeed.encodeBase64().toString()
		Map staticData = [localSeed: localSeed]
		asyncPost(uri, localSeed, "application/octet-stream", 
				  "parseKlapHandshake", null, staticData)
	} else {
		def rsaKeys = getRsaKeys()
		Map reqData = [rsaKeyNo: rsaKeys.keyNo]
		def pubPem = "-----BEGIN PUBLIC KEY-----\n${rsaKeys.public}-----END PUBLIC KEY-----\n"
		Map cmdBody = [ method: "handshake", params: [ key: pubPem]]
		String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()
		asyncPost(getDataValue("baseUrl"), cmdBodyJson, "application/json", 
				  "parseAesHandshake", null, reqData)
	}
	return logData
}

//	===== AES Handshake and Login =====
def parseAesHandshake(resp, data){
	Map logData = [method: "parseAesHandshake"]
	def respStatus = "ERROR"
	if (resp.status == 200 && resp.data != null) {
		Map cmdResp =  new JsonSlurper().parseText(resp.data)
		Map rsaKeys = keyData().find { it.keyNo == data.data.rsaKeyNo }
		String deviceKey = cmdResp.result.key
		def cookieHeader = resp.headers["Set-Cookie"].toString()
		def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
		logData << [cookie: cookie]
		device.updateSetting("cookie",[type:"password", value: cookie])
		Map aesArray = readAesDeviceKey(deviceKey, rsaKeys.private)
		logData << [aesArray: aesArray]
		if (aesArraystatus == "ERROR") {
			logData << [check: "privateKey"]
			logWarn(logData)
		} else {
			respStatus = "OK"
			byte[] encKey = aesArray.cryptoArray[0..15]
			device.updateSetting("encKey",[type:"password", value: encKey])
			byte[] encIv = aesArray.cryptoArray[16..31]
			device.updateSetting("encIv",[type:"password", value: encIv])
			logData << [encKey: encKey, encIv: encIv]
			
			Map cmdBody = [method: "login_device",
						   params: [password: parent.encPassword,
									username: parent.encUsername],
						   requestTimeMils: 0]
			def cmdStr = JsonOutput.toJson(cmdBody).toString()
			def encrString = aesEncrypt(cmdStr, encKey, encIv)
			Map reqBody = [method: "securePassthrough", 
						   params: [request: encrString]]
			asyncPost(getDataValue("baseUrl"), reqBody, "application/json", 
					  "parseAesLogin", cookie, null)
		}
	} else {
		logData << [errorData: respData]
		logWarn(logData)
	}
	logData << [respStatus: respStatus]
	logDebug(logData)
}

def readAesDeviceKey(deviceKey, privateKey) {
	def status = "ERROR"
	Map logData = [:]
	try {
		byte[] privateKeyBytes = privateKey.decodeBase64()
		byte[] deviceKeyBytes = deviceKey.getBytes("UTF-8").decodeBase64()
    	Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
		instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
		byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
		logData << [cryptoArray: cryptoArray]
		status = "OK"
	} catch (err) {
		logData << [errorData: err]
	}
	logData << [keyStatus: status]
	return logData
}

def parseAesLogin(resp, data) {
	Map logData = [method: "parseAesLogin"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				byte[] encKey = new JsonSlurper().parseText(encKey)
				byte[] encIv = new JsonSlurper().parseText(encIv)
				def clearResp = aesDecrypt(resp.json.result.response, encKey, encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					device.updateSetting("token",[type:"password", value: token])
				} else {
					logData << [respStatus: "ERROR", error_code: cmdResp.error_code,
								  check: "cryptoArray, credentials", data: cmdResp]
					logWarn(logData)
				}
			} catch (err) {
				logData << [respStatus: "ERROR", error: err]
				logWarn(logData)
			}
		} else {
			logData << [respStatus: "ERROR", data: respData.data]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR", data: respData]
	}
	logDebug(logData)
}

//	===== KLAP Handshake and Login =====
def parseKlapHandshake(resp, data=null) {
	Map logData = [method: "parseKlapHandshake"]
	def validated = false
	if (resp.status == 200 && resp.data != null) {
		def cookieHeader = resp.headers["Set-Cookie"].toString()
		def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
		//	Validate data
		byte[] localSeed = data.data.localSeed
		byte[] seedData = resp.data.decodeBase64()
		byte[] remoteSeed = seedData[0 .. 15]
		byte[] serverHash = seedData[16 .. 47]
		byte[] localHash = parent.localHash.decodeBase64()
		byte[] authHash = [localSeed, remoteSeed, localHash].flatten()
		byte[] localAuthHash = mdEncode("SHA-256", authHash)
		if (localAuthHash == serverHash) {
			validated = true
			logData << [sessionData: createKlapSessionData(localSeed, remoteSeed,
														   localHash, cookie)]
			def uri = "${getDataValue("baseUrl")}/handshake2"
			byte[] loginHash = [remoteSeed, localSeed, localHash].flatten()
			byte[] body = mdEncode("SHA-256", loginHash)
			
			asyncPost(uri, body, "application/octet-stream",
					  "parseKlapLogin", cookie, null)
		}
	} else {
		logData << [status: "ERROR", resp: resp, data: data]
	}
	logData << [validated: validated]
	logDebug(logData)
}

def createKlapSessionData(localSeed, remoteSeed, localHash, cookie) {
	Map sessionData = [:]
	//	seqNo and encIv
	byte[] payload = ["iv".getBytes(), localSeed, remoteSeed, localHash].flatten()
	byte[] fullIv = mdEncode("SHA-256", payload)
	byte[] byteSeqNo = fullIv[-4..-1]
	int seqNo = byteArrayToInteger(byteSeqNo)
	state.seqNo = seqNo
	sessionData << [seqNo: seqNo]
	device.updateSetting("encIv",[type:"password", value: fullIv[0..11]])
	device.updateSetting("cookie",[type:"password", value: cookie])
	sessionData << [encIv: fullIv[0..11], cookie: cookie]
	//	KEY
	payload = ["lsk".getBytes(), localSeed, remoteSeed, localHash].flatten()
	byte[] encKey = mdEncode("SHA-256", payload)[0..15]
	device.updateSetting("encKey",[type:"password", value: encKey])
	sessionData << [encKey: encKey]
	//	SIG
	payload = ["ldk".getBytes(), localSeed, remoteSeed, localHash].flatten()
	byte[] encSig = mdEncode("SHA-256", payload)[0..27]
	device.updateSetting("encSig",[type:"password", value: encSig])
	sessionData << [encSig: encSig]
	return sessionData
}

def parseKlapLogin(resp, data) {
	Map logData = [method: "parseKlapLogin"]
	def loginSuccess = false
	if (resp.status == 200) {
		loginSuccess = true 
	} else {
		LogData << [errorData: resp.properties]
	}
	logData << [loginSuccess: loginSuccess]
	logDebug(logData)
}

//	===== Protocol specific encrytion/decryption =====
def klapEncrypt(byte[] request, encKey, encIv, encSig, seqNo) {
	byte[] encSeqNo = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeqNo].flatten()

	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	byte[] cipherRequest = cipher.doFinal(request)

	byte[] payload = [encSig, encSeqNo, cipherRequest].flatten()
	byte[] signature = mdEncode("SHA-256", payload)
	cipherRequest = [signature, cipherRequest].flatten()
	return [cipherData: cipherRequest, seqNumber: seqNo]
}

def aesEncrypt(request, encKey, encIv) {
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
	SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
	cipher.init(Cipher.ENCRYPT_MODE, key, iv)
	String result = cipher.doFinal(request.getBytes("UTF-8")).encodeBase64().toString()
	return result.replace("\r\n","")
}

def klapDecrypt(cipherResponse, encKey, encIv, seqNo) {
	byte[] encSeq = integerToByteArray(seqNo)
	byte[] ivEnc = [encIv, encSeq].flatten()

	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(ivEnc)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	byte[] byteResponse = cipher.doFinal(cipherResponse)
	return new String(byteResponse, "UTF-8")
}

def aesDecrypt(cipherResponse, encKey, encIv) {
    byte[] decodedBytes = cipherResponse.decodeBase64()
	def cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    SecretKeySpec key = new SecretKeySpec(encKey, "AES")
	IvParameterSpec iv = new IvParameterSpec(encIv)
    cipher.init(Cipher.DECRYPT_MODE, key, iv)
	String result = new String(cipher.doFinal(decodedBytes), "UTF-8")
	return result
}

//	===== RSA Key Methods =====
def getRsaKeys() {
	def keyNo = Math.round(5 * Math.random()).toInteger()
	def keyData = keyData()
	def RSAKeys = keyData.find { it.keyNo == keyNo }
	return RSAKeys
}

def keyData() {
	//	Keys used for discovery.
	return [
		[
			keyNo: 0,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGr/mHBK8aqx7UAS+g+TuAvE3J2DdwsqRn9MmAkjPGNon1ZlwM6nLQHfJHebdohyVqkNWaCECGXnftnlC8CM2c/RujvCrStRA0lVD+jixO9QJ9PcYTa07Z1FuEze7Q5OIa6pEoPxomrjxzVlUWLDXt901qCdn3/zRZpBdpXzVZtQIDAQAB",
			private: "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMav+YcErxqrHtQBL6D5O4C8TcnYN3CypGf0yYCSM8Y2ifVmXAzqctAd8kd5t2iHJWqQ1ZoIQIZed+2eULwIzZz9G6O8KtK1EDSVUP6OLE71An09xhNrTtnUW4TN7tDk4hrqkSg/GiauPHNWVRYsNe33TWoJ2ff/NFmkF2lfNVm1AgMBAAECgYEAocxCHmKBGe2KAEkq+SKdAxvVGO77TsobOhDMWug0Q1C8jduaUGZHsxT/7JbA9d1AagSh/XqE2Sdq8FUBF+7vSFzozBHyGkrX1iKURpQFEQM2j9JgUCucEavnxvCqDYpscyNRAgqz9jdh+BjEMcKAG7o68bOw41ZC+JyYR41xSe0CQQD1os71NcZiMVqYcBud6fTYFHZz3HBNcbzOk+RpIHyi8aF3zIqPKIAh2pO4s7vJgrMZTc2wkIe0ZnUrm0oaC//jAkEAzxIPW1mWd3+KE3gpgyX0cFkZsDmlIbWojUIbyz8NgeUglr+BczARG4ITrTV4fxkGwNI4EZxBT8vXDSIXJ8NDhwJBAIiKndx0rfg7Uw7VkqRvPqk2hrnU2aBTDw8N6rP9WQsCoi0DyCnX65Hl/KN5VXOocYIpW6NAVA8VvSAmTES6Ut0CQQCX20jD13mPfUsHaDIZafZPhiheoofFpvFLVtYHQeBoCF7T7vHCRdfl8oj3l6UcoH/hXMmdsJf9KyI1EXElyf91AkAvLfmAS2UvUnhX4qyFioitjxwWawSnf+CewN8LDbH7m5JVXJEh3hqp+aLHg1EaW4wJtkoKLCF+DeVIgbSvOLJw"
		],[
			keyNo: 1,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCshy+qBKbJNefcyJUZ/3i+3KyLji6XaWEWvebUCC2r9/0jE6hc89AufO41a13E3gJ2es732vaxwZ1BZKLy468NnL+tg6vlQXaPkDcdunQwjxbTLNL/yzDZs9HRju2lJnupcksdJWBZmjtztMWQkzBrQVeSKzSTrKYK0s24EEXmtQIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKyHL6oEpsk159zIlRn/eL7crIuOLpdpYRa95tQILav3/SMTqFzz0C587jVrXcTeAnZ6zvfa9rHBnUFkovLjrw2cv62Dq+VBdo+QNx26dDCPFtMs0v/LMNmz0dGO7aUme6lySx0lYFmaO3O0xZCTMGtBV5IrNJOspgrSzbgQRea1AgMBAAECgYBSeiX9H1AkbJK1Z2ZwEUNF6vTJmmUHmScC2jHZNzeuOFVZSXJ5TU0+jBbMjtE65e9DeJ4suw6oF6j3tAZ6GwJ5tHoIy+qHRV6AjA8GEXjhSwwVCyP8jXYZ7UZyHzjLQAK+L0PvwJY1lAtns/Xmk5GH+zpNnhEmKSZAw23f7wpj2QJBANVPQGYT7TsMTDEEl2jq/ZgOX5Djf2VnKpPZYZGsUmg1hMwcpN/4XQ7XOaclR5TO/CJBJl3UCUEVjdrR1zdD8g8CQQDPDoa5Y5UfhLz4Ja2/gs2UKwO4fkTqqR6Ad8fQlaUZ55HINHWFd8FeERBFgNJzszrzd9BBJ7NnZM5nf2OPqU77AkBLuQuScSZ5HL97czbQvwLxVMDmLWyPMdVykOvLC9JhPgZ7cvuwqnlWiF7mEBzeHbBx9JDLJDd4zE8ETBPLgapPAkAHhCR52FaSdVQSwfNjr1DdHw6chODlj8wOp8p2FOiQXyqYlObrOGSpkH8BtuJs1sW+DsxdgR5vE2a2tRYdIe0/AkEAoQ5MzLcETQrmabdVCyB9pQAiHe4yY9e1w7cimsLJOrH7LMM0hqvBqFOIbSPrZyTp7Ie8awn4nTKoZQtvBfwzHw=="
		],[
			keyNo: 2,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCBeqRy4zAOs63Sc5yc0DtlFXG1stmdD6sEfUiGjlsy0S8aS8X+Qcjcu5AK3uBBrkVNIa8djXht1bd+pUof5/txzWIMJw9SNtNYqzSdeO7cCtRLzuQnQWP7Am64OBvYkXn2sUqoaqDE50LbSQWbuvZw0Vi9QihfBYGQdlrqjCPUsQIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIF6pHLjMA6zrdJznJzQO2UVcbWy2Z0PqwR9SIaOWzLRLxpLxf5ByNy7kAre4EGuRU0hrx2NeG3Vt36lSh/n+3HNYgwnD1I201irNJ147twK1EvO5CdBY/sCbrg4G9iRefaxSqhqoMTnQttJBZu69nDRWL1CKF8FgZB2WuqMI9SxAgMBAAECgYBBi2wkHI3/Y0Xi+1OUrnTivvBJIri2oW/ZXfKQ6w+PsgU+Mo2QII0l8G0Ck8DCfw3l9d9H/o2wTDgPjGzxqeXHAbxET1dS0QBTjR1zLZlFyfAs7WO8tDKmHVroUgqRkJgoQNQlBSe1E3e7pTgSKElzLuALkRS6p1jhzT2wu9U04QJBAOFr/G36PbQ6NmDYtVyEEr3vWn46JHeZISdJOsordR7Wzbt6xk6/zUDHq0OGM9rYrpBy7PNrbc0JuQrhfbIyaHMCQQCTCvETjXCMkwyUrQT6TpxVzKEVRf1rCitnNQCh1TLnDKcCEAnqZT2RRS3yNXTWFoJrtuEHMGmwUrtog9+ZJBlLAkEA2qxdkPY621XJIIO404mPgM7rMx4F+DsE7U5diHdFw2fO5brBGu13GAtZuUQ7k2W1WY0TDUO+nTN8XPDHdZDuvwJABu7TIwreLaKZS0FFJNAkCt+VEL22Dx/xn/Idz4OP3Nj53t0Guqh/WKQcYHkowxdYmt+KiJ49vXSJJYpiNoQ/NQJAM1HCl8hBznLZLQlxrCTdMvUimG3kJmA0bUNVncgUBq7ptqjk7lp5iNrle5aml99foYnzZeEUW6jrCC7Lj9tg+w=="
		],[
			keyNo: 3,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCFYaoMvv5kBxUUbp4PQyd7RoZlPompsupXP2La0qGGxacF98/88W4KNUqLbF4X5BPqxoEA+VeZy75qqyfuYbGQ4fxT6usE/LnzW8zDY/PjhVBht8FBRyAUsoYAt3Ip6sDyjd9YzRzUL1Q/OxCgxz5CNETYxcNr7zfMshBHDmZXMQIDAQAB",
			private: "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIVhqgy+/mQHFRRung9DJ3tGhmU+iamy6lc/YtrSoYbFpwX3z/zxbgo1SotsXhfkE+rGgQD5V5nLvmqrJ+5hsZDh/FPq6wT8ufNbzMNj8+OFUGG3wUFHIBSyhgC3cinqwPKN31jNHNQvVD87EKDHPkI0RNjFw2vvN8yyEEcOZlcxAgMBAAECgYA3NxjoMeCpk+z8ClbQRqJ/e9CC9QKUB4bPG2RW5b8MRaJA7DdjpKZC/5CeavwAs+Ay3n3k41OKTTfEfJoJKtQQZnCrqnZfq9IVZI26xfYo0cgSYbi8wCie6nqIBdu9k54nqhePPshi22VcFuOh97xxPvY7kiUaRbbKqxn9PFwrYQJBAMsO3uOnYSJxN/FuxksKLqhtNei2GUC/0l7uIE8rbRdtN3QOpcC5suj7id03/IMn2Ks+Vsrmi0lV4VV/c8xyo9UCQQCoKDlObjbYeYYdW7/NvI6cEntgHygENi7b6WFk+dbRhJQgrFH8Z/Idj9a2E3BkfLCTUM1Z/Z3e7D0iqPDKBn/tAkBAHI3bKvnMOhsDq4oIH0rj+rdOplAK1YXCW0TwOjHTd7ROfGFxHDCUxvacVhTwBCCw0JnuriPEH81phTg2kOuRAkAEPR9UrsqLImUTEGEBWqNto7mgbqifko4T1QozdWjI10K0oCNg7W3Y+Os8o7jNj6cTz5GdlxsHp4TS/tczAH7xAkBY6KPIlF1FfiyJAnBC8+jJr2h4TSPQD7sbJJmYw7mvR+f1T4tsWY0aGux69hVm8BoaLStBVPdkaENBMdP+a07u"
		],[
			keyNo: 4,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQClF0yuCpo3r1ZpYlGcyI5wy5nnvZdOZmxqz5U2rklt2b8+9uWhmsGdpbTv5+qJXlZmvUKbpoaPxpJluBFDJH2GSpq3I0whh0gNq9Arzpp/TDYaZLb6iIqDMF6wm8yjGOtcSkB7qLQWkXpEN9T2NsEzlfTc+GTKc07QXHnzxoLmwQIDAQAB",
			private: "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKUXTK4KmjevVmliUZzIjnDLmee9l05mbGrPlTauSW3Zvz725aGawZ2ltO/n6oleVma9Qpumho/GkmW4EUMkfYZKmrcjTCGHSA2r0CvOmn9MNhpktvqIioMwXrCbzKMY61xKQHuotBaRekQ31PY2wTOV9Nz4ZMpzTtBcefPGgubBAgMBAAECgYB4wCz+05RvDFk45YfqFCtTRyg//0UvO+0qxsBN6Xad2XlvlWjqJeZd53kLTGcYqJ6rsNyKOmgLu2MS8Wn24TbJmPUAwZU+9cvSPxxQ5k6bwjg1RifieIcbTPC5wHDqVy0/Ur7dt+JVMOHFseR/pElDw471LCdwWSuFHAKuiHsaUQJBANHiPdSU3s1bbJYTLaS1tW0UXo7aqgeXuJgqZ2sKsoIEheEAROJ5rW/f2KrFVtvg0ITSM8mgXNlhNBS5OE4nSD0CQQDJXYJxKvdodeRoj+RGTCZGZanAE1naUzSdfcNWx2IMnYUD/3/2eB7ZIyQPBG5fWjc3bGOJKI+gy/14bCwXU7zVAkAdnsE9HBlpf+qOL3y0jxRgpYxGuuNeGPJrPyjDOYpBwSOnwmL2V1e7vyqTxy/f7hVfeU7nuKMB5q7z8cPZe7+9AkEAl7A6aDe+wlE069OhWZdZqeRBmLC7Gi1d0FoBwahW4zvyDM32vltEmbvQGQP0hR33xGeBH7yPXcjtOz75g+UPtQJBAL4gknJ/p+yQm9RJB0oq/g+HriErpIMHwrhNoRY1aOBMJVl4ari1Ch2RQNL9KQW7yrFDv7XiP3z5NwNDKsp/QeU="
		],[
			keyNo: 5,
			public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChN8Xc+gsSuhcLVM1W1E+e1o+celvKlOmuV6sJEkJecknKFujx9+T4xvyapzyePpTBn0lA9EYbaF7UDYBsDgqSwgt0El3gV+49O56nt1ELbLUJtkYEQPK+6Pu8665UG17leCiaMiFQyoZhD80PXhpjehqDu2900uU/4DzKZ/eywwIDAQAB",
			private: "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKE3xdz6CxK6FwtUzVbUT57Wj5x6W8qU6a5XqwkSQl5yScoW6PH35PjG/JqnPJ4+lMGfSUD0RhtoXtQNgGwOCpLCC3QSXeBX7j07nqe3UQtstQm2RgRA8r7o+7zrrlQbXuV4KJoyIVDKhmEPzQ9eGmN6GoO7b3TS5T/gPMpn97LDAgMBAAECgYAy+uQCwL8HqPjoiGR2dKTI4aiAHuEv6m8KxoY7VB7QputWkHARNAaf9KykawXsNHXt1GThuV0CBbsW6z4U7UvCJEZEpv7qJiGX8UWgEs1ISatqXmiIMVosIJJvoFw/rAoScadCYyicskjwDFBVNU53EAUD3WzwEq+dRYDn52lqQQJBAMu30FEReAHTAKE/hvjAeBUyWjg7E4/lnYvb/i9Wuc+MTH0q3JxFGGMb3n6APT9+kbGE0rinM/GEXtpny+5y3asCQQDKl7eNq0NdIEBGAdKerX4O+nVDZ7PXz1kQ2ca0r1tXtY/9sBDDoKHP2fQAH/xlOLIhLaH1rabSEJYNUM0ohHdJAkBYZqhwNWtlJ0ITtvSEB0lUsWfzFLe1bseCBHH16uVwygn7GtlmupkNkO9o548seWkRpnimhnAE8xMSJY6aJ6BHAkEAuSFLKrqGJGOEWHTx8u63cxiMb7wkK+HekfdwDUzxO4U+v6RUrW/sbfPNdQ/FpPnaTVdV2RuGhg+CD0j3MT9bgQJARH86hfxp1bkyc7f1iJQT8sofdqqVz5grCV5XeGY77BNmCvTOGLfL5pOJdgALuOoP4t3e94nRYdlW6LqIVugRBQ=="
		]
	]
}

//	===== Encoding Methods =====
def mdEncode(hashMethod, byte[] data) {
	MessageDigest md = MessageDigest.getInstance(hashMethod)
	md.update(data)
	return md.digest()
}

String encodeUtf8(String message) {
	byte[] arr = message.getBytes("UTF8")
	return new String(arr)
}

int byteArrayToInteger(byte[] byteArr) {
	int arrayASInteger
	try {
		arrayAsInteger = ((byteArr[0] & 0xFF) << 24) + ((byteArr[1] & 0xFF) << 16) +
			((byteArr[2] & 0xFF) << 8) + (byteArr[3] & 0xFF)
	} catch (error) {
		Map errLog = [byteArr: byteArr, ERROR: error]
		logWarn("byteArrayToInteger: ${errLog}")
	}
	return arrayAsInteger
}

byte[] integerToByteArray(value) {
	String hexValue = hubitat.helper.HexUtils.integerToHexString(value, 4)
	byte[] byteValue = hubitat.helper.HexUtils.hexStringToByteArray(hexValue)
	return byteValue
}

//	===== Communications =====
def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

//	===== ASYNC Post =====
def asyncSend(cmdBody, reqData, action) {
	Map cmdData = [cmdBody: cmdBody, reqData: reqData, action: action]
	state.lastCmd = cmdData
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	if (getDataValue("protocol") == "KLAP") {
		byte[] encSig = new JsonSlurper().parseText(encSig)
		String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()
		int seqNo = state.seqNo + 1
		state.seqNo = seqNo
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv, encSig, seqNo)
		def uri = "${getDataValue("baseUrl")}/request?seq=${encryptedData.seqNumber}"
		asyncPost(uri, encryptedData.cipherData, "application/octet-stream",
				  action, cookie, reqData)
	} else {
		def uri = "${getDataValue("baseUrl")}?token=${token}"
		def cmdStr = JsonOutput.toJson(cmdBody).toString()
		Map reqBody = [method: "securePassthrough",
					   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
		def body = new groovy.json.JsonBuilder(reqBody).toString()
		asyncPost(uri, body, "application/json",
				  action, cookie, reqData)
	}
}
def asyncPost(uri, body, contentType, parseMethod, cookie=null, reqData=null) {
	def reqParams = [
		uri: uri,
		body: body,
		contentType: contentType,
		requestContentType: contentType,
		headers: [
			"Cookie": cookie,
		],
		timeout: 8
	]
	Map logData = [method: "asyncPost", uri: uri, contentType: contentType,
				   parseMethod: parseMethod, cookie: cookie, reqData: reqData]
	try {
		asynchttpPost(parseMethod, reqParams, [data: reqData])
		logData << [status: "OK"]
		logDebug(logData)
	} catch (err) {
		logData << [status: "FAILED", error: err, ]
		logWarn(logData)
	}
}
def parseData(resp) {
	def logData = [method: "parseData"]
	if (resp.status == 200) {
		try {
			Map cmdResp
			byte[] encKey = new JsonSlurper().parseText(encKey)
			byte[] encIv = new JsonSlurper().parseText(encIv)
			if (getDataValue("protocol") == "KLAP") {
				byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
				int seqNo = state.seqNo				
				cmdResp =  new JsonSlurper().parseText(klapDecrypt(cipherResponse, encKey, encIv, seqNo))
			} else {
				cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response, encKey, encIv))
			}
			logData << [status: "OK", cmdResp: cmdResp]
			state.errorCount = 0
			setCommsError(false)
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			runIn(1, handleCommsError, [data: "deviceDataParseError"])
		}
	} else {
		logData << [status: "httpFailure(timeout)", data: resp.properties]
		runIn(1, handleCommsError, [data: "httpFailure(timeout)"])
	}
	logDebug(logData)
	return logData
}

//	===== Error Handling =====
def handleCommsError(retryReason) {
	Map logData = [method: "handleCommsError", retryReason: retryReason]
	if (state.lastCmd != "") {
		def count = state.errorCount + 1
		state.errorCount = count
		def cmdData = new JSONObject(state.lastCmd)
		def cmdBody = parseJson(cmdData.cmdBody.toString())
		Map data = [cmdBody: cmdBody, method: cmdBody.method, action: cmdBody.action]
		logData << [count: count, command: cmdBody]
		switch (count) {
			case 1:
				pauseExecution(2000)
				Map loginData = deviceLogin()
				logData << [retryLogin: loginData.loginStatus, action: "retryCommand"]
				runIn(1, delayedPassThrough, [data:data])
				break
			case 2:
				logData << [updateData: parent.tpLinkCheckForDevices(5), action: "retryCommand"]
				runIn(3, delayedPassThrough, [data:data])
			case 3:
				logData << [status: setCommsError(true)]
				logWarn(logData)
				break
			default:
				logData << [status: "retriesDisabled"]
				break
		}
	} else {
		logData << [status: "noCommandToRetry"]
	}
	logInfo(logData)
}

def delayedPassThrough(data) {
	asyncSend(data.cmdBody, data.method, data.action)
}

def setCommsError(status) {
	if (device.currentValue("commsError") == true && status == false) {
		updateAttr("commsError", false)
		setPollInterval("25 min")
	} else if (device.currentValue("commsError") == false && status == true) {
		updateAttr("commsError", true)
		setPollInterval()
	}
}
