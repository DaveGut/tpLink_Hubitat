library (
	name: "tpLinkCapSwitchLevel",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat capability Switch Level and Change Level methods",
	category: "utilities",
	documentationLink: ""
)

capability "Switch Level"
capability "Change Level"

def setLevel(level, transTime=0) {
	logDebug([method: "setLevel", level: level, transTime: transTime])
	if (level == null) { level = device.currentValue("level") toInteger() }
	if (transTime < 0) { transTime = 0 }
	if (transTime > 0) {
		startLevelTransition(level, transTime)
	} else {
		if (level == 0) {
			off()
		} else {
			List requests = [[
				method: "set_device_info",
				params: [
					brightness: level
				]]]
			requests << [method: "get_device_info"]
			sendDevCmd(requests, "setLevel", "parseUpdates")
		}
	}
}

def startLevelTransition(level, transTime) {
	def startTime = (now()/1000).toInteger()
	def endTime = startTime + transTime
	Map transData = [endTime: endTime, targetLevel: level, cmdIncr: 180]
	//	Command increment derived from experimentation with Tapo Lan devices.
	def totalIncrs = (transTime * 5).toInteger()
	
	//	Level Increment (based on total level Change, cmdIncr, and transTime)
	def currLevel = device.currentValue("level").toInteger()
	def levelChange = level - currLevel
	def levelIncr = levelChange/totalIncrs
	if (levelIncr < 0 ) { levelIncr = (levelIncr - 0.5).toInteger() }
	else { levelIncr = (levelIncr + 0.5).toInteger() }
	transData << [currLevel: currLevel, levelIncr: levelIncr]
	
	logDebug([method: "startCtTransition", transData: transData])
	doLevelTransition(transData)
}

def doLevelTransition(Map transData) {
	def newLevel = transData.targetLevel
	def doAgain = true
	def curTime = (now()/1000).toInteger()
	if (newLevel == transData.currLevel || curTime >= transData.endTime) {
		doAgain = false
	} else {
		newLevel = transData.currLevel + transData.levelIncr
		if (transData.levelIncr >= 0 && newLevel > transData.targetLevel) {
			newLevel = transData.targetLevel
		} else if (transData.levelIncr < 0 && newLevel < transData.targetLevel) {
			newLevel = transData.targetLevel
		}
	}
	transData << [currLevel: newLevel]
	if (currLevel != 0) {
		sendSingleCmd([method: "set_device_info", params: [brightness: newLevel]],
				  "doLevelTransition", "nullParse")
		if (doAgain == true) {
			runInMillis(transData.cmdIncr, doLevelTransition, [data: transData])
		} else {
			runInMillis(500, setLevel, [data: transData.targetLevel])
		}
	} else {
		off()
	}
}

def startLevelChange(direction) {
	logDebug("startLevelChange: [level: ${device.currentValue("level")}, direction: ${direction}]")
	if (direction == "up") { levelUp() }
	else { levelDown() }
}

def stopLevelChange() {
	logDebug("stopLevelChange: [level: ${device.currentValue("level")}]")
	unschedule(levelUp)
	unschedule(levelDown)
}

def levelUp() {
	def curLevel = device.currentValue("level").toInteger()
	if (curLevel != 100) {
		def newLevel = curLevel + 4
		if (newLevel > 100) { newLevel = 100 }
		setLevel(newLevel)
		runIn(1, levelUp)
	}
}

def levelDown() {
	def curLevel = device.currentValue("level").toInteger()
	if (device.currentValue("switch") == "on") {
		def newLevel = curLevel - 4
		if (newLevel <= 0) { off() }
		else {
			setLevel(newLevel)
			runIn(1, levelDown)
		}
	}
}
