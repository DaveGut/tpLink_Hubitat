/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_bulb_color", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_bulb_color.groovy")
	{
		capability "Light"
		capability "Switch"
		capability "Switch Level"
		capability "Change Level"
		capability "Color Temperature"
		capability "Color Mode"
		capability "Color Control"
		attribute "commsError", "string"
	}
	preferences {
		commonPreferences()
		input ("gradualOnOff", "bool", title: "Set Gradual ON/OFF", defaultValue: false)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [method: "delayedUpdates"]
	logData << [gradualOnOff: gradualOnOff]
	List requests = [[method: "set_on_off_gradually_info",
					  params: [enable: gradualOnOff]]]
	requests << [method: "get_on_off_gradually_info"]
	
	logData << [nameSync: nameSync]
	def nickname = device.getLabel().bytes.encodeBase64().toString()
	requests << [method: "set_device_info", params: [nickname: nickname]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "delayedUpdates", "parseUpdates")
	logInfo(logData)
	runIn(5, refresh)
}

def setColorTemperature(colorTemp, level = device.currentValue("level"), transTime=null) {
	//	Note: Tapo Devices do not support transition time.  Set preference "Set Bulb to Gradual ON/OFF"
	if (transTime != null) {
		logWarn("setColorTemperature: Dimmer level duration not supported.  Use Preference Set Gradual On/Off.")
	}
	logDebug("setColorTemperature: [level: ${level}, colorTemp: ${colorTemp}]")
	def lowCt = getDataValue("ctLow").toInteger()
	def highCt = getDataValue("ctHigh").toInteger()
	if (colorTemp < lowCt) { colorTemp = lowCt }
	else if (colorTemp > highCt) { colorTemp = highCt }
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			brightness: level,
			color_temp: colorTemp
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setColorTemperature", "deviceParse")
}

def setHue(hue){
	logDebug("setHue: ${hue}")
	hue = (3.6 * hue).toInteger()
	logDebug("setHue: ${hue}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setHue", "deviceParse")
}

def setSaturation(saturation) {
	logDebug("setSatiratopm: ${saturation}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			saturation: saturation,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setSaturation", "deviceParse")
}

def setColor(color) {
	def hue = (3.6 * color.hue).toInteger()
	logDebug("setColor: ${color}")
	List requests = [[
		method: "set_device_info",
		params: [
			device_on: true,
			hue: hue,
			saturation: color.saturation,
			brightness: color.level,
			color_temp: 0
		]]]
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "setColor", "deviceParse")
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		def devData = respData.cmdResp
		if (devData.result.responses) {
			devData = devData.result.responses.find{it.method == "get_device_info"}
		}
		logData << [devData: devData]
		if (devData != null && devData.error_code == 0) {
			devData = devData.result
			def onOff = "off"
			if (devData.device_on == true) { onOff = "on" }
			if (device.currentValue("switch") != onOff) {
				sendEvent(name: "switch", value: onOff, type: state.eventType)
				state.eventType = "physical"
			}
			updateAttr("level", devData.brightness)
			if (devData.color_temp == 0) {
				updateAttr("colorMode", "COLOR")
				def hubHue = (devData.hue / 3.6).toInteger()
				updateAttr("hue", hubHue)
				updateAttr("saturation", devData.saturation)
				updateAttr("color", "[hue: ${hubHue}, saturation: ${devData.saturation}]")
				updateAttr("colorName", colorName = convertHueToGenericColorName(hubHue))
				def rgb = hubitat.helper.ColorUtils.hsvToRGB([hubHue,
															  devData.saturation,
															  devData.brightness])
				updateAttr("RGB", rgb)
				updateAttr("colorTemperature", 0)
			} else {
				updateAttr("colorMode", "CT")
				updateAttr("colorTemperature", devData.color_temp)
				updateAttr("colorName", convertTemperatureToGenericColorName(devData.color_temp.toInteger()))
				updateAttr("color", "[:]")
				updateAttr("RGB", "[]")
			}
		}
	}
	logDebug(logData)
}

//	Library Inclusion
#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.Logging
