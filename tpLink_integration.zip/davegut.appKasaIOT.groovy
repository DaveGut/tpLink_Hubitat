library (
	name: "appKasaIOT",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Kasa IOT devices.",
	category: "utilities",
	documentationLink: ""
)

//	Kasa Cloud Token (only if useKasaCloud is true)
def getKasaToken() {
	if(!useKasaCloud) { 
		app?.updateSetting("kasaToken", "INVALID")
		return [kasaCloudData: [useKasaCloud: useKasaCloud, kasaToken: "INVALID"]]
	}
	Map logData = [method: "getKasaToken", , userName: userName, userPassword: userPassword]
	Map tokenData = [:]
	def termId = java.util.UUID.randomUUID()
	def cmdBody = [
		method: "login",
		params: [
			appType: "Kasa_Android",
			cloudUserName: "${userName}",
			cloudPassword: "${userPassword.replaceAll('&gt;', '>').replaceAll('&lt;','<')}",
			terminalUUID: "${termId}"]]
	cmdData = [uri: "https://wap.tplinkcloud.com",
			   cmdBody: cmdBody]
	def respData = sendKasaCmd(cmdData)
	if (respData.error_code == 0) {
		token = respData.result.token
		app?.updateSetting("kasaToken", respData.result.token)
		tokenData << [kasaToken: kasaToken]
		
		def cloudUrl = kasaCloudUrl
		if (!kasaCloudUrl) {
			cloudUrl = getCloudUrl()
		}
		tokenData << [kasaCloudUrl: cloudUrl]
		
	} else {
		app?.updateSetting("kasaToken", "INVALID")
		tokenData << [kasaToken: kasaToken]
	}
	logData << tokenData
	logInfo(logData)
	return [kasaCloudData: tokenData]
}

def getCloudUrl() {
	def cloudUrl = "invalid"
	def cmdData = [uri: "https://wap.tplinkcloud.com?token=${kasaToken}", 
				   cmdBody: [method: "getDeviceList"]]
	def respData = sendKasaCmd(cmdData)
	if (respData.error_code == 0) {
		def cloudDevices = respData.result.deviceList
		cloudUrl = cloudDevices[0].appServerUrl
		app?.updateSetting("kasaCloudUrl", cloudUrl)
	} else {
		logData << [Method: "getCloudUrl", error: "Data not returned from Kasa Cloud", data: respData]
		logWarn(logData)
	}
	return cloudUrl
}

//	===== Legacy (IOT) devices =====
def findIOTDevices(action, timeout = 10) {
	def start = state.hostArray.min().toInteger()
	def finish = state.hostArray.max().toInteger() + 1
	Map logData = [method: "findIOTDevices", hostArray: state.hostArray, portArray: state.portArray, 
				   pollSegment: state.segArray, timeout: timeout]
	state.portArray.each {
		def port = it.trim()
		List deviceIPs = []
		state.segArray.each {
			def pollSegment = it.trim()
           for(int i = start; i < finish; i++) {
				deviceIPs.add("${pollSegment}.${i.toString()}")
			}
			logData << ["${pollSegment}": port]
			def cmdData = outputXOR("""{"system":{"get_sysinfo":{}}}""")
			await = sendLanCmd(deviceIPs.join(','), port, cmdData, action, timeout)
			//	Use timeout and pause in tplink app.
			logDebug("findIOTDevices: [startFinding: [port: ${port}, segment: ${pollSegment}]]")
			app?.updateSetting("finding", true)
			int i
			for(i = 0; i < 30; i++) {
				pauseExecution(1000)
				if (i == 29) {
					logWarn("findIOTDevices: [findingError: [port: ${port}, segment: ${pollSegment}]]")
				}
				if (finding == false) {
					pauseExecution(1000)
					i = 31
				}
			}
			logDebug("<b>findIOTDevices: [port: ${port}, segment: ${pollSegment}, finding: complete]</b>")
		}
		logDebug("<b>findIOTDevices: [port: ${port}, finding: complete]</b>")
	}
	logDebug("<b>findIOTDevices: [finding: complete]</b>")
	app?.updateSetting("finding", false)
	return logData
}

def getIOTLanData(response) {
	Map logData = [method: "getIOTLanData", responses: response.size()]
	logDebug(logData)
	if (response instanceof Map) {
		def lanData = parseIOTLanData(response)
		if (lanData.error) { return }
		def cmdResp = lanData.cmdResp
		if (cmdResp.system) {
			cmdResp = cmdResp.system
		}
		def await = parseIOTDeviceData(cmdResp, lanData.ip, lanData.port)
	} else {
		response.each {
			def lanData = parseIOTLanData(it)
			if (lanData.error) { return }
			def cmdResp = lanData.cmdResp
			if (cmdResp.system) {
				cmdResp = cmdResp.system
			}
			def await = parseIOTDeviceData(cmdResp, lanData.ip, lanData.port)
		}
	}
	
	
	app?.updateSetting("finding", false)
	runIn(30, updateTpLinkDevices, [data: discData])
}

def parseIOTLanData(response) {
	def resp = parseLanMessage(response.description)
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		def ip = convertHexToIP(resp.ip)
		def port = convertHexToInt(resp.port)
		def clearResp = inputXOR(resp.payload)
		def cmdResp
		try {
			cmdResp = new JsonSlurper().parseText(clearResp).system.get_sysinfo
		} catch (err) {
			if (clearResp.contains("child_num")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("child_num")-2) + "}}}"
			} else if (clearResp.contains("children")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("children")-2) + "}}}"
			} else if (clearResp.contains("preferred")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("preferred")-2) + "}}}"
			} else {
				logWarn("parseIOTLanData: [error: msg too long, data: ${clearResp}]")
				return [error: "error", reason: "message to long"]
			}
			cmdResp = new JsonSlurper().parseText(clearResp).system.get_sysinfo
		}
		return [cmdResp: cmdResp, ip: ip, port: port]
	} else {
		return [error: "error", reason: "not LAN_TYPE_UDPCLIENT", respType: resp.type]
		logWarn(logData)
	}
}

def findCloudIOTDevices() {
	Map logData = [:]
	if (!useKasaCloud || kasaToken == "INVALID") {
		logData << [useKasaCloud: useKasaCloud, kasaToken: kasaToken]
		logData << [status: "Not executed"]
		return logData
	}
	def message = ""
	def cmdData = [uri: "https://wap.tplinkcloud.com?token=${kasaToken}", 
				   cmdBody: [method: "getDeviceList"]]
	def respData = sendKasaCmd(cmdData)
	def cloudDevices
	def cloudUrl
	if (respData.error_code == 0) {
		cloudDevices = respData.result.deviceList
		cloudUrl = ""
	} else {
		message = "Devices not returned from Kasa Cloud."
		logData << [status: "error getting cloud data", error: message, data: respData]
		logWarn(logData)
		return logData
	}
//	def devicesData = atomicState.devices
	def devicesData = atomicState.iotDevices
	cloudDevices.each { childDev ->
		def devData = devicesData.find { it.value.deviceId == childDev.deviceId }
		if (devData && devData.value.deviceId == childDev.deviceId) {
			logDebug([ignoredDevice: childDev.deviceMac, reason: "already in array"])

		} else if (childDev.deviceType != "IOT.SMARTPLUGSWITCH" &&
				   childDev.deviceType != "IOT.SMARTBULB" && 
				   childDev.deviceType != "IOT.IPCAMERA") {
			logDebug([ignoredDevice: childDev.deviceMac, reason: "unsupported deviceType"])
		} else if (childDev.status == 0) {
			logDebug([ignoredDevice: childDev.deviceMac, reason: "not controllable via cloud"])
		} else {
			cloudUrl = childDev.appServerUrl
			def cmdBody = [
				method: "passthrough",
				params: [
					deviceId: childDev.deviceId,
					requestData: """{"system":{"get_sysinfo":{}}}"""]]
			cmdData = [uri: "${cloudUrl}/?token=${kasaToken}",
					   cmdBody: cmdBody]
			def cmdResp
			respData = sendKasaCmd(cmdData)
			if (respData.error_code == 0) {
				def jsonSlurper = new groovy.json.JsonSlurper()
				cmdResp = jsonSlurper.parseText(respData.result.responseData).system.get_sysinfo
				if (cmdResp.system) {
					cmdResp = cmdResp.system
				}
				def await = parseIOTDeviceData(cmdResp)
			}
		}
	}
	logData << [status: "added cloud-only devices"]
	if (cloudUrl != "" && cloudUrl != kasaCloudUrl) {
		app?.updateSetting("kasaCloudUrl", cloudUrl)
		logData << [kasaCloudUrl: cloudUrl]
	}
	return logData
}

def parseIOTDeviceData(cmdResp, ip = "CLOUD", port = "CLOUD") {
	def logData = [method: "parseIOTDeviceData"]
	def dni
	if (cmdResp.mic_mac) {
		dni = cmdResp.mic_mac
	} else {
		dni = cmdResp.mac.replace(/:/, "")
	}
	def devTest = devicesData.find { it.key == dni }
	if (devTest != null) {
		logData << ["${cmdResp.alias}": [status: "notParsed, Already in database"]]
		return
	}
	def kasaType
	if (cmdResp.mic_type) {
		kasaType = cmdResp.mic_type
	} else {
		kasaType = cmdResp.type
	}
	List supported = supportedProducts()
	if (!supported.contains(kasaType)) {
		logData << ["${kasaType}": "Not Supported"]
		logWarn(logData)
		return
	}
	
	def type = "Kasa Plug Switch"
	def feature = cmdResp.feature
	def ctHigh		//	Commonality with SMART.  Use in driver vice hard-coded values.
	def ctLow		//	Commonality with SMART.  Use in driver vice hard-coded values.
	if (kasaType == "IOT.SMARTPLUGSWITCH") {
		if (cmdResp.dev_name && cmdResp.dev_name.contains("Dimmer")) {
			feature = "dimmingSwitch"
			type = "Kasa Dimming Switch"
		}
	} else if (kasaType == "IOT.SMARTBULB") {
		if (cmdResp.lighting_effect_state) {
			feature = "lightStrip"
			ctHigh = 2500
			ctLow = 9000
			type = "Kasa Light Strip"
		} else if (cmdResp.is_color == 1) {
			feature = "colorBulb"
			ctHigh = 2500
			ctLow = 9000
			type = "Kasa Color Bulb"
		} else if (cmdResp.is_variable_color_temp == 1) {
			feature = "colorTempBulb"
			ctHigh = 2700
			ctLow = 6500
			type = "Kasa CT Bulb"
		} else {
			feature = "monoBulb"
			type = "Kasa Mono Bulb"
		}
	}
	def model = cmdResp.model.substring(0,5)
	def alias = cmdResp.alias
	def deviceId = cmdResp.deviceId
	def plugNo
	def plugId
	def await
	if (cmdResp.children) {
		def childPlugs = cmdResp.children
		childPlugs.each {
			plugNo = it.id
			plugNo = it.id.substring(it.id.length() - 2)
			def childDni = "${dni}${plugNo}"
			plugId = "${deviceId}${plugNo}"
			alias = it.alias
			await = createIOTDevice(childDni, ip, port, type, feature, ctHigh, ctLow, model,
									kasaType, alias, deviceId, plugNo, plugId)
		}
	} else if (model == "HS300") {
		def parentAlias = alias
		for(int i = 0; i < 6; i++) {
			plugNo = "0${i.toString()}"
			def childDni = "${dni}${plugNo}"
			plugId = "${deviceId}${plugNo}"
			def child = getChildDevice(childDni)
			if (child) {
				alias = child.device.getLabel()
			} else {
				alias = "${parentAlias}_${plugNo}_TEMP"
			}
			await = createIOTDevice(childDni, ip, port, type, feature, ctHigh, ctLow, model,
									kasaType, alias, deviceId, plugNo, plugId)
		}
	} else {
		await = createIOTDevice(dni, ip, port, type, feature, ctHigh, ctLow, model,
								kasaType, alias, deviceId, plugNo, plugId)
	}
	logData << [alias: "<b>${alias}</b>", kasaType: kasaType, type: type, ip: ip, 
				port: port, status: "added to array"]
	logDebug(logData)
	return
}

def createIOTDevice(dni, ip, port, type, feature, ctHigh, ctLow, model, kasaType, alias, deviceId, plugNo, plugId) {
	Map logData = [method: "createIOTDevice"]
	def devicesData = atomicState.iotDevices
	Map deviceData = [deviceType: kasaType, protocol: "IOT", model:model, ip: ip, 
					  port: port, alias: alias, type: type, feature: feature, deviceId: deviceId]
	if (plugId != null) {
		deviceData << [plugId: plugId, plugNo: plugNo]
	}
	devicesData << ["${dni}": deviceData]
	
	atomicState.iotDevices = devicesData
	logData << ["${deviceData.alias}": deviceData, dni: dni]
	logDebug(logData)
	return
}

//	===== Update Kasa Child Data =====
def kasaCheckForDevices(timeout = 5) {
	Map logData = [method: "kasaCheckForDevices"]
	def findData = findIOTDevices("getIOTLanData", timeout)
	logData << [status: "checking"]
	state.kasaChecked = true
	runIn(570, resetKasaChecked)
	runIn(10, updateKasaDevices)
	return logData
}

def resetKasaChecked() { state.kasaChecked = false }

def updateKasaDevices() {
//	def devicesData = atomicState.devices
	def devicesData = atomicState.iotDevices
	Map logData = [method: "updateKasaDevices"]
	state.kasaChecked = true
	runIn(570, resetKasaChecked)
	def children = getChildDevices()
	children.each { childDev ->
		def device = devicesData.find {it.key == childDev.getDeviceNetworkId() }
		if (device.value.ip == "CLOUD") {
			logData << [noUpdate: "cloud device"]
		} else {
			childDev.updateAttr("commsError", "false")
			if (childDev.getDataValue("deviceIP") != device.value.ip ||
				childDev.getDataValue("devicePort") != device.value.port.toString()) {
				childDev.updateDataValue("deviceIP", device.value.ip)
				childDev.updateSetting("manualIp", [type:"string", value: device.value.ip])
				childDev.updateDataValue("devicePort", device.value.port.toString())
				childDev.updateSetting("manualPort", [type:"string", value: device.value.port.toString()])
				logData << [ip: device.value.ip, port: device.value.port, connected: true]
			}
		}
	}
	logInfo(logData)
	return
}

//	===== Legacy (IOT) Communications =====
private outputXOR(command) {
	def str = ""
	def encrCmd = ""
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}

private inputXOR(encrResponse) {
	String[] strBytes = encrResponse.split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length-1; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}

def sendKasaCmd(cmdData) {
	def commandParams = [
		uri: cmdData.uri,
		requestContentType: 'application/json',
		contentType: 'application/json',
		headers: ['Accept':'application/json; version=1, */*; q=0.01'],
		body : new groovy.json.JsonBuilder(cmdData.cmdBody).toString()
	]
	def respData
	try {
		httpPostJson(commandParams) {resp ->
			if (resp.status == 200) {
				respData = resp.data
			} else {
				def msg = "sendKasaCmd: <b>HTTP Status not equal to 200.  Protocol error.  "
				msg += "HTTP Protocol Status = ${resp.status}"
				logWarn(msg)
				respData = [error_code: resp.status, msg: "HTTP Protocol Error"]
			}
		}
	} catch (e) {
		def msg = "sendKasaCmd: <b>Error in Cloud Communications.</b> The Kasa Cloud is unreachable."
		msg += "\nAdditional Data: Error = ${e}\n\n"
		logWarn(msg)
		respData = [error_code: 9999, msg: e]
	}
	return respData
}

//	===== Utility methods =====
private String convertHexToIP(hex) {
	[convertHexToInt(hex[0..1]),convertHexToInt(hex[2..3]),convertHexToInt(hex[4..5]),convertHexToInt(hex[6..7])].join(".")
}

private Integer convertHexToInt(hex) { Integer.parseInt(hex,16) }

//	===== IOT Device Sync Support =====
def syncBulbPresets(bulbPresets) {
	logDebug("syncBulbPresets")
	def devicesData = atomicState.devices
	devicesData.each {
		def type = it.value.type
		if (type == "Kasa Color Bulb" || type == "Kasa Light Strip") {
			def child = getChildDevice(it.key)
			if (child) {
				child.updatePresets(bulbPresets)
			}
		}
	}
}

def resetStates(deviceNetworkId) {
	logDebug("resetStates: ${deviceNetworkId}")
	def devicesData = atomicState.devices
	devicesData.each {
		def type = it.value.type
		if (type == "Kasa Light Strip") {
			def child = getChildDevice(it.key)
			if (child && it.key != deviceNetworkId) {
				child.resetStates()
			}
		}
	}
}

def syncEffectPreset(effData, deviceNetworkId) {
	logDebug("syncEffectPreset: ${effData.name} || ${deviceNetworkId}")
	def devicesData = atomicState.devices
	devicesData.each {
		def type = it.value.type
		if (type == "Kasa Light Strip") {
			def child = getChildDevice(it.key)
			if (child && dni != deviceNetworkId) {
				child.updateEffectPreset(effData)
			}
		}
	}
}

def coordinate(cType, coordData, deviceId, plugNo) {
	logDebug("coordinate: ${cType}, ${coordData}, ${deviceId}, ${plugNo}")
	def plugs = atomicState.devices.findAll{ it.value.deviceId == deviceId }
	plugs.each {
		if (it.value.plugNo != plugNo) {
			def child = getChildDevice(it.value.dni)
			if (child) {
				child.coordUpdate(cType, coordData)
				pauseExecution(200)
			}
		}
	}
}
