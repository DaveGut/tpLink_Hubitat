/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	============
def nameSpace() { return "davegut" }
//	================================

metadata {
	definition (name: "tpLink_plug_em", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug_em.groovy")
	{
		capability "Switch"
		capability "Refresh"
		capability "Configuration"
		attribute "commsError", "string"
		capability "EnergyMeter"
		capability "PowerMeter"
		attribute "energyThisMonth", "number"
	}
	preferences {
		commonPreferences()
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
		input ("autoOffEnable", "bool", title: "Enable Auto Off", defaultValue: false)
		input ("autoOffTime", "NUMBER", title: "Auto Off Time (minutes)", defaultValue: 120)
		input ("defState", "enum", title: "Power Loss Default State",
			   options: ["lastState", "on", "off"], defaultValue: "lastState")
		input ("powerProtect", "bool", title: "Enable Power Protection", defaultValue: false)
		input ("pwrProtectWatts", "NUMBER", title: "Power Protection Watts (Max 1660)", 
			   defaultValue: 1000)
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [method: "delayedUpdates"]
	logData << [autoOff: [enable: autoOffEnable, delay: autoOffTime]]
	List requests =  [[method: "set_auto_off_config",
					   params: [enable:autoOffEnable,
								delay_min: autoOffTime.toInteger()]]]
	
	requests << [method: "get_auto_off_config"]
	
	logData << [powerProtection: [protectWatts: pwrProtectWatts,
								  enabled: powerProtect]]
	requests << [[method: "set_protection_power",
				 params: [protection_power: pwrProtectWatts,
						  enabled: powerProtect]]]
	requests << [method: "get_protection_power"]

	logData << [ledRule: ledRule]
	requests << [method: "get_led_info"]

	logData << [defState: defState]
	def type = "last_states"
	def state = []
	if (defState == "on") {
		type = "custom"
		state = [on: true]
	} else if (defState == "off") {
		type = "custom"
		state = [on: false]
	}
	logData << [nameSync: nameSync]
	if (nameSync == "hubitat") {
		def nickname = device.getLabel().bytes.encodeBase64().toString()
		requests << [method: "set_device_info",
					 params: [
						 default_states: [type: type, state: state],
						 nickname: nickname]]
	} else {
		requests << [method: "set_device_info",
					 params: [
						 default_states: [type: type, state: state]]]
	}
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "delayedUpdates", "parseUpdates")
	runEvery30Minutes(emUpdate)
	logData << [emUpdate: "30 Minutes"]
	logInfo(logData)
	runIn(5, refresh)
}

def deviceParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "deviceParse"]
	if (respData.status == "OK") {
		def devicesData = respData.cmdResp
		Map devData = [:]
		Map emData = [:]
		if (devicesData.result.responses) {
			devData = devicesData.result.responses.find{it.method == "get_device_info"}
			emData = devicesData.result.responses.find{it.method == "get_energy_usage"}
		}
		logData << [devData: devData, emData: emData]
		if (devData != null && devData.error_code == 0) {
			devData = devData.result
			def onOff = "off"
			if (devData.device_on == true) { onOff = "on" }
			if (device.currentValue("switch") != onOff) {
				sendEvent(name: "switch", value: onOff, type: state.eventType)
				state.eventType = "physical"
			}
		}
		if (emData != null && emData.error_code == 0) {
			emData = emData.result
			def power = (emData.current_power/1000).toInteger()
			updateAttr("power", power.toString())
		}
	}
	logDebug(logData)
}

def emUpdate() {
	asyncSend([method:"get_energy_usage"], "refresh", "emUpdateParse")
}
def emUpdateParse(resp, data=null) {
	def respData = parseData(resp)
	Map logData = [method: "emUpdateParse"]
	if (respData.status == "OK") {
		def emData = respData.cmdResp
		if (emData.result.responses) {
			emData = emData.result.responses.find{it.method == "get_energy_usage"}
		}
		logData << [emData: emData]
		if (emData != null && emData.error_code == 0) {
			emData = emData.result
			def energy = emData.today_energy/1000
			updateAttr("energy", energy.toString())
			updateAttr("energyThisMonth", emData.month_energy.toString())
		}
	}
	logDebug(logData)
}

#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.Logging
