/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Verified on L530E(US) and L535E(US).
=================================================================================================*/
//	=====	NAMESPACE	in library davegut.Logging	============

metadata {
	definition (name: "TpLink Color Bulb", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_bulb_color.groovy")
	{
		capability "Light"
	}
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	logInfo(logData)
}

def updated() {
	device.removeSetting("ledRule")
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data]
	if (result.device_on != null) {
		def onOff = "off"
		if (result.device_on == true) { onOff = "on" }
		sendEvent(name: "switch", value: onOff, type: state.eventType)
		state.eventType = "physical"
		logData << [switch: onOff]
	}
	if (result.brightness != null) {
		updateAttr("level", result.brightness)
		logData << [level: result.brightness]
	}
	if (result.color_temp != null) {
		if (result.color_temp == 0) {
			updateAttr("colorMode", "COLOR")
			def hubHue = (result.hue / 3.6).toInteger()
			updateAttr("hue", hubHue)
			updateAttr("saturation", result.saturation)
			updateAttr("color", "[hue: ${hubHue}, saturation: ${result.saturation}]")
			def colorName = convertHueToGenericColorName(hubHue)
			updateAttr("colorName", colorName)
			def rgb = hubitat.helper.ColorUtils.hsvToRGB([hubHue,
														  result.saturation,
														  result.brightness])
			updateAttr("RGB", rgb)
			updateAttr("colorTemperature", 0)
			logData << [colorMode: "COLOR", colorName: colorName, color: color, 
						RGB: RGB, colorTemperature: 0]
		} else {
			updateAttr("colorMode", "CT")
			updateAttr("colorTemperature", result.color_temp)
			def colorName = convertTemperatureToGenericColorName(result.color_temp.toInteger())
			updateAttr("hue", 0)
			updateAttr("saturation", 0)
			updateAttr("colorName", colorName)
			updateAttr("color", "[:]")
			updateAttr("RGB", "[]")
			logData << [colorMode: "CT", colorName: colorName, color: color, 
						RGB: RGB, colorTemperature: result.color_temp]
		}
	}
	logDebug(logData)
}

//	Library Inclusion
#include davegut.tpLinkCapSwitch
#include davegut.tpLinkCapSwitchLevel
#include davegut.tpLinkCapColorControl
#include davegut.tpLinkCommon
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.Logging
