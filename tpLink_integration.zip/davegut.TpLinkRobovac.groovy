/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

=================================================================================================*/
//	=====	NAMESPACE	in library davegut.Logging	============
//import org.json.JSONObject
//import groovy.json.JsonSlurper
//import groovy.json.JsonOutput
//import groovy.json.JsonBuilder

metadata {
	definition (name: "TpLink Robovac", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_robovac.groovy")
	{
		capability "Refresh"
		capability "Configuration"
		attribute "commsError", "string"
		capability "Battery"
		capability "Actuator"
		command "setCleanPrefs", [
			[name: "cleanPasses", type: "ENUM", description: "Number of Vacuum Passes",
			 constraints: [1, 2, 3]],
			[name: "vacSuction", type: "ENUM", description: "Vacuum Suction", 
			 constraints: ["quiet", "standard", "turbo", "max"]],
			[name: "waterLevel", type: "ENUM", description: "Vacuum Suction", 
			 constraints: ["none", "low", "moderate", "high"]]]
		attribute "cleanPasses", "number"
		attribute "vacuumSuction", "string"
		attribute "waterLevel", "string"
		command "cleanStart"
		command "cleanPause"
		command "cleanResume"
		command "dockVacuum"
		attribute "docking", "string"
		attribute "cleanOn", "string"
		attribute "vacuumStatus", "string"
		attribute "prompt", "string"
		attribute "promptCode", "promptCode"
		attribute "mopState", "string"
		attribute "waterLevel", "number"
	}
	preferences {
//		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
//			   options: ["always", "never", "night_mode"], defaultValue: "always")
		List pollOptions = ["5 sec", "10 sec", "30 sec", "5 min", "10 min", "15 min", "30 min"]
		input ("pollInterval", "enum", title: "Poll/Refresh Interval",
			   options: pollOptions, defaultValue: "30 min")
		input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
	}
}

def installed() {
	updateAttr("commsError", "false")
	state.errorCount = 0
	state.lastCmd = ""
	state.eventType = "digital"
	Map logData = [configure: configure(false)]
	return logData
}

def configure(checkApp = true) {
	Map logData = [method: "configure"]
	if (checkApp == true) {
		logData << [updateData: parent.tpLinkCheckForDevices(5)]
	}
	unschedule()
	logData << [handshake: deviceHandshake()]
	runEvery3Hours(deviceHandshake)
	logData << [handshakeInterval: "3 Hours"]
	logData << [pollInterval: setPollInterval()]
	logData << [logging: setLogsOff()]
	runIn(10, initSettings)
	logInfo(logData)
	return logData
}

def initSettings() {
	Map logData = [method: "initSettings"]
	List requests = []
	if (ledRule) { requests << [method: "get_led_info"] }
	requests << [method: "get_device_info"]
	asyncSend(createMultiCmd(requests), "initSettings", "parseUpdates")
	return logData
}

def updated() {
	Map logData = [method: updated]
	def commsErr = device.currentValue("commsError")
	logData << [commsError: commsErr]
	if (commsErr == "true") {
		logData << [configure: configure(true)]
	}
	updateAttr("commsError", "false")
	state.lastCmd = ""
	logData << [pollInterval: setPollInterval()]
	logData << [logging: setLogsOff()]
	pauseExecution(5000)
	logInfo(logData)
}

//	===== Cleaning Control =====
def cleanStart() {
	logDebug([method: "cleanStart"])
	def cmdBody = [method: "setSwitchClean", params: [clean_on: true, clean_mode: 0]]
	asyncSend(cmdBody,"cleanStart", "controlParse")
}

def cleanPause() {
	logDebug([method: "cleanPause"])
	def cmdBody = [method: "setRobotPause", params: [pause: true]]
	asyncSend(cmdBody,"cleanPause", "controlParse")
}

def cleanResume() {
	logDebug([method: "cleanResume"])
	def cmdBody = [method: "setRobotPause", params: [pause: false]]
	asyncSend(cmdBody,"dcleanResume", "controlParse")
}

def dockVacuum() {
	logDebug([method: "dockVacuum"])
	def cmdBody = [method: "setSwitchCharge", params: [switch_charge: true]]
	asyncSend(cmdBody,"dockVacuum", "controlParse")
}

def controlParse(resp, data=null) {
	Map logData = [method: "controlParse", control: data]
	try {
		def respData = parseData(resp)
		logData << [respData: respData]
		if(respData.cmdResp != "ERROR" && respData.cmdResp.error_code == 0) {
			runIn(8, getCleanData)
			logDebug(logData)
		} else {
			logData << [resp: resp.properties]
			logWarn(logData)
		}
	} catch (err) {
		logData << [errorData: err]
		logWarn(logData)
	}
}

def getCleanData() {
	logDebug([method: "getCleanData"])
	List requests = [
		[method: "getSwitchClean"],
		[method: "getVacStatus"],
		[method: "getMopState"],
		[method: "getSwitchCharge"]]
	asyncSend(createMultiCmd(requests),"getCleanData", "parseUpdates")
}

def parse_getVacStatus(vacData) {
	Map logData = [method: "parse_getVacStatus"]
	String vacuumStatus
	switch (vacData.status) {
		case 0: vacuumStatus = "OffDock/notCleaning"; break
		case 1: vacuumStatus = "cleaning"; break
		case 2: vacuumStatus = "2"; break
		case 3: vacuumStatus = "3"; break
		case 4: vacuumStatus = "docking"; break
		case 5: vacuumStatus = "docked/charging"; break
		case 6: vacuumStatus = "docked/charged"; break
		case 7: vacuumStatus = "paused"; break
		default: vacuumStatus = "${vacData.status}"
	}
	updateAttr("vacuumStatus", vacuumStatus)
	updateAttr("prompt", vacData.prompt)
	updateAttr("promptCode", vacData.promptCode_id)
	logData << [vacuumStatus: vacuumStatus, cleanOn: cleanOn, docking: docking,
			   mopState: mopState]
	if (vacData.status != 6 && vacData.status != 5) {
		runIn(60, getCleanData)
	}
	logDebug(logData)
}

//	==== Clean Preferences ====
def setCleanPrefs(passes, suction, water) {
	def logData = [method: "setCleanPrefs", passes: passes, suction: suction, waterLevel: water]
	Integer sucNo
	switch(suction) {
		case "standard": sucNo = 2; break
		case "turbo": sucNo = 3; break
		case "max": sucNo = 4; break
		default: sucNo = 1
	}
	Integer watLev
	switch(water) {
		case "low": watLev = 2; break
		case "moderate": watLev = 3; break
		case "high": watLev = 4; break
		default: watLev = 1
	}
	List requests = [
		[method:"setCleanNumber", params:[suction_level: sucNo, 
										  clean_number: passes.toInteger(), 
										  cistern: watLev]],
		[method: "getCleanNumber"]]
	asyncSend(createMultiCmd(requests), "setCleanPrefs", "parseUpdates")
	logDebug(logData)
}

def parse_getCleanNumber(result) {
	logDebug([method: "parse_getCleanNumber", result: result])
	updateAttr("cleanPasses", result.clean_number)
	String vacuumSuction
	switch(result.suction) {
		case 2: vacuumSuction = "standard"; break
		case 3: vacuumSuction = "turbo"; break
		case 4: vacuumSuction = "max"; break
		default: vacuumSuction = "quiet"
	}
	updateAttr("vacuumSuction", vacuumSuction)
	String waterLevel
	switch(result.cistern) {
		case 2: waterLevel = "low"; break
		case 3: waterLevel = "moderate"; break
		case 4: waterLevel = "high"; break
		default: waterLevel = "none"
	}
	updateAttr("waterLevel", waterLevel)
}

//	===== Refresh =====
def refresh() {
	getCleanData()
	List requests = [
		[method: "getBatteryInfo"],
		[method: "getCleanNumber"]	]
	asyncSend(createMultiCmd(requests), "refresh", "parseUpdates")
}

//	===== Login =====
def deviceHandshake() { 
	Map reqData = [:]
	Map cmdBody = [method: "login",
				   params: [hashed: true, 
							password: parent.encPasswordVac,
							username: parent.userName]]
	Map reqParams = [uri: getDataValue("baseUrl"),
					 ignoreSSLIssues: true,
					 body: cmdBody,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10]
	asyncPost(reqParams, "parseVacAesLogin", reqData)
}

def parseVacAesLogin(resp, data) {
	Map logData = [method: "parseVacAesLogin", oldToken: token]
	if (resp.status == 200 && resp.json != null) {
		logData << [status: "OK"]
		def newToken = resp.json.result.token
		device.updateSetting("token", [type: "string", value: newToken])
		logData << [token: newToken]
		state.errorCount = 0
		if (device && device.currentValue("commsError") == "true") {
			logData << [setCommsError: setCommsError(false)]
		}
		logDebug(logData)
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

//	===== Communications =====
def getVacAesParams(cmdBody) {
	Map reqParams = [uri: "${getDataValue("baseUrl")}/?token=${token}",
					 body: cmdBody,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 ignoreSSLIssues: true,
					 timeout: 10]
	return reqParams	
}

def parseVacAesData(resp) {
	Map parseData = [parseMethod: "parseVacAesData"]
	try {
		parseData << [status: "OK", cmdResp: resp.json]
		state.errorCount = 0
		if (device.currentValue("commsError") == "true") {
			parseData << [setCommsError: setCommsError(false)]
		}
		logDebug(parseData)
	} catch (err) {
		parseData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		logWarn(parseData)
		handleCommsError()
	}
	return parseData	
}

//	===== Capability Configuration =====
def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def setPollInterval(pInterval = pollInterval) {
	if (pInterval.contains("sec")) {
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", "refresh")
		logWarn("setPollInterval: Polling intervals of less than one minute " +
				"can take high resources and may impact hub performance.")
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", "refresh")
	}
	return pInterval
}

//	===== Preferences Methods =====
def parseUpdates(resp, data= null) {
	Map logData = [method: "parseUpdates"]
	def respData = parseData(resp).cmdResp
	if (respData.error_code == 0) {
		respData.result.responses.each {
			if (it != null && it.error_code == 0) {
				switchParse(it)
			} else {
				logData << ["${it.method}": [status: "cmdFailed", data: it]]
				logWarn(logData)				
			}
		}
	} else {
		logData << [status: "invalidRequest", resp: resp.properties, respData: respData]
		logWarn(logData)				
	}
}
	
def switchParse(devResp) {
	Map logData = [method: switchParse]
	def doLog = true
	def prefs = getDataValue("prefs")
	switch(devResp.method) {
		case "get_device_info":
			logData << [deviceMethod: devResp.method]
			parse_get_device_info(devResp.result, "switchParse")
			break
		case "get_led_info":
			logData << [deviceMethod: devResp.method]
			if (ledRule != devResp.result.led_rule) {
				Map requests = [
					method: "set_led_info",
					params: [
						led_rule: ledRule,
						//	Uses mode data from device.  This driver does not update these.
						night_mode: [
							night_mode_type: devResp.result.night_mode.night_mode_type,
							sunrise_offset: devResp.result.night_mode.sunrise_offset, 
							sunset_offset:devResp.result.night_mode.sunset_offset,
							start_time: devResp.result.night_mode.start_time,
							end_time: devResp.result.night_mode.end_time
						]]]
				asyncSend(requests, "delayedUpdates", "parseUpdates")
				device.updateSetting("ledRule", [type:"enum", value: ledRule])
				logData << [status: "updatingLedRule"]
			}
			logData << [ledRule: ledRule]
			break
		case "get_battery_info":
			updateAttr("battery", devResp.result.battery_percentage)
			break
		case "getCleanNumber":
			parse_getCleanNumber(devResp.result)
			break
		case "getSwitchClean":
			updateAttr("cleanOn", devResp.clean_on)
			break
		case "getMopState":
			updateAttr("mopState", devResp.mop_state)
			break
		case "getSwitchCharge":
			updateAttr("docking", devResp.switch_charge)
			break
		case "getVacStatus":
			parse_getVacStatus(devResp.result)
			break
		case "set_led_info":
		case "set_device_info":
		case "set_auto_off_config":
		case "set_on_off_gradually_info":
			doLog = false
			break
		default:
			logData << [status: "unhandled", devResp: devResp]
	}
	if (doLog) { logDebug(logData) }
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

#include davegut.tpLinkComms
#include davegut.Logging
