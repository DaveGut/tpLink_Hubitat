library (
	name: "tpLinkComms",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Communication methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

//	===== Async Commsunications Methods =====
def asyncSend(cmdBody, reqData, action) {
	Map cmdData = [cmdBody: cmdBody, reqData: reqData, action: action]
	state.lastCmd = cmdData
	def protocol = getDataValue("protocol")
	Map reqParams = [:]
	if (protocol == "KLAP") {
		reqParams = getKlapParams(cmdBody)
	} else if (protocol == "AES") {
		reqParams = getAesParams(cmdBody)
	} else if (protocol == "vacAes") {
		reqParams = getVacAesParams(cmdBody)
	}
	asyncPost(reqParams, action, reqData)
}

def asyncPost(reqParams, parseMethod, reqData=null) {
	Map logData = [method: "asyncPost", parseMethod: parseMethod, data:reqData]
	try {
		asynchttpPost(parseMethod, reqParams, [data: reqData])
		logData << [status: "OK"]
	} catch (err) {
		logData << [status: "FAILED", reqParams: reqParams, error: err]
		runIn(1, handleCommsError)
	}
	logDebug(logData)
}

def parseData(resp, protocol = getDataValue("protocol")) {
	Map logData = [method: "parseData"]
	if (resp.status == 200) {
		if (protocol == "KLAP") {
			logData << parseKlapData(resp)
		} else if (protocol == "AES") {
			logData << parseAesData(resp)
		} else if (protocol == "vacAes") {
			logData << parseVacAesData(resp)
		}
	} else {
		logData << [status: "httpFailure"]
		runIn(1, handleCommsError)
	}
	return logData
}

//	===== Communications Error Handling =====
def handleCommsError() {
	Map logData = [method: "handleCommsError"]
	if (state.lastCmd != "") {
		def count = state.errorCount + 1
		logData << [count: count, lastCmd: state.lastCmd]
		switch (count) {
			case 1:
				logData << [action: "resendCommand"]
				runIn(2, delayedPassThrough)
				break
			case 2:
				logData << [attemptHandshake: deviceHandshake(),
						    action: "resendCommand"]
				runIn(2, delayedPassThrough)
				break
			case 3:
				logData << [configure: configure(true),
						    action: "resendCommand"]
				runIn(2, delayedPassThrough)
			default:
				if (device.currentValue("commsError") == "false") {
					logData << [setCommsError: setCommsError(true)]
				}
				logData << [retries: "disabled"]
				break
		}
		state.errorCount = count
	} else {
		logData << [status: "noCommandToRetry"]
	}
	logInfo(logData)
}

def delayedPassThrough() {
	def cmdData = new JSONObject(state.lastCmd)
	def cmdBody = parseJson(cmdData.cmdBody.toString())
	asyncSend(cmdBody, cmdData.reqData, cmdData.action)
}

def setCommsError(status) {
	if (device.currentValue("commsError") == "true" && status == false) {
		updateAttr("commsError", "false")
		setPollInterval()
		unschedule(errorDeviceHandshake)
		return "false"
	} else if (device.currentValue("commsError") == "false" && status == true) {
		updateAttr("commsError", "true")
		setPollInterval("30 min")
		runEvery5Minutes(errorDeviceHandshake)
		return "true"
	}
}

def errorDeviceHandshake() { 
	logInfo([method: "errorDeviceHandshake"])
	deviceHandshake()
}
