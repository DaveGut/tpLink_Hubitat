/*	Multi-TP-Link Product Integration Application
	Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Link to Documentation =====
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/Documentation.pdf

The code below is adaptable between four cases to allow the developer a single environment
supporting the range of TP-LINK Kasa and Tapo devices.  This is necessitated by the
manufacturer's transition of their KASA devices from their IOT API to the API used for
their TAPO Product line (herein called TP-LINK API for clarity).

Four Options for NAME in Definition:
a.	Kasa Integration: Integrates Legacy (IOT API) Kasa plugs and switches and bulbs
b.	KasaSmart Integration.  Integrates Legacy devices AND TP-LINK API plugs,
	switches, and hub.  The hub has a child Tnermostat Radiator Valve (TRV) child.
	Future-proofed to include Bulbs if they later are Remodeled from Tapo.
c.	Tapo Integration.  Integrates all TAPO labeled plugs, switches, bulbs, and hubs
	(including hub child devices).  For backward compatibility with the Community
	integration, adds support for current KASA TP-LInk API devices.
d.	TpLink Integration.  All of the above except the Tapo robovac (this will be available
	as a community DRIVER (No app required).

The integration does not currently support Cameras, Doorbells, wifi Thermostat, nor
the RoboVac.  I anticipate some level of support for the Thermostat when it finally is
released by TP-Link.

Identification of the current KASA TP-LINK API devices (from the Android APK File).
This field will grow as Kasa manuactures new device versions (it appears they are
just updating the hardware packaging and firmware name for TAPO devices to Kasa).
1.	SMART_TAPO_REMODEL_KASA_HUB_KH100 (works with Kasa TRV)
2.	SMART_TAPO_REMODEL_KASA_PLUG_EP25
3.	SMART_TAPO_REMODEL_KASA_PLUG_KP125M (Matter)
4.	SMART_TAPO_REMODEL_KASA_POWER_STRIP_EP40M
5.	SMART_TAPO_REMODEL_KASA_SWITCH_HS200
6.	SMART_TAPO_REMODEL_KASA_SWITCH_HS220 (Dimmer)
7.	SMART_TAPO_REMODEL_KASA_SWITCH_KS205 (Matter)
8.	SMART_TAPO_REMODEL_KASA_SWITCH_KS225 (Dimmer, Matter)
9.	SMART_TAPO_REMODEL_KASA_SWITCH_KS240 (Dual Fan Control/Dimmer)

Application Changes.  Essentially a new app with most code coming from the EXISITING
built-in App as well as the Community Tapo integration.  Uses Libraries to break out
common methods from methods specific to the IOT and TP-LINK APIs.  Major changes:
a.	Common data in the atomicState.devices for all devices.
b.	Updated device polling from the drivers (part of error handling) with separate polling
	for each API.
c.	Reorganized Start Page to accommodate accommodate this drivers multi-integration.
	(This is readily modified if the TpLink version is settled on for all devices.)
d.	Two if conditions uses sparingly: if !"Kasa Integration" and if !"Tapo Integration".
e.	product lookup method to select products (type) for each app NAME.

Kasa (Legacy) drivers:  Minor change to error handling to work properly (was broken in
						determining new IP address). "Configure" improvements (will checl
						app to update IP addresses on LAN devices).
New TP-LINK drivers:	Based on community integration.  Added Fan Control.
========================================*/
//#include davegut.appKasaIOT				//	name = Kasa, KasaSmart, TpLink Integration
#include davegut.appTpLinkSmart			//	name = Tapo, Kasa Smart, TpLink Integration
#include davegut.tpLinkComms			//	name = Tapo, Kasa Smart, TpLink Integration
#include davegut.tpLinkCrypto			//	name = Tapo, Kasa Smart, TpLink Integration
#include davegut.Logging

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import org.json.JSONObject	//	Check all imports after testing is complete.

definition(
//	name: "Kasa Integration",
//	name: "KasaSmart Integration",
	name: "Tapo Integration",
//	name: "TpLink Integration",
	namespace: nameSpace(),
	author: "Dave Gutheinz",
	description: "Application to install TP-Link bulbs, plugs, and switches.",
	category: "Convenience",
	iconUrl: "",
	iconX2Url: "",
	installOnOpen: true,
	singleInstance: true,
	documentationLink: "https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/README.md",
	importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/KasaDevices/Application/KasaIntegrationApp.groovy"
)

preferences {
	page(name: "startPage")
	page(name: "enterCredentialsPage")
	page(name: "processCredentials")
	page(name: "addDevicesPage")
	page(name: "removeDevicesPage")
}

def installed() {
	app?.updateSetting("logEnable", false)
	app?.updateSetting("infoLog", true)
	def hub = location.hubs[0]
	def hubIpArray = hub.localIP.split('\\.')
	def segments = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
	app?.updateSetting("lanSegment", [type:"string", value: segments])
	app?.updateSetting("ports", [type:"string", value: "9999"])
	app?.updateSetting("hostLimits", [type:"string", value: "2, 254"])
	if (app.getLabel() != "Tapo Integration") {
		app?.updateSetting("kasaToken", "INVALID")
		app?.updateSetting("useKasaCloud", false)
	}
	if (app.getLabel() != "Kasa Integration") {
		app?.updateSetting("encPassword", "INVALID")
		app?.updateSetting("encUsername", "INVALID")
		app?.updateSetting("localHash", "INVALID")
	}
	logInfo([method: "installed", status: "Initialized settings"])
}

def updated() {
	app?.removeSetting("selectedAddDevices")
	app?.removeSetting("selectedRemoveDevices")
	app?.updateSetting("logEnable", false)
	app?.updateSetting("appSetup", false)
	app?.updateSetting("startApp", true)
	app?.updateSetting("scheduled", false)
	state.needCreds = false
	scheduleItems()
	logInfo([method: "updated", status: "setting updated for new session"])
}

def scheduleItems() {
	Map logData = [method: "scheduleItems"]
	unschedule()
	if (useKasaCloud) {
		schedule("0 30 2 ? * MON,WED,SAT", getKasaToken)
		logData << [kasaCloudLogin: "scheduled MON, WED, SAT"]
	}
	app?.updateSetting("scheduled", false)
	logData << setLogsOff()
	//	Clean databases
	logData << [databases: "trimmed"]
	def devicesData = atomicState.devices
	Map childDevices = [:]
	devicesData.each { device ->
		if (getChildDevice(device.key)) { childDevices << device }
	}
	atomicState.devices = childDevices
	atomicState.iotDevices = [:]
	atomicState.tpLinkDevices = [:]
	logInfo(logData)
}

def uninstalled() {
    getAllChildDevices().each { 
        deleteChildDevice(it.deviceNetworkId)
    }
	logInfo([method: "uninstalled", status: "Devices and App uninstalled"])
}

def initInstance() {
	if (!scheduled) {
		unschedule()
		runIn(1800, scheduleItems)
		app?.updateSetting("scheduled", true)
	}
	if (appVer != version()) {
		if (!atomicState.devices) { atomicState.devices = [:] }
		if (!atomicState.tpLinkDevices) { atomicState.tpLinkDevices = [:] }
		if (!atomicState.iotDevices) { atomicState.iotDevices = [:] }
		if (!state.needCreds) { state.needCreds = false }
		if (app.getLabel() != "Tapo Integration") {	state.kasaChecked = false }
		if (app.getLabel() != "Kasa Integration") { state.tpLinkChecked = false }
		if (app.getLabel() != "Tapo Integration" && !useKasaCloud) {
			def kasaTokenUpd = "INVALID"
			def useCloud = false
			if (kasaToken && kasaToken != "INVALID") {
				useCloud = true
				kasTokenUpd = kasaToken
			}
			app?.updateSetting("useKasaCloud", useCloud)
			app?.updateSetting("kasaToken", kasaTokenUpd)
		}
		setSegments()
		logInfo([method: "initInstance", status: "App data updated for appVer ${version()}"])
	}
	if (appSetup) {
		setSegments()
		logInfo([method: "initInstance", status: "Updated App Setup Data"])
	}
	return
}

def setSegments() {
	try {
		state.segArray = lanSegment.split('\\,')
		state.portArray = ports.split('\\,')
		def rangeArray = hostLimits.split('\\,')
		def array0 = rangeArray[0].toInteger()
		def array1 = array0 + 2
		if (rangeArray.size() > 1) {
			array1 = rangeArray[1].toInteger()
		}
	state.hostArray = [array0, array1]
	} catch (e) {
		logWarn("startPage: Invalid entry for Lan Segements, Host Array Range, or Ports. Resetting to default!")
		def hub = location.hubs[0]
		def hubIpArray = hub.localIP.split('\\.')
		def segments = [hubIpArray[0],hubIpArray[1],hubIpArray[2]].join(".")
		app?.updateSetting("lanSegment", [type:"string", value: segments])
		app?.updateSetting("ports", [type:"string", value: "9999"])
		app?.updateSetting("hostLimits", [type:"string", value: "1, 254"])
	}
}

def startPage() {
	logInfo([method: "startPage", status: "Starting ${app.getLabel()} Setup"])
	def action = initInstance()
	if (selectedRemoveDevices) { removeDevices() } 
	else if (selectedAddDevices) { addDevices() }
	return dynamicPage(name:"startPage",
					   title:"<b>${app.getLabel()}</b>",
					   uninstall: true,
					   install: true) {
		section() {
			Map lanParams = [LanSegments: state.segArray, Ports: state.portArray, hostRange: 
						   state.hostArray]
			String params = "<b>Application Setup Parameters</b>"
			if (app.getLabel() != "Tapo Integration") {
				params += "\n\t<b>useKasaCloud</b>: ${useKasaCloud}"
				params += ", <b>kasaToken</b>: ${kasaToken}"
			}
			params += "\n\t<b>lanDiscoveryParams</b>: ${lanParams}"
			paragraph params
			input "appSetup", "bool", title: "<b>Modify Application Setup</b> (useCloud, LanDiscParams)",
				submitOnChange: true, defaultValue: false
			if (appSetup) {
				if (app.getLabel() != "Tapo Integration") {
					input "useKasaCloud", "bool", title: "<b>Use the Kasa Cloud</b>",
						description:  "Use the Kasa Cloud to control legacy devices.  Usually used only with discovery issues",
						submitOnChange: true
				}
				if (!useKasaCloud) { app?.updateSetting("kasaToken", "INVALID") }
				input "lanSegment", "string",
					title: "<b>Lan Segments</b> (ex: 192.168.50, 192,168.01)", submitOnChange: true
				input "hostLimits", "string",
					title: "<b>Host Address Range</b> (ex: 5, 100)", submitOnChange: true
				input "ports", "string",
					title: "<b>Ports for Port Forwarding</b> (ex: 9999, 8000)", submitOnChange: true
			}
			def credDesc = "Credentials: userName: ${userName}, password set/redacted"
			if (useKasaCloud) { credDesc += ", CloudToken: ${kasaToken}" }
			def addDesc = "Install ALL Bulbs and Switches"
			if (!userName || !userPassword) {
				credDesc = "<b>Credentials not set.  Enter credentials to proceed.</b>"
				addDesc = "Install only legacy Kasa Bulbs and Switches"
				if (app.getLabel() != "Kasa Integration") { state.needCreds = true }
			} else {
				if (app.getLabel() != "Kasa Integration") { state.needCreds = false }
			}
			if (kasaToken == "INVALID" && useKasaCloud) {
				credDesc += "\n<b>Token requires update for kasaCloud control of devices."
				credDesc += " Two Factor identification MUST be disabled in Kasa App</b>."
			}
			if ((useKasaCloud && app.getLabel() == "Kasa Integration") ||
				app.getLabel() != "Kasa Integration") {
				href "enterCredentialsPage",
					title: "<b>Enter/Update Username and Password</b>",
					description: credDesc
			}
			if (!state.needCreds) {
				href "addDevicesPage",
					title: "<b>Scan for devices and add</b>",
					description: addDesc
			} else {
				paragraph "<b>Credentials are required to scan for to find devices</b>"
			}
			href "removeDevicesPage",
				title: "<b>Remove Devices</b>",
				description: "Select to remove selected Device from Hubitat."
			input "logEnable", "bool",
				   title: "<b>Debug logging</b>",
				   submitOnChange: true
		}
	}
}

def enterCredentialsPage() {
	Map credData = [:]
	return dynamicPage (name: "enterCredentialsPage", 
    					title: "Enter  Credentials",
						nextPage: startPage,
                        install: false) {
		section() {
			input "showPassword", "bool",
				title: "<b>Show Password</b>",
				submitOnChange: true,
				defaultValue: false
			paragraph "<b>Password and Username are both case sensitive.</b>"
			def pwdType = "password"
			if (showPassword) { pwdType = "string" }
			input ("userName", "email",
            		title: "Email Address", 
                    required: false,
                    submitOnChange: false)
			input ("userPassword", pwdType,
            		title: "Account Password",
                    required: false,
                    submitOnChange: false)
			paragraph "<b>You must select Update Credentials before exiting this page.</b>"
			input "updateCredentials", "bool",
				title: "<b>Update Credentials</b>",
				submitOnChange: true,
				defaultValue: false
			if (updateCredentials && userName && userPassword && 
				userName != null && userPassword != null) {
				credData << processCredentials()
			}
			paragraph "Current derived credData: ${credData}"
		}
	}
}

private processCredentials() {
	Map logData = [method: "processCredentials", userName: userName, userPassword: userPassword]
	Map credData = [:]
	if (app.getLabel() != "Kasa Integration") {
		credData << createTpLinkCreds()
	}
	if (useKasaCloud) {
		credData << getKasaToken()
	}
	logData << credData
	logInfo(logData)
	app?.updateSetting("updateCredentials", false)
	return credData
}

//	===== Add selected newdevices =====
def addDevicesPage() {
	logDebug("addDevicesPage")
	app?.removeSetting("selectedAddDevices")
	def action = findDevices(8)
	action = updateLegacyDevices()
	def addDevicesData = atomicState.devices
	def uninstalledDevices = [:]
	addDevicesData.each {
		def isChild = getChildDevice(it.key)
		if (!isChild) {
			if (it.value.prefs.toString().contains("matter")) {
				uninstalledDevices["${it.key}"] = "${it.value.alias}, ${it.value.type}, (matterDevice)"
			} else {
				uninstalledDevices["${it.key}"] = "${it.value.alias}, ${it.value.type}"
			}
		}
	}
	uninstalledDevices.sort()
	
	def deviceList = []
	if (addDevicesData == null) {
		deviceList << "<b>No Devices in addDevicesData.</b>]"
	} else {
		addDevicesData.each{
			def dni = it.key
			def result = ["Failed", "n/a"]
			def installed = "No"
			def isChild = getChildDevice(it.key)
			if (isChild) {
				installed = "Yes"
			}
			if (it.value.ip) {
				deviceList << "<b>${it.value.alias}</b>: ${it.value.ip}:${it.value.port}, ${installed}"
			} else if (it.value.baseUrl) {
				deviceList << "<b>${it.value.alias}</b>: ${it.value.baseUrl}, ${installed}"
			}
		}
	}
	deviceList.sort()
	def theList = ""
	deviceList.each {
		theList += "${it}\n"
	}

	return dynamicPage(name:"addDevicesPage",
					   title: "Add Devices to Hubitat",
					   nextPage: startPage,
					   install: false) {
	 	section() {
			input ("selectedAddDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "Devices to add (${uninstalledDevices.size() ?: 0} available).\n\t" +
				   "Total Devices: ${addDevicesData.size()}",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: uninstalledDevices)
			paragraph "<b>Found Devices: (Alias: Ip:Port, Installed?)</b>\r<p style='font-size:14px'>${theList}</p>"
			href "addDevicesPage",
				title: "<b>Rescan for Additional Devices</b>",
				description: "<b>Perform scan again to try to capture missing devices.</b>"
		}
	}
}

def findDevices(timeout) {
	def allDevices = atomicState.devices
	Map logData = [method: "findDevices", intType: app.getLabel()]
	if (app.getLabel() != "Tapo Integration") {
		logInfo("findDevices: Finding KASA LAN Devices")
		logData << [findIOTDevices: findIOTDevices("getIOTLanData", timeout)]
		if (useKasaCloud) {
			logInfo("findDevices: Found ${atomicState.iotDevices.size()} KASA Devices")
			logData << [findCloudIOTDevices: findCloudIOTDevices()]
		}
	}
	if (app.getLabel() != "Kasa Integration") {
		logInfo("findDevices: Finding TP-Link LAN Devices")
		logData << [findTpLinkDevices: findTpLinkDevices("getTpLinkLanData", timeout)]
	}
	allDevices = allDevices + atomicState.iotDevices + atomicState.tpLinkDevices
	atomicState.devices = allDevices
	logInfo(logData)
	return
}

def supportedProducts() {
	List supported = []
	if (app.getLabel() == "Kasa Integration") {
		supported = ["IOT.SMARTBULB", "IOT.SMARTPLUGSWITCH"]
	} else if (app.getLabel() == "KasaSmart Integration") {
		supported = ["IOT.SMARTBULB", "IOT.SMARTPLUGSWITCH", "SMART.KASAPLUG",
					 "SMART.KASASWITCH", "SMART.KASAHUB"]
	} else if (app.getLabel() == "Tapo Integration") {
		supported = ["SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH",
					 "SMART.KASAHUB", "SMART.TAPOHUB", "SMART.KASAPLUG",
					 "SMART.KASASWITCH", "SMART.TAPOROBOVAC"]
	} else if (app.getLabel() == "TpLink Integration") {
		supported = ["IOT.SMARTBULB", "IOT.SMARTPLUGSWITCH", "SMART.KASAPLUG", "SMART.KASASWITCH",
					"SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH", 
					"SMART.KASAHUB", "SMART.TAPOHUB", "SMART.TAPOROBOVAC"]
	}
	return supported
}

def updateLegacyDevices() {
	Map logData = [method: "updateLegacyDevices", appVer: appVer, 
				   version: version()]
	if (appVer != version()) {
		List children = getChildDevices()
		logData << [children: children]
		children.each { child ->
//			child.updateDeviceData()
			child.configure(false)
		}
		app?.updateSetting("appVer", [type:"string", value: version()])
		logData << [appVer: version()]
	}
	logInfo(logData)
	return
}

//	===== Add Devices =====
def addDevices() {
	Map logData = [method: "addDevices", selectedDevices: selectedDevices]
	def hub = location.hubs[0]
	def devicesData = atomicState.devices
	selectedAddDevices.each { dni ->
		def isChild = getChildDevice(dni)
		if (!isChild) {
			def device = devicesData.find { it.key == dni }
			addDevice(device, dni)
		}
		pauseExecution(3000)
	}
	logInfo(logData)
	app?.removeSetting("selectedAddDevices")
}

def addDevice(device, dni) {
	Map logData = [method: "addDevice", dni: dni]
	try {
		Map deviceData = [protocol: device.value.protocol]
		if (device.value.protocol == "IOT") {
			//	FUTURE: Add tpLinkType and type to deviceData
			deviceData << [deviceIP: device.value.ip,
						   deviceId: device.value.deviceId,
						   devicePort:  device.value.port,
						   feature: feature]
		} else {
			deviceData << [baseUrl: device.value.baseUrl,
						   tpLinkType: device.value.deviceType,
						   type: device.value.type]
		}

		if (device.value.plugNo != null) {
			//	Add to devices on update.
			deviceData << [plugNo: device.value.plugNo,
						   plugId: device.value.plugId]
			}
		if (device.value.ctLow != null) {
			deviceData << [ctLow: device.value.ctLow,
						   ctHigh: device.value.ctHigh]
		}
		try {
			addChildDevice(
				nameSpace(),
				"TpLink ${device.value.type}",
				dni,
				[
					"label": device.value.alias,
					"name" : device.value.model,
					"data" : deviceData
				]
			)
			logData << [status: "added"]
			logInfo(logData)
		} catch (err) {
			logData << [status: "failedToAdd", driver: device.value.type, errorMsg: error]
			logWarn(logData)
		}
	} catch (error) {
		logData << [status: "failedToAdd", device: device, errorMsg: error]
		logWarn(logData)
	}
	return
}

//	===== Remove Devices =====
def removeDevicesPage() {
	Map logData = [method: "removeDevicesPage"]
	Map installedDevices = [:]
	getChildDevices().each {
		installedDevices << ["${it.device.deviceNetworkId}": it.device.label]
	}
	logData << [installedDevices: installedDevices]
	logData << [childDevices: installedDevices]
	logInfo(logData)
	return dynamicPage(name:"removedDevicesPage",
					   title:"<b>Remove Devices from Hubitat</b>",
					   nextPage: startPage,
					   install: false) {
		section() {
			input ("selectedRemoveDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "Devices to remove (${installedDevices.size() ?: 0} available)",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: installedDevices)
		}
	}
}
def removeDevices() {
	Map logData = [method: "removeDevices", selectedRemoveDevices: selectedRemoveDevices]
	def devicesData = atomicState.devices
	selectedRemoveDevices.each { dni ->
		def device = devicesData.find { it.key == dni }
		def isChild = getChildDevice(dni)
		if (isChild) {
			try {
				deleteChildDevice(dni)
				logData << ["${dni}": [status: "ok", alias: device.value.alias]]
			} catch (error) {
				logData << ["${dni}": [status: "FAILED", alias: device.value.alias, error: error]]
				logWarn(logData)
			}
		}
	}
	app?.removeSetting("selectedRemoveDevices")
	logInfo(logData)
}

def appCheckDevices() {
	Map logData = [method: "appCheckDevices"]
	if (app.getLabel() != "Tapo Integration") {
		if (state.kasaChecked == false) {
			logData << [kasaCheck: findIOTDevices("getIOTLanData", 5)]
			state.kasaChecked = true
			runIn(570, resetKasaChecked)
			logData << [kasaCheck: "Running"]
		} else {
			logData << [kasaCheck: "notRun. Ran within last 10 minutes"]
		}
	}
	if (app.getLabel() != "Kasa Integration") {
		if (state.tpLinkChecked == false) {
			logData << [tpLinkCheck: findTpLinkDevices("parseTpLinkCheck", 5)]
			state.tpLinkChecked = true
			runIn(570, resetTpLinkChecked)
			logData << [tpLinkCheck: "Running"]
		} else {
			logData << [kasaCheck: "notRun. Ran within last 10 minutes"]
		}
	}
	logInfo(logData)
}

//	===== Common UDP Communications =====
private sendLanCmd(ip, port, cmdData, action, commsTo = 5, ignore = false) {
	def myHubAction = new hubitat.device.HubAction(
		cmdData,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "${ip}:${port}",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 ignoreResponse: ignore,
		 parseWarning: true,
		 timeout: commsTo,
		 callback: action])
	try {
		sendHubCommand(myHubAction)
	} catch (error) {
		logWarn("sendLanCmd: command to ${ip}:${port} failed. Error = ${error}")
	}
	return
}
