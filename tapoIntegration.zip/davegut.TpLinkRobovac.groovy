/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Robovac", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_robovac.groovy")
	{
		capability "Battery"
		capability "Actuator"
		command "setCleanPrefs", [
			[name: "cleanPasses", type: "ENUM", description: "Number of Vacuum Passes",
			 constraints: [1, 2, 3]],
			[name: "waterLevel", type: "ENUM", description: "Vacuum Suction", 
			 constraints: ["none", "low", "moderate", "high"]]]

		attribute "cleanPasses", "number"
		attribute "waterLevel", "string"
		command "cleanStart"
		command "cleanPause"
		command "cleanResume"
		command "dockVacuum"
		command "cleanRooms", [[type: "String", description: "example: 1, 2, 5, see state.mapInfo.  "]]
		attribute "cleaningList", "String"
		attribute "docking", "string"
		attribute "vacuumStatus", "string"
		attribute "prompt", "string"
		attribute "promptCode", "promptCode"
		attribute "mopState", "string"
		attribute "waterLevel", "number"
	}
	preferences {
		commonPreferences()
		input ("updateMaps", "bool", title: "Update Vacuum Maps", defaultValue: true)
		input ("activeMap", "String", title: "Active Map for cleaning")
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	state.eventType = "digital"
	logInfo(logData)
	runIn(10, updated)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logData << [updateMaps: getMapInfo()]
	logInfo(logData)
}
def getMapInfo() {
	Map logData = [getMapInfo: updateMaps]
	if (updateMaps == true) {
		List requests = [[method: "getMapInfo"]]
		sendDevCmd(requests, "getMapInfo", "parseUpdates")
	}
	return logData
}
def parse_getMapInfo(result, data) {
	state.mapInfo = [:]
	state.remove("mapData")
	List mapList = result.map_list
	mapList.each { 
		List requests = [[method: "getMapData", params: ["map_id": it.map_id]]]
		sendDevCmd(requests, it.map_id, "parseUpdates")
		pauseExecution(3000)
	}
	device.updateSetting("updateMaps",[type:"bool", value: true])
}
def parse_getMapData(result, data) {
	String mapId = result.map_id
	Map areaData = [:]
	result.area_list.each {
		if (it.type == "room") {
			byte[] plainBytes = it.name.decodeBase64()
			String mapName = new String(plainBytes)
			areaData << ["${it.id}": mapName]
		}
	}
	Map thisMap = ["${mapId}": areaData]
	state.mapInfo << thisMap
	logDebug([method: "parse_getMapData", thisMap: thisMap])
}

//	===== Cleaning Control =====
def cleanStart() {
	logDebug([method: "cleanStart"])
	def cmdBody = [method: "setSwitchClean", params: [clean_on: true, clean_mode: 0]]
	asyncSend(cmdBody,"cleanStart", "controlParse")
}

def cleanRooms(roomNos) {
	List rooms = roomNos.split(",").collect {it.trim() as Integer }
	Integer mapId = state.mapInfo.find { entry -> true }.key.toInteger()
	if (activeMap != null) { mapId = activeMap.toInteger() }
	List requests = [
		[method: "setSwitchClean", params: [
			room_list: rooms, clean_on: true, clean_order: true,
			clean_mode: 3, map_id: mapId]]]
	sendDevCmd(requests, "cleanRooms(${rooms}", "controlParse")
}

def cleanPause() {
	logDebug([method: "cleanPause"])
	def cmdBody = [method: "setRobotPause", params: [pause: true]]
	asyncSend(cmdBody,"cleanPause", "controlParse")
}

def cleanResume() {
	logDebug([method: "cleanResume"])
	def cmdBody = [method: "setRobotPause", params: [pause: false]]
	asyncSend(cmdBody,"cleanResume", "controlParse")
}

def dockVacuum() {
	logDebug([method: "dockVacuum"])
	def cmdBody = [method: "setSwitchCharge", params: [switch_charge: true]]
	asyncSend(cmdBody,"dockVacuum", "controlParse")
}

def controlParse(resp, data=null) {
	Map logData = [method: "controlParse", sourceMethod: data]
	try {
		def respData = parseData(resp, data)
		logData << [respData: respData]
		if(respData.status == 200) {
			runIn(8, getCleanData)
			logDebug(logData)
		} else {
			logData << [resp: resp.properties]
			logWarn(logData)
		}
	} catch (err) {
		logData << [errorData: err]
		logWarn(logData)
	}
}

def getCleanData() {
	logDebug([method: "getCleanData"])
	List requests = [
		[method: "getSwitchClean"],
		[method: "getVacStatus"],
		[method: "getMopState"],
		[method: "getSwitchCharge"]]
	sendDevCmd(requests,"getCleanData", "parseUpdates")
}

def parse_getVacStatus(vacData, data) {
	Map logData = [method: "parse_getVacStatus", sourceMethod: data]
	String vacuumStatus
	switch (vacData.status) {
		case 0: vacuumStatus = "OffDock/notCleaning"; break
		case 1: vacuumStatus = "cleaning"; break
		case 2: vacuumStatus = "2"; break
		case 3: vacuumStatus = "3"; break
		case 4: vacuumStatus = "docking"; break
		case 5: vacuumStatus = "docked/charging"; break
		case 6: vacuumStatus = "docked/charged"; break
		case 7: vacuumStatus = "paused"; break
		default: vacuumStatus = "${vacData.status}"
	}
	updateAttr("vacuumStatus", vacuumStatus)
	updateAttr("prompt", vacData.prompt)
	updateAttr("promptCode", vacData.promptCode_id)
	logData << [vacuumStatus: vacuumStatus, cleanOn: cleanOn, docking: docking,
			   mopState: mopState]
	if (vacData.status != 6 && vacData.status != 5) {
		runIn(60, getCleanData)
	}
	logDebug(logData)
}

//	==== Clean Preferences ====
def setCleanPrefs(passes=1, water="none") {
	def logData = [method: "setCleanPrefs", passes: passes, suction: suction, waterLevel: water]
	Integer sucNo
	switch(suction) {
		case "standard": sucNo = 2; break
		case "turbo": sucNo = 3; break
		case "max": sucNo = 4; break
		default: sucNo = 1
	}
	Integer watLev
	switch(water) {
		case "low": watLev = 2; break
		case "moderate": watLev = 3; break
		case "high": watLev = 4; break
		default: watLev = 1
	}
	List requests = [
		[method:"setCleanNumber", params:[
			clean_number: passes.toInteger(), cistern: watLev]],
		[method: "getCleanNumber"]]
	sendDevCmd(requests, "setCleanPrefs", "parseUpdates")
	logDebug(logData)
}

def parse_getCleanNumber(result, data) {
	logDebug([method: "parse_getCleanNumber", SourceMethod: data, result: result])
	updateAttr("cleanPasses", result.clean_number)
	String vacuumSuction
	switch(result.suction) {
		case 2: vacuumSuction = "standard"; break
		case 3: vacuumSuction = "turbo"; break
		case 4: vacuumSuction = "max"; break
		default: vacuumSuction = "quiet"
	}
	String waterLevel
	switch(result.cistern) {
		case 2: waterLevel = "low"; break
		case 3: waterLevel = "moderate"; break
		case 4: waterLevel = "high"; break
		default: waterLevel = "none"
	}
	updateAttr("waterLevel", waterLevel)
}

def parse_get_device_info(result, data) { }
def parse_getBatteryInfo(result, data) {
	logDebug([method: "parse_get_battery_info", SourceMethod: data, result: result])
	updateAttr("battery", result.battery_percentage)
}
def parse_getSwitchClean(result, data) {
	def roomList = []
	if (result.result) { roomList = result.result.room_list }
	updateAttr("cleaningList", roomList)
	logDebug([method: "parse_getSwitchClean", sourceMethod: data, roomList: roomList])
}
def parse_getSwitchCharge(result, data) {
	logDebug([method: "parse_getSwitchCharge", SourceMethod: data, result: result])
	updateAttr("docking", result.switch_charge)
}
def parse_getMopState(result, data) {
	logDebug([method: "parse_getMopState", SourceMethod: data, result: result])
	updateAttr("mopState", result.mop_state)
}

#include davegut.tpLinkCapConfiguration
#include davegut.tpLinkCommon
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.tpLinkTransKlap
#include davegut.tpLinkTransVacAes
#include davegut.Logging
