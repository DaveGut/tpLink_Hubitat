library (
	name: "tpLinkCamTransport",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "TP-Link Camera Protocol Implementation",
	category: "utilities",
	documentationLink: ""
)
import java.util.Random
import java.security.MessageDigest
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.Cipher
import java.security.KeyFactory
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.IvParameterSpec

def cameraHandshake(hsInput, devData = [:]) {
	Map logData = [url: hsInput.url]
	def warn = true
//	Step 1.	Determine secureUser (userName or "admin").
	def isSecure = state.isSecure
	if (isSecure != true) {
		isSecure = checkSecure(hsInput)
		state.isSecure = isSecure
		logData << [isSecure: isSecure]
	}
	if (isSecure == true) {
//	Step 2.	Confirm Device.
		Map confData = confirmDevice(hsInput)
		logData << [devConfData: confData]
		if (confData.confirmed == true) {
//	Step 3.	Get token data.
			Map tokenData = getToken(hsInput, confData)
			logData << [tokenData: tokenData]
			if (tokenData.status == "OK") {
//	Step 4. next action.
				if (app) {
					camCmdIn = [lsk: tokenData.lsk, ivb: tokenData.ivb, 
								seqNo: tokenData.seqNo, apiUrl: tokenData.apiUrl,
								encPwd: hsInput.pwd, cnonce: confData.cnonce]
					sendCameraDataCmd(devData, camCmdIn)
				} else if (device) {
					device.updateSetting("nonce", [type:"password", value: confData.nonce])
					device.updateSetting("cnonce", [type:"password", value: confData.cnonce])
					device.updateSetting("lsk",[type:"password", value: tokenData.lsk])
					device.updateSetting("ivb",[type:"password", value: tokenData.ivb])
					device.updateSetting("encPwd",[type:"password", value: hsInput.encPwd])
					device.updateSetting("apiUrl",[type:"password", value: tokenData.apiUrl])
					state.seqNo = tokenData.seqNo
				}
				warn = false
			}
		}
	}
	if (warn == true) { logWarn([cameraHandshake: logData]) }
	else {logDebug([cameraHandshake: logData]) }
	return logData
}

def checkSecure(hsInput) {
	secure = false
	Map cmdBody = [method: "login", params: [encrypt_type: "3",  username: hsInput.user]]
	Map respData = postSync(cmdBody, hsInput.url)
	if (respData.error_code == -40413 && respData.result && respData.result.data
		&& respData.result.data.encrypt_type.contains("3")) {
		secure = true
	}
	return secure
}

def confirmDevice(hsInput) {
	String cnonce = getSeed(8).encodeHex().toString().toUpperCase()
	Map cmdBody = [method: "login",
				   params: [cnonce: cnonce, encrypt_type: "3",  username: hsInput.user]]
	Map respData = postSync(cmdBody, hsInput.url)
	Map confData = [confirmed: false]
	if (!respData.status) {
		Map results = respData.result.data
		if (respData.error_code == -40413 && results.code == -40401 && 
			results.encrypt_type.toString().contains("3")) {
			String noncesPwdHash = cnonce + hsInput.pwd + results.nonce
			String testHash = mdEncode("SHA-256", noncesPwdHash.getBytes()).encodeHex().toString().toUpperCase()
			String checkData = testHash + results.nonce + cnonce
			if (checkData == results.device_confirm) {
				confData << [confirmed: true, nonce: results.nonce, cnonce: cnonce]
			} else {
				Map logData = [confirmDevice: [devErrCode: 
							   respData.error_code, confirmed: false, 
							   message: "Data confirm between device and Hubitat failed."]]
				logWarn(logData)
			}
		} else {
			Map logData = [confirmDevice: [devErrCode: respData.error_code,
						   confirmed: false, message: "Device returned invalid errorCode"]]
			logWarn(logData)
		}
	}
	return confData
}

def getToken(hsInput, confData) {
	Map tokenData = [:]
	String digestPwdHex = hsInput.pwd + confData.cnonce + confData.nonce
	String digestPwd = mdEncode("SHA-256", digestPwdHex.getBytes()).encodeHex().toString().toUpperCase()
	String fullDigestPwdHex = digestPwd + confData.cnonce + confData.nonce
	String fullDigestPwd = new String(fullDigestPwdHex.getBytes(), "UTF-8")
	Map cmdBody = [
		method: "login",
		params: [cnonce: confData.cnonce, 
				 encrypt_type: "3",
				 digest_passwd: fullDigestPwd,
				 username: hsInput.user
			]]
	Map respData = postSync(cmdBody, hsInput.url)
	Map logData = [errorCode: respData.error_code]
	if (respData.error_code == 0) {
		Map result = respData.result
		if (result != null) {
			if (result.start_seq != null) {
				if (result.user_group == "root") {
					byte[] lsk = genEncryptToken("lsk", hsInput.pwd, confData.nonce, confData.cnonce)
					byte[] ivb = genEncryptToken("ivb", hsInput.pwd, confData.nonce, confData.cnonce)
					String apiUrl = "${hsInput.url}/stok=${result.stok}/ds"
					tokenData << [seqNo: result.start_seq, lsk: lsk, ivb: ivb,
								  apiUrl: apiUrl, status: "OK"]
				} else {
					tokenData << [status: "invalidUserGroup"]
				}
			} else {
				tokenData << [status: "nullStartSeq"]
			}
		} else {
			tokenData << [status: "nullDataFrom Device", respData: respData]
		}
	} else {
		tokenData << [status: "credentialError"]
	}
	if (tokenData.status != "OK") {
		logData << [tokenData: tokenData, respData: respData]
		logWarn([getToken: logData])
	}
	return tokenData
}

def genEncryptToken(tokenType, pwd, nonce, cnonce) {
	String hashedKeyHex = cnonce + pwd + nonce
	String hashedKey = mdEncode("SHA-256", hashedKeyHex.getBytes()).encodeHex().toString().toUpperCase()
	String tokenHex = tokenType + cnonce + nonce + hashedKey
	byte[] tokenFull = mdEncode("SHA-256", tokenHex.getBytes())
	return tokenFull[0..15]
}

def shortHandshake() {
	String pwd = parent.encPasswordCam
	String url = getDataValue("baseUrl")
	Map logData = [:]
	String digestPwdHex = pwd + cnonce + nonce
	String digestPwd = mdEncode("SHA-256", digestPwdHex.getBytes()).encodeHex().toString().toUpperCase()
	String fullDigestPwdHex = digestPwd + cnonce + nonce
	String fullDigestPwd = new String(fullDigestPwdHex.getBytes(), "UTF-8")
	Map cmdBody = [
		method: "login",
		params: [cnonce: cnonce, 
				 encrypt_type: "3",
				 digest_passwd: fullDigestPwd,
				 username: parent.userName
			]]
	Map respData = postSync(cmdBody, url)
	
	logData << [errorCode: respData.error_code]
	String tokenStatus = "OK"
	if (respData.error_code == 0) {
		Map result = respData.result
		if (result != null) {
			if (result.start_seq != null) {
				if (result.user_group == "root") {
					byte[] lsk = genEncryptToken("lsk", pwd, nonce, cnonce)
					byte[] ivb = genEncryptToken("ivb", pwd, nonce, cnonce)
					String apiUrl = "${url}/stok=${result.stok}/ds"
logData << [seqNo: result.start_seq, lsk: lsk, ivb: ivb, apiUrl: apiUrl]
					device.updateSetting("lsk",[type:"password", value: lsk])
					device.updateSetting("ivb",[type:"password", value: ivb])
					device.updateSetting("apiUrl",[type:"password", value: apiUrl])
					state.seqNo = result.start_seq
				} else {
					tokenStatus = "invalidUserGroup"
				}
			} else {
				tokenStatus = "nullStartSeq"
			}
		} else {
			tokenStatus = "nullDataFrom Device"
		}
	} else {
		tokenStatus ="credentialError"
	}
	if (tokenStatus != "OK") {
		Map hsInput = [url: url, user: parent.userName, pwd: pwd]
		logData << [respData: respData, cameraHandshake: cameraHandshake(hsInput)]
		logWarn([shortHandshake: logData])
	}
	return logData
}

//	===== Sync Communications =====
def getCamHeaders() {
	Map headers = [
		"Accept": "application/json",
		"Accept-Encoding": "gzip, deflate",
		"User-Agent": "Tapo CameraClient Android",
		"Connection": "close",
		"requestByApp": "true",
		"Content-Type": "application/json; charset=UTF-8"
		]
	return headers
}

def postSync(cmdBody, baseUrl) {
	Map respData = [:]
	Map heads = getCamHeaders()
	Map httpParams = [uri: baseUrl,
					 body: JsonOutput.toJson(cmdBody),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 ignoreSSLIssues: true,
					 headers: heads
					 ]
	try {
		httpPostJson(httpParams) { resp ->
			if (resp.status == 200) {
				respData << resp.data
			} else {
				respData << [status: resp.status, errorData: resp.properties,
							 action: "<b>Check IP Address</b>"]
				logWarn(respData)
			}
		}
	} catch (err) {
		respData << [status: "httpPostJson error", error: err]
		logWarn(respData)
	}
	return respData
}

def getCameraParams(cmdBody, reqData) {
	byte[] encKey = new JsonSlurper().parseText(lsk)
	byte[] encIv = new JsonSlurper().parseText(ivb)
	def cmdStr = JsonOutput.toJson(cmdBody)
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
	String cmdData = new groovy.json.JsonBuilder(reqBody).toString()
	Integer seqNumber = state.seqNo
	String initTagHex = parent.encPasswordCam + cnonce
	String initTag = mdEncode("SHA-256", initTagHex.getBytes()).encodeHex().toString().toUpperCase()
	String tagString = initTag + cmdData + seqNumber
	String tag =  mdEncode("SHA-256", tagString.getBytes()).encodeHex().toString().toUpperCase()
	Map heads = getCamHeaders()
	heads << ["Tapo_tag": tag, Seq: seqNumber]
	Map reqParams = [uri: apiUrl,
					 body: cmdData,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 15,
					 ignoreSSLIssues: true,
					 headers: heads
					]
	return reqParams
}

def parseCameraData(resp, data) {
	Map parseData = [sourceMethod: data.data, jsonErrCode: resp.json.error_code]
	state.seqNo += 1
	if (resp.json.error_code == 0) {
		try {
			byte[] encKey = new JsonSlurper().parseText(lsk)
			byte[] encIv = new JsonSlurper().parseText(ivb)
			Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
															 	encKey, encIv))
			parseData << [parseStatus: "OK", cmdResp: cmdResp]
			state.protoError = false
		} catch (err) {
			parseData << [parseStatus: "Decrypt Error", error: err]
       }
	} else {
		parseData << [parseStatus: "Protocol Error"]
	}
	if (parseData.parseStatus != "OK") {
		if (state.protoError == false) {
			parseData << [nextMeth: "resolveProtocolError"]
			resolveProtocolError()
		}
	}
	return parseData
}

//	Run deviceHandshake then retry command
def resolveProtocolError() {
	Map logData = [method: "resolveProtocolError", lastCmd: state.lastCommand]
	state.protoError = true
	deviceHandshake()
	runIn(4, delayedPassThrough)
	logDebug(logData)
}

