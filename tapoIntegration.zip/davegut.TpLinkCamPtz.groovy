/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Supports:  Tapo PTZ Cameras

Known issues:
1.	Not all setting functions available on Hubitat.  User should request.
2.	Driver does not work for Tapo H200/H500 cameras.

Note on Battery Capable Devices: These devices are either solely battery powered or
connected to a power source to continually charge the battery.  To achieve the maximum
battery life, the functions are somewhat limited.  Some limitations
a.	Non- ONIF and RSTP video format.
b.	If not wired, the use of polling will have sever impact on battery time between
	recharge.  Consider using other means to bring data into Hubitat and turn off
	polling.
	1)	Link to Amazon and create rules linked to Hubitat virtual device.
	2)	Use Tapo Smart Actions linking to a bulb/dimmer in your home and use bulb-level
		to set motion/ring attributes plus set inactive (I use 10-20 to set and 0 to
		set inactive).
=================================================================================================*/
metadata {
	definition (name: "TpLink Cam Ptz", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_cam_ptz.groovy")
	{
		command "patrolMode", [
			[name: "Patrol between defined viewPoints. ",
			 constraints: ["on", "off"], type: "ENUM"],
			[name: "view duration (secs), ",
			 constraints: [10, 20, 30], type: "ENUM"]]
		attribute "patrolMode", "string"
		command "setViewpoint", [[
			name: "Go to camera viewpoint. ",
			constraints: [1, 2, 3, 4, 5, 6, 7, 8], type: "ENUM"]]
		attribute "currViewpoint", "string"
	}
	preferences {
		commonPreferences()
	}
}

def installed() {
	state.viewPoints = []
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def updDevSettings() {
	List requests = [
	]
	comUpdDevSettings(requests)
	return "Device Settings Updated"
}	

def refresh() {
	List requests = [
		[method:"getPresetConfig", params: [preset:[name: "preset"]]]
	]
	comRefresh(requests)
	logDebug([method: "refresh"])
}

def parse_getPresetConfig(devResp) {
	state.viewPoints = devResp.preset.preset.id
	return [viewPoints: vPoints]
}

def patrolMode(onOff = "on", vTime = 10) {
	Map logData = [method: "patrolMode", onOff: onOff, lag: lag, viewPoints: state.viewPoints]
	if (state.viewPoints.size() < 2) {
		logData << [error: "Must have at least 2 viewPoints set for patrol mode"]
		logWarn(logData)
		return
	}
	if (onOff == "off") {
		stopPatrol()
	} else {
		moveToPreset(state.viewPoints[0])
		schedule("*/${vTime} * * * * ?", "runPatrol")
		runIn(300, stopPatrol)
	}
	sendEvent(name: "patrolMode", value: onOff)
	logData << [patrolMode: onOff]
	logDebug(logData)
}

def runPatrol() {
	def nextVpIndex = state.viewPoints.indexOf(state.lastViewpoint) + 1
	if (nextVpIndex >= state.viewPoints.size()) { nextVpIndex = 0 }
	moveToPreset(state.viewPoints[nextVpIndex])
}

def stopPatrol() {
	unschedule("runPatrol")
	sendEvent(name: "patrolMode", value: "off")
	logDebug([method: "patrolMode", patrolMode: "off"])
}

def setViewpoint(presetId) {
	Map logData = [method: "setViewpoint", viewpointNo: presetId, vpIds: state.viewPoints]
	if (state.viewPoints.contains(presetId)) {
		logData << [lastViewpoint: presetId]
		moveToPreset(presetId)
		logDebug(logData)
	} else {
		logData << [status: "ERROR", data: "Viewpoint ${presetId} is not defined."]
		logWarn(logData)
	}
}

def moveToPreset(presetId) {
	List requests = [[method: "motorMoveToPreset", params: [preset: [goto_preset: [id:presetId]]]]]
	state.lastViewpoint = presetId.toString()
	sendDevCmd(requests, "moveToPreset", "parseUpdates")
}

#include davegut.tpLinkCamCommon
#include davegut.tpLinkCapConfiguration
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.tpLinkCamTransport
#include davegut.Logging
