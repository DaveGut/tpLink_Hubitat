library (
	name: "appTpLinkSmart",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Tapo protocol devices.",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
 
def createTpLinkCreds() {
	Map SMARTCredData = [u: userName, p: userPassword]
	//	User Creds (username/password hashed)
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "string", value: encUsername])
	SMARTCredData << [encUsername: encUsername]
	String encPassword = userPassword.trim().bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "string", value: encPassword])
	SMARTCredData << [encPassword: encPassword]
	//	vacAes Creds (password only)
	String encPasswordVac = mdEncode("MD5", userPassword.trim().bytes).encodeHex().toString().toUpperCase()
	app?.updateSetting("encPasswordVac", [type: "string", value: encPasswordVac])
	SMARTCredData << [encPasswordVac: encPasswordVac]
	//	Camera Creds (password only)
	String encPasswordCam = mdEncode("SHA-256", userPassword.trim().bytes).encodeHex().toString().toUpperCase()
	app?.updateSetting("encPasswordCam", [type: "string", value: encPasswordCam])
	SMARTCredData << [encPasswordCam: encPasswordCam]
	//	KLAP Local Hash
	byte[] userHashByte = mdEncode("SHA-1", encodeUtf8(userName).getBytes())
	byte[] passwordHashByte = mdEncode("SHA-1", encodeUtf8(userPassword.trim()).getBytes())
	byte[] authHashByte = [userHashByte, passwordHashByte].flatten()
	String authHash = mdEncode("SHA-256", authHashByte).encodeBase64().toString()
	app?.updateSetting("localHash", [type: "string", value: authHash])
	SMARTCredData << [localHash: localHash]
	logDebug(SMARTCredData)
	return [SMARTDevCreds: SMARTCredData]
}

def findTpLinkDevices(action, timeout = 10) {
	Map logData = [method: "findTpLinkDevices", action: action, timeOut: timeout]
	def start = state.hostArray.min().toInteger()
	def finish = state.hostArray.max().toInteger() + 1
	logData << [hostArray: state.hostArray, pollSegments: state.segArray]
	List deviceIPs = []
	state.segArray.each {
		def pollSegment = it.trim()
		logData << [pollSegment: pollSegment]
		for(int i = start; i < finish; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
		logData << [pass1: "port 20002"]
		sendLanCmd(deviceIPs.join(','), "20002", cmdData, action, timeout)
		runIn(timeout + 5, udpTimeout)
		pauseExecution(10000)
		logData << [pass2: "port 20004"]
		sendLanCmd(deviceIPs.join(','), "20004", cmdData, action, timeout)
		runIn(timeout + 5, udpTimeout)
	}
	logInfo(logData)
	state.tpLinkChecked = true
	runIn(570, resetTpLinkChecked)
	return logData
}

def udpTimeout() {
	Map logData = [method: "udpTimeout", status: "no devices found", error: "udpTimeout"]
	logWarn(logData)
	atomicState.finding = false
}

def getTpLinkLanData(response) {
	Map logData = [method: "getTpLinkLanData", 
				   action: "Completed LAN Discovery",
				   smartDevicesFound: response.size()]
	logInfo(logData)
	unschedule("udpTimeout")
	List discData = []
	if (response instanceof Map) {
		Map devData = getDiscData(response)
		if (devData.status == "OK") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK" && !discData.toString().contains(devData.dni)) {
				discData << devData
			}
		}
	}
	getAllTpLinkDeviceData(discData)
	runIn(60, updateTpLinkDevices, [data: discData])
}

def getDiscData(response) {
	Map devData = [:]
	Map unsupDev = atomicState.unsupported
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			//	Handle Jumbo packets
			if (payloadString.length() > 1007) {
				if (payloadString.contains(""":"H200",""")) {
					//	H200. Keep data up to, but not including "key"
					payloadString = payloadString.substring(0,payloadString.indexOf(""","key":""")) + "}}}"
				} else {
					//	Unknown cases with fingers crossed.  (Note: I could go through a lot of processing
					//	here to determine the break point; however, I am lazy and it is a currently undiscovered case..)
					payloadString = payloadString + """"}}}"""
				}
			}
			Map payload = new JsonSlurper().parseText(payloadString).result
			List supported = supportedProducts()
			String devType = payload.device_type
			String model = payload.device_model
			String devIp = payload.ip
			String protocol = payload.mgt_encrypt_schm.encrypt_type
			String status = "true"
			if (protocol == "TPAP") { 
				status = "Protocol not supported"
				unsupDev << ["<b>${model}</b>": "Protocol ${protocol} not supported"]
			}	else if (model == "HS200") {
				status = "Device model not supported"
				unsupDev << ["<b>${model}</b>": "Model ${model} not supported"]
			}	else if (!supported.contains(devType)) { 
				status = "Device type not supported" 
				unsupDev << ["<b>${model}</b>": "DevType ${devType} not supported"]
			}
			if (status == "true") {
				String dni = payload.mac.replaceAll("-", "")
				String port = payload.mgt_encrypt_schm.http_port
				String httpStr = "http://"
				String httpPath = "/app"
				if (payload.mgt_encrypt_schm.is_support_https) {
					httpStr = "https://"
				}
				if (devType == "SMART.IPCAMERA" || devType == "SMART.TAPODOORBELL") {
					protocol = "camera"
					port = "443"
				} else if (devType == "SMART.TAPOROBOVAC" && protocol == "AES") {
					protocol = "vacAes"
					httpPath = ""
				}
				String baseUrl = httpStr + devIp + ":" + port + httpPath
				devData << [udpPort: respData.port, type: devType, model: model, baseUrl: baseUrl, 
							dni: dni, ip: devIp, port: port, protocol: protocol, status: "OK"]
				if (payload.power) { devData << [power: payload.power] }
				logDebug(devData)
			} else {
				Map errResp = [method: "getDiscData", payload: payload, status: status]
				logWarn(errResp)
			}
		}
	} catch (err) {
		devData << [status: "INVALID", respData: repsData, error: err]
		logWarn(devData)
	}
	atomicState.unsupported = unsupDev
	return devData
}

def getAllTpLinkDeviceData(List discData) {
	Map logData = [method: "getAllTpLinkDeviceData", discData: discData.size()]
	discData.each { Map devData ->
		if (devData.protocol == "KLAP") {
			klapHandshake(devData.baseUrl, localHash, devData)
		} else if (devData.protocol == "AES") {
			aesHandshake(devData.baseUrl, devData)
		} else if (devData.protocol == "vacAes") {
			vacAesHandshake(devData.baseUrl, userName, encPasswordVac, devData)
		} else if (devData.protocol == "camera") {
			Map hsInput = [url: devData.baseUrl, user: userName, pwd: encPasswordCam]
			cameraHandshake(hsInput, devData)
		} else { 
			unknownProt(devData)
		}
		pauseExecution(1000)
	}
	atomicState.finding = false
	logDebug(logData)
}

def getDataCmd() {
	List requests = [[method: "get_device_info"]]
	requests << [method: "component_nego"]
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def addToDevices(devData, cmdData) {
	Map logData = [method: "addToDevices"]
	String dni = devData.dni
	def devicesData = atomicState.devices
	devicesData.remove(dni)
	def comps
	def cmdResp
	String alias
	String tpType = devData.type
	String model = devData.model
	if (devData.protocol != "camera") {
		comps = cmdData.find { it.method == "component_nego" }
		comps = comps.result.component_list
		cmdResp = cmdData.find { it.method == "get_device_info" }
		cmdResp = cmdResp.result
		byte[] plainBytes = cmdResp.nickname.decodeBase64()
		alias = new String(plainBytes)
		if (alias == "") { alias = model }
	} else {
		comps = cmdData.find { it.method == "getAppComponentList" }
		comps = comps.result.app_component.app_component_list
		cmdResp = cmdData.find { it.method == "getDeviceInfo" }
		cmdResp = cmdResp.result.device_info.basic_info
		alias = cmdResp.device_alias
		if (alias == "") { alias = model }
	}
	def type = "Unknown"
	def ctHigh
	def ctLow
	Map deviceData = [devIp: devData.ip, deviceType: tpType, protocol: devData.protocol,
					  model: model, baseUrl: devData.baseUrl, alias: alias]
	//	Determine Driver to Load
	if (tpType.contains("PLUG") || tpType.contains("SWITCH")) {
		type = "Plug"
		if (comps.find { it.id == "control_child" }) {
			type = "Parent"
		} else if (comps.find { it.id == "dimmer" }) {
			type = "Dimmer"
		}
	} else if (tpType.contains("HUB")) {
		type = "Hub"
	} else if (tpType.contains("BULB")) {
		type = "Dimmer"
		if (comps.find { it.id == "light_strip" }) {
			type = "Lightstrip"
		} else if (comps.find { it.id == "color" }) {
			type = "Color Bulb"
		}
		if (type != "Dimmer" && comps.find { it.id == "color_temperature" } ) {
			ctHigh = cmdResp.color_temp_range[1]
			ctLow = cmdResp.color_temp_range[0]
			deviceData << [ctHigh: ctHigh, ctLow: ctLow]
		}
	} else if (tpType.contains("ROBOVAC")) {
		type = "Robovac"
	} else if (tpType.contains("CAMERA")) {
		type = "Camera"
		if (comps.find { it.name == "ptz" } ) {
			type = "Cam Ptz"
		}
	} else if (tpType.contains("DOORBELL")) {
		type = "Camera"
		deviceData << [isDoorbell: "true"]
	} else if (tpType.contains("CHIME")) {
		type = "Chime"
	}
	deviceData << [type: type]
	if (comps.find {it.id == "led"} ) { 
		String ledVer = comps.find {it.id == "led"}.ver_code
		deviceData << [ledVer: ledVer]
	}
	if (comps.find {it.id == "energy_monitoring"}) { deviceData << [isEm: "true"] }
	if (comps.find {it.id == "on_off_gradually"}) { deviceData << [gradOnOff: "true"] }
	if (comps.find { it.name == "led"}) {
		String ledVer = comps.find { it.name == "led" }.version
		deviceData << [ledVer: ledVer]
	}
	if (comps.find {it.name == "alert"}) { deviceData << [alert: "true"] }
	if (devData.power) { deviceData << [power: devData.power] }
	devicesData << ["${dni}": deviceData]
	atomicState.devices = devicesData
	logData << ["${deviceData.alias}": deviceData, dni: dni]
	Map InfoData = ["${deviceData.alias}": "added to device data"]
	logInfo("${deviceData.alias}: added to device data")
	updateChild(dni, deviceData)
	logDebug(logData)
}

def updateChild(dni, deviceData) {
	def child = getChildDevice(dni)
	if (child) {
		child.updateChild(deviceData)
	}
}

//	===== get Smart KLAP Protocol Data =====
def sendKlapDataCmd(handshakeData, data) {
	if (handshakeData.respStatus != "Login OK") {
		Map logData = [method: "sendKlapDataCmd", handshake: handshakeData]
		logWarn(logData)
	} else {
		Map reqParams = [timeout: 10, headers: ["Cookie": data.data.cookie]]
		def seqNo = data.data.seqNo + 1
		String cmdBodyJson = new groovy.json.JsonBuilder(getDataCmd()).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), data.data.encKey, 
										data.data.encIv, data.data.encSig, seqNo)
		reqParams << [
			uri: "${data.data.baseUrl}/request?seq=${encryptedData.seqNumber}",
			body: encryptedData.cipherData,
			ignoreSSLIssues: true,
			timeout:10,
			contentType: "application/octet-stream",
			requestContentType: "application/octet-stream"]
		asynchttpPost("parseKlapResp", reqParams, [data: data.data])
	}
}

def parseKlapResp(resp, data) {
	Map logData = [method: "parseKlapResp", ip: data.data.devData.ip]
	if (resp.status == 200) {
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse, data.data.encKey,
										data.data.encIv, data.data.seqNo + 1)
			Map cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp", cmdResp: cmdResp]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== get Smart Camera Protocol Data =====
def sendCameraDataCmd(devData, camCmdIn) {
	List requests = [[method:"getDeviceInfo", params:[device_info:[name:["basic_info"]]]],
					 [method:"getAppComponentList", params:[app_component:[name:"app_component_list"]]]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	def cmdStr = JsonOutput.toJson(cmdBody)
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, camCmdIn.lsk, camCmdIn.ivb)]]
	String cmdData = new groovy.json.JsonBuilder(reqBody).toString()
	String initTagHex = camCmdIn.encPwd + camCmdIn.cnonce
	String initTag = mdEncode("SHA-256", initTagHex.getBytes()).encodeHex().toString().toUpperCase()
	String tagString = initTag + cmdData + camCmdIn.seqNo
	String tag =  mdEncode("SHA-256", tagString.getBytes()).encodeHex().toString().toUpperCase()
	Map heads = getCamHeaders()
	heads << ["Tapo_tag": tag, Seq: camCmdIn.seqNo]
	Map reqParams = [uri: camCmdIn.apiUrl,
					 body: cmdData,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 ignoreSSLIssues: true,
					 headers: heads
					]
	asynchttpPost("parseCameraResp", reqParams, [data: [devData: devData, camCmdIn: camCmdIn]])
}

def parseCameraResp(resp, data) {
	Map logData = [method: "parseCameraResp", ip: data.data.devData.ip]
	if (resp.json.error_code == 0) {
		resp = resp.json
		try {
			def clearResp = aesDecrypt(resp.result.response, data.data.camCmdIn.lsk, 
									   data.data.camCmdIn.ivb)
			Map cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
                logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp", cmdResp: cmdResp]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "decryptDataError", error: err]
			logWarn(logData)
		}
	} else {
		logData << [status: "rerurnDataErrorCode", resp: resp]
		logWarn(logData)
	}
}

//	===== get Smart AES Protocol Data =====
def getAesToken(resp, data) {
	Map logData = [method: "getAesToken"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				def clearResp = aesDecrypt(resp.json.result.response, data.encKey, data.encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					logDebug(logData)
					sendAesDataCmd(token, data)
				} else {
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					logWarn(logData)
				}
			} catch (err) {
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				logWarn(logData)
			}
		} else {
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		logWarn(logData)
	}
}

def sendAesDataCmd(token, data) {
	def cmdStr = JsonOutput.toJson(getDataCmd()).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, data.encKey, data.encIv)]]
	Map reqParams = [uri: "${data.baseUrl}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 headers: ["Cookie": data.cookie]]
	asynchttpPost("parseAesResp", reqParams, [data: data])
}

def parseAesResp(resp, data) {
	Map logData = [method: "parseAesResp"]
	if (resp.status == 200) {
		try {
			Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
																 data.data.encKey, data.data.encIv))
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== get Smart vacAes Protocol Data =====
def sendVacAesDataCmd(token, data) {
	Map devData = data.data.devData
	Map reqParams = getVacAesParams(getDataCmd(), "${data.data.baseUrl}/?token=${token}")
	asynchttpPost("parseVacAesResp", reqParams, [data: devData])
}

def parseVacAesResp(resp, devData) {
	Map logData = [parseMethod: "parseVacAesResp"]
	try {
		Map cmdResp = resp.json
		logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(devData.data, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
	} catch (err) {
		logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		logWarn(logData)
	}
	return parseData
}

//	===== Support device data update request =====
def tpLinkCheckForDevices(timeout = 5) {
	Map logData = [method: "tpLinkCheckForDevices"]
	def checked = true
	if (state.tpLinkChecked == true) {
		checked = false
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		def findData = findTpLinkDevices("parseTpLinkCheck", timeout)
		logData << [status: "checking"]
		pauseExecution((timeout+2)*1000)
	}
	logDebug(logData)
	return checked
}

def resetTpLinkChecked() { state.tpLinkChecked = false }

def parseTpLinkCheck(response) {
	List discData = []
	if (response instanceof Map) {
		Map devdata = getDiscData(response)
		if (devData.status != "INVALID") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
//	atomicState.finding = false
	updateTpLinkDevices(discData)
}

def updateTpLinkDevices(discData) {
	Map logData = [method: "updateTpLinkDevices"]
	state.tpLinkChecked = true
	runIn(570, resetTpLinkChecked)
	List children = getChildDevices()
	children.each { childDev ->
		Map childData = [:]
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (childDev.getDataValue("baseUrl")) {
			if (devData != null) {
				if (childDev.getDataValue("baseUrl") == devData.baseUrl &&
				    childDev.getDataValue("protocol") == devData.protocol) {
					childData << [status: "noChanges"]
				} else {
					childDev.updateDataValue("baseUrl", devData.baseUrl)
					childDev.updateDataValue("protocol", devData.protocol)
					childData << ["baseUrl": devData.baseUrl,
								  "protocol": devData.protocol,
								  "connected": "true"]
				}
			} else {
				Map warnData = [method: "updateTpLinkDevices", device: childDev,
								connected: "false", reason: "not Discovered By App"]
				logWarn(warnData)
			}
			pauseExecution(500)
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
}
