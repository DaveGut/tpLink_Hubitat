library (
	name: "tpLinkParentCommon",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Parent common methods",
	category: "utilities",
	documentationLink: ""
)

def installChildDevices() {
	Map request = [method: "get_child_device_list"]
	asyncSend(request, "installChildDevices", "installChildren")
}

def installChildren(resp, data=null) {
	Map logData = [method: "installChildren", currentChildren: getChildDevices()]
	logInfo(logData)
	def respData = parseData(resp, getDataValue("protocol"), data)
	if (respData.cmdResp != null) {
		def children = respData.cmdResp.result.child_device_list
		Integer position = 0
		children.each {
			position += 1
			String  childDni = "${it.mac}-${position.toString()}"
			def isChild = getChildDevice(childDni)
			byte[] plainBytes = it.nickname.decodeBase64()
			String alias = new String(plainBytes)
			Map instData = [alias: alias, childDni: childDni]
			if (isChild) {
				instData << [status: "device already installed"]
				logInfo(instData)
			} else {
				def isEm = false
				if (it.protection_power != null) {
					isEm = true
				}
				String devType = getDeviceType(it.category)
				instData << [label: alias, name: it.model, type: devType, deviceId: 
							 it.device_id, category: it.category]
				if (devType == "Child Undefined") {
					instData << [status: "notInstalled", error: "Currently Unsupported"]
					logInfo(instData)
				} else {
					try {
						addChildDevice(
							nameSpace(), 
							"TpLink ${devType}",
							childDni,
							[
								"label": alias,
								"name": it.model,
								category: it.category,
								deviceId: it.device_id,
								type: devType,
								isEm: isEm
							])
						instData << [status: "Installed"]
						logInfo(instData)
					} catch (err) {
						instData << [status: "FAILED", error: err, driverNotInstalled: "TpLink ${devType}"]
						logWarn(instData)
						logWarn("\n\r<b>Driver TpLink ${devType} likely not installed.\n\r")
					}
				}
			}
		}
		device.updateSetting("installChild", [type: "bool", value: "false"])
	}
}

def getDeviceType(category) {
	String deviceType
	switch(category) {
		case "subg.trigger.contact-sensor":
			deviceType = "Hub Contact"
			break

		case "subg.trigger.motion-sensor":
			deviceType = "Hub Motion"
			break

		case "subg.trigger.button":
			deviceType = "Hub Button"
			break

		case "subg.trigger.temp-hmdt-sensor":
			deviceType = "Hub TempHumidity"
			break

		case "subg.trigger.water-leak-sensor":
			deviceType = "Hub Leak"
			break

		case "subg.trv":
			deviceType = "Hub Trv"
			break

		case "subg.plugswitch.switch":
		case "subg.plugswitch.plug":
			deviceType = "Hub Plug"
			break

		//	===== PARENT CONNECTED =====
		case "plug.powerstrip.sub-plug":
			deviceType = "Child Plug"
			break

 		case "kasa.switch.outlet.sub-fan":
			deviceType = "Child Fan"
			break

 		case "kasa.switch.outlet.sub-dimmer":
		case "plug.powerstrip.sub-bulb":
			deviceType = "Child Dimmer"
			break
		
		default:
			deviceType = "Child Undefined"
	}
	return deviceType
}

//	Data Distribution
def distChildGetData(devResp, data) {
	def child = getChildDevice(data.data)
	switch(devResp.method) {
		case "get_device_info":
			child.parse_get_device_info(devResp.result, data)
			child.parseNameUpdate(devResp.result)
			break
		case "get_current_power":
			child.parse_get_current_power(devResp.result, data)
			break
		case "get_device_usage":
			child.parse_get_device_usage(devResp.result, data)
			break
		case "get_trigger_logs":
			child.parse_get_trigger_log(devResp.result, data)
			break
		default:
			if (!devResp.method.contains("set_")) {
				Map logData = [method: "distGetData", data: data,
							   devMethod: devResp.method, status: "unprocessed"]
				logDebug(logData)
			}
	}
}

def parse_get_child_device_list(result, data) {
	Map logData = [method: "get_child_device_list", data: data]
	def children = getChildDevices()
	children.each { child ->
		def devId = child.getDataValue("deviceId")
		def childData = result.child_device_list.find{ it.device_id == devId }
		child.parse_get_device_info(childData, data)
	}
	logData << [status: "OK"]
	logDebug(logData)
}
