/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub Button", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleInstance: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_button.groovy")
	{
		attribute "lowBattery", "string"
		capability "Sensor"
		attribute "lastTriggerNo", "NUMBER"
		attribute "button", "STRING"
	}
	preferences {
		commonPreferences()
	}
}

def installed() { runIn(1, updated) }

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info"]
	getTriggerLog(1)
	updateAttr("lowBattery", result.at_low_battery.toString())
	logData << [battery: result.at_low_battery.toString()]
	logDebug(logData)
}

def getTriggerLog(count) {
	List requests = [[method: "get_trigger_logs",
				   params: [page_size: 1,"start_id": 0]]]
	sendDevCmd(requests, device.getDeviceNetworkId(), "parseUpdates")
}

def parse_get_trigger_log(result, data = null) {
	Map logData = [method: "parse_get_trigger_log", data: data, result: result]
	triggerLog = result.logs[0]
	if (device.currentValue("lastTriggerNo") != triggerLog.id) {
		sendEvent(name: "lastTriggerNo", value: triggerLog.id)
		String trigger = triggerLog.event
		if (trigger == "rotation") {
			trigger = "rotateCW"
			if (triggerLog.params.rotate_deg < 0) {
				trigger = "rotateCCW"
			}
		}
		sendEvent(name: "button", value: trigger)
		logData << [ lastTriggerNo: triggerLog.start_id, button: trigger]
	}
	logDebug(logData)
}

#include davegut.tpLinkChildCommon
#include davegut.Logging
