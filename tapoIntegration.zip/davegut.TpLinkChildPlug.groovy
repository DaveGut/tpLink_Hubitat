/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md 
=================================================================================================*/

metadata {
	definition (name: "TpLink Child Plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_child_plug.groovy")
	{ }
	preferences {
		if (getDataValue("isEm") == "true") {
			emPreferences()
		}
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed"]
	logData << [commonInst: commonInstalled()]
	state.eventType = "digital"
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info", data: data, result: result]
	switchParse(result)
	logDebug(logData)
}

#include davegut.tpLinkCapSwitch
#include davegut.tpLinkCapEngMon
#include davegut.tpLinkChildCommon
#include davegut.Logging
