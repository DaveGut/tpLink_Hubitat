/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub TempHumidity", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_tempHumidity.groovy")
	{
		capability "Temperature Measurement"
		capability "Relative Humidity Measurement"
		attribute "lowBattery", "string"
		capability "Sensor"
	}
	preferences {
		input ("tempUnit", "Enum",  title: "Temperature Scale", 
			   options: ["C", "F"], defaultValue: "C")
		commonPreferences()
	}
}

def installed() {
	runIn(1, updated) }

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	state.BETA_VERSION = "This is a beta version of the driver."
	logInfo(logData)
}

def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info"]
	updateAttr("temperature", result.current_temp)
	updateAttr("humidity", result.current_humidity)
	logData << [temperature: result.current_temp, humidity: result.current_humidity]
	logDebug(logData)
}

#include davegut.tpLinkChildCommon
#include davegut.Logging
