library (
	name: "tpLinkTransVacAes",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Handshake methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)

//	===== Login =====
def vacAesHandshake(baseUrl, userName, encPasswordVac, devData = null) { 
	Map reqData = [baseUrl: baseUrl, devData: devData]
	if (device) {
		userName = parent.userName
		encPasswordVac = parent.encPasswordVac
	}
	Map cmdBody = [method: "login",
				   params: [hashed: true, 
							password: encPasswordVac,
							username: userName]]
	Map reqParams = getVacAesParams(cmdBody, baseUrl)
	asynchttpPost("parseVacAesLogin", reqParams, [data: reqData])
}

def parseVacAesLogin(resp, data) {
	Map logData = [method: "parseVacAesLogin", oldToken: token]
	if (resp.status == 200 && resp.json != null) {
		def newToken = resp.json.result.token
		logData << [status: "OK", token: newToken]
		if (device) {
			device.updateSetting("token", [type: "string", value: newToken])
			setCommsError(200)
		} else {
			sendVacAesDataCmd(newToken, data)
		}			
		logDebug(logData)
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

def getVacAesParams(cmdBody, url) {
	Map reqParams = [uri: url,
					 body: cmdBody,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 ignoreSSLIssues: true,
					 timeout: 10]
	return reqParams	
}

def parseVacAesData(resp, data) {
	Map parseData = [parseMethod: "parseVacAesData", sourceMethod: data.data]
	try {
		parseData << [cryptoStatus: "OK", cmdResp: resp.json]
		logDebug(parseData)
	} catch (err) {
		parseData << [cryptoStatus: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		logWarn(parseData)
		handleCommsError()
	}
	return parseData
}
