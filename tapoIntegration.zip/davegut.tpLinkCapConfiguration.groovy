library (
	name: "tpLinkCapConfiguration",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat capability Configuration.",
	category: "utilities",
	documentationLink: ""
) 

capability "Configuration"

def configure() {
	String devIp = getDataValue("devIp")
	Map logData = [method: "configure", devIp: devIp]
	def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
//	try {
//		if (getDataValue("power")) {
//			sendFindCmd(devIp, "20004", cmdData, "configure2", 5)
//		} else {
//			sendFindCmd(devIp, "20002", cmdData, "configure2", 5)
//		}
//		logInfo(logData)
//	} catch (err) {
		def parentChecked = parent.tpLinkCheckForDevices(5)
		logData << [status: "FAILED", error: err, parentChecked: parentChecked]
		logWarn(logData)
		configure3()
//	}
}

def configure2(response) {
	Map logData = [method: "configure2"]
	def respData = parseLanMessage(response)
	String hubDni = device.getDeviceNetworkId()
	logData << [dni: respData.mac, hubDni: hubDni]
	def parentChecked = false
	if (respData.mac != hubDni) {
		logData << [status: "device/ip not found", action: "parentCheck",
				    parentChecked: parent.tpLinkCheckForDevices(5)]
	} else {
		logData << [status: "device/ip found"]
	}
	configure3()
	logInfo(logData)
}
def configure3() {
	Map logData = [method: "configure3"]
	logData <<[updateDeviceData: updateDeviceData(true)]
	logData << [deviceHandshake: deviceHandshake()]
	if (getDataValue("protocol") != "camera") {
		runEvery3Hours("deviceHandshake")
		logData << [handshakeInterval: "3 Hours"]
	}
	runIn(5, refresh)
	logInfo(logData)
}

def deviceHandshake() {
	def protocol = getDataValue("protocol")
	Map logData = [method: "deviceHandshake", protocol: protocol]
	if (protocol == "KLAP") {
		klapHandshake(getDataValue("baseUrl"), parent.localHash)
	} else if (protocol == "camera") {
		Map hsInput = [url: getDataValue("baseUrl"), user: parent.userName,
					   pwd: parent.encPasswordCam]
		cameraHandshake(hsInput)
	} else if (protocol == "AES") {
		aesHandshake()
	} else if (protocol == "vacAes") {
		vacAesHandshake(getDataValue("baseUrl"), parent.userName, parent.encPasswordVac)
	} else {
		logData << [ERROR: "Protocol not supported"]
		logWarn(logData)
	}
	return logData
}
