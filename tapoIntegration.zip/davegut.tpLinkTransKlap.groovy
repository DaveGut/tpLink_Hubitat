library (
	name: "tpLinkTransKlap",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Handshake methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)

def klapHandshake(baseUrl, localHash, devData = null) {
	byte[] localSeed = getSeed(16)
	Map reqData = [localSeed: localSeed, baseUrl: baseUrl, localHash: localHash, devData:devData]
	Map reqParams = [uri: "${baseUrl}/handshake1",
					 body: localSeed,
					 contentType: "application/octet-stream",
					 requestContentType: "application/octet-stream",
					 timeout:10,
					 ignoreSSLIssues: true]
	asynchttpPost("parseKlapHandshake", reqParams, [data: reqData])
}

def parseKlapHandshake(resp, data) {
	Map reqData = [devData: data.data.devData]
	hs1Success = false
	if (resp.status == 200 && resp.data != null) {
		try {
			byte[] localSeed = data.data.localSeed
			byte[] seedData = resp.data.decodeBase64()
			byte[] remoteSeed = seedData[0 .. 15]
			byte[] serverHash = seedData[16 .. 47]
			byte[] localHash = data.data.localHash.decodeBase64()
			byte[] authHash = [localSeed, remoteSeed, localHash].flatten()
			byte[] localAuthHash = mdEncode("SHA-256", authHash)
			if (localAuthHash == serverHash) {
				//	cookie
				def cookieHeader = resp.headers["Set-Cookie"].toString()
				def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
				//	seqNo and encIv
				byte[] payload = ["iv".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] fullIv = mdEncode("SHA-256", payload)
				byte[] byteSeqNo = fullIv[-4..-1]
				int seqNo = byteArrayToInteger(byteSeqNo)
				if (device) {
					state.seqNo = seqNo
				} else {
					atomicState.seqNo = seqNo
				}
				//	encKey
				payload = ["lsk".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] encKey = mdEncode("SHA-256", payload)[0..15]
				//	encSig
				payload = ["ldk".getBytes(), localSeed, remoteSeed, localHash].flatten()
				byte[] encSig = mdEncode("SHA-256", payload)[0..27]
				hs1Success = true
				logDebug([parseKlapHandshake: reqData])
				if (device) {
					device.updateSetting("cookie",[type:"password", value: cookie]) 
					device.updateSetting("encKey",[type:"password", value: encKey]) 
					device.updateSetting("encIv",[type:"password", value: fullIv[0..11]]) 
					device.updateSetting("encSig",[type:"password", value: encSig]) 
				} else {
					reqData << [cookie: cookie, seqNo: seqNo, encIv: fullIv[0..11], 
								encSig: encSig, encKey: encKey]
				}
				byte[] loginHash = [remoteSeed, localSeed, localHash].flatten()
				byte[] body = mdEncode("SHA-256", loginHash)
				Map reqParams = [uri: "${data.data.baseUrl}/handshake2",
								 body: body,
								 timeout:10,
								 ignoreSSLIssues: true,
								 headers: ["Cookie": cookie],
								 contentType: "application/octet-stream",
								 requestContentType: "application/octet-stream"]
				asynchttpPost("parseKlapHandshake2", reqParams, [data: reqData])
			} else {
				reqData << [respStatus: "ERROR: localAuthHash != serverHash",
							action: "<b>Check credentials and try again</b>"]
			}
		} catch (err) {
			reqData << [respStatus: "ERROR parsing 200 response", resp: resp.properties, error: err,
						action: "<b>Try Configure command</b>"]
		}
	} else {
		reqData << [respStatus: resp.status, message: resp.errorMessage,
					action: "<b>Try Configure command</b>"]
	}
	reqData << [hs1Success: hs1Success]
	if (hs1Success == false) { 
		logWarn([parseKlapHandshake: reqData])
	}
}

def parseKlapHandshake2(resp, data) {
	Map logData = [method: "parseKlapHandshake2"]
	if (resp.status == 200 && resp.data == null) {
		logData << [respStatus: "Login OK"]
		setCommsError(200)
		logDebug(logData)
	} else {
		logData << [respStatus: "LOGIN FAILED", reason: "ERROR in HTTP response",
					resp: resp.properties]
		logWarn(logData)
	}
	if (!device) { sendKlapDataCmd(logData, data) }
}

def getKlapParams(cmdBody) {
	int seqNo = state.seqNo + 1
	state.seqNo = seqNo
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	byte[] encSig = new JsonSlurper().parseText(encSig)
	String cmdBodyJson = new groovy.json.JsonBuilder(cmdBody).toString()

	Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), encKey, encIv,
									encSig, seqNo)
	Map reqParams = [
		uri: "${getDataValue("baseUrl")}/request?seq=${seqNo}",
		body: encryptedData.cipherData,
		headers: ["Cookie": cookie],
		contentType: "application/octet-stream",
		requestContentType: "application/octet-stream",
		timeout: 10,
		ignoreSSLIssues: true]
	return reqParams
}

def parseKlapData(resp, data) {
	Map parseData = [Method: "parseKlapData", sourceMethod: data.data]
	try {
		byte[] encKey = new JsonSlurper().parseText(encKey)
		byte[] encIv = new JsonSlurper().parseText(encIv)
		int seqNo = state.seqNo
		byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
		Map cmdResp =  new JsonSlurper().parseText(klapDecrypt(cipherResponse, encKey,
														   encIv, seqNo))
		parseData << [cryptoStatus: "OK", cmdResp: cmdResp]
	} catch (err) {
		parseData << [cryptoStatus: "decryptDataError", error: err]
	}
	return parseData
}
