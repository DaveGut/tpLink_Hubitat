library (
	name: "tpLinkCamCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common Camera driver methods",
	category: "utilities",
	documentationLink: ""
)

capability "Polling"
capability "Refresh"
capability "Battery"
capability "Motion Sensor"
command "displayPrivacy", [[name: "Display Privacy", constraints: ["on", "off"], type: "ENUM"]]
attribute "privacy", "string"
command "deviceHandshake"
attribute "batteryStatus", "string"
attribute "commsError", "string"

def commonPreferences() {
	input ("motionDetect", "enum", title: "Motion Detection and Sensitivity", options: ["off", "low", "medium", "high"])
	if (getDataValue("alert") == "true") {
		input ("alertConf", "enum", title: "Camera Alert Type", options: ["off", "both", "sound", "light"])
	}
	List ledOpts = ["on", "off"]
	if (getDataValue("ledVer") == "2") { ledOpts = ["auto", "off"] }
	input ("ledRule", "enum", title: "LED Mode", options: ledOpts)
	input ("pollInterval", "enum", title: "Motion Poll Interval",  
		   options: ["off", "5", "10", "15", "30"], defaultValue: "15")
	input ("rebootDev", "bool", title: "Reboot Device", defaultValue: false)
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	sendEvent(name: "motion", value: "inactive")
	updateAttr("commsError", "false")
	state.lastAlarmTime = 0
	state.errorCount = 0
	state.pollInterval = "30"
	Map logData = [configure: configure()]
	runIn(7, updated)
	return logData
}

def commonUpdated() {
	unschedule()
	sendEvent(name: "commsError", value: "false")
	sendEvent(name: "motion", value: "inactive")
	state.errorCount = 0
	if (state.pollInterval == null) {state.pollInterval = "30" }
	Map logData = [commsError: "cleared"]
	logData << setLogsOff()
	if (rebootDev == true) {
		List requests = [[method: "rebootDevice", params: [system: [reboot: "" ]]]]
		sendDevCmd(requests, "rebootDev", "finishReboot")
		logData << [rebootDevice: "device reboot being attempted"]
	} else {
		logData << setPollInterval(pollInterval)
		if (getDataValue("power") != "BATTERY") {
			runEvery1Hour(refresh)
			logData << [refreshInterval: "1 Hour"]
			runEvery1Hour(deviceHandshake)
			logData << [deviceHandshake: "1 Hour"]
		} else {
			runEvery1Hour(udpRefresh)
			logData << [ udpRefreshInterval: "1 hour" ]
		}
		updDevSettings()
		runIn(10, refresh)
	}
	return logData
}

def finishReboot(resp, data = null) {
	Map logData = [finishReboot: "Takes 35 Seconds to finish"]
	logData << [wait: "<b>20s for device to reconnect to LAN</b>", action: "executing deviceHandshake"]
	device.updateSetting("rebootDev",[type:"bool", value: false])
	runIn(30, configure)
	logInfo(logData)
}

def comUpdDevSettings(requests) {
	def motSens = "medium"
	def motDet = motionDetect
	if (motionDetect != "off") { motDet = "on"; motSens = motionDetect }
	requests << [method:"setDetectionConfig",params:[motion_detection:[
		motion_det:[sensitivity: motSens, enabled: motDet]]]]
	if (state.ledStatus != ledRule) {
		requests << [method:"setLedStatus", params:[led:[config:[enabled:ledRule]]]]
	}
	if (getDataValue("alert") == "true") {
		if (alertConf == "off") {
			requests << [method:"setAlertConfig",params: [msg_alarm: [chn1_msg_alarm_info: [enabled: "off"]]]]
		} else {
			def alarmMode = [alertConf]
			if (alertConf == "both") { alarmMode = ["sound", "light"] }
			requests << [method:"setAlertConfig",params: [msg_alarm:[chn1_msg_alarm_info: [alarm_mode: alarmMode, enabled: "on"]]]]
		}
	}
	if (alertConf== "off") {
		requests << [method:"setAlertConfig",params: [msg_alarm: [chn1_msg_alarm_info: [enabled: "off"]]]]
	} else {
		def alarmMode = [config]
		if (alertConf == "both") { alarmMode = ["sound", "light"] }
		requests << [method:"setAlertConfig",params: [msg_alarm:[chn1_msg_alarm_info: [alarm_mode: alarmMode, enabled: "on"]]]]
	}
	sendDevCmd(requests, "updateDevSettings", "parseUpdates")
}

def comRefresh(requests) {
	state.udpRefresh = true
	requests << [method:"getLedStatus",params:[led:[name:["config"]]]]
	requests << [method:"getDetectionConfig",params:[motion_detection:[name:["motion_det"]]]]
	requests << [method:"getLensMaskConfig",params:[lens_mask:[name:["lens_mask_info"]]]]
	if (getDataValue("alert") == "true") {
		requests << [method:"getAlertConfig", params:[msg_alarm:[name:"chn1_msg_alarm_info"]]]
	}
	logDebug([refresh: requests])
	sendDevCmd(requests, "refresh", "parseUpdates")
}

def setPollInterval(interval) {
	Map params = [:]
	unschedule("encrPoll")
	unschedule("udpPoll")
	def pollMethod = "encrPoll"
	if (getDataValue("power")) { pollMethod = "udpPoll" }
	if (interval != "off") {
		if (interval == "error") {
		//	Called if commsError asserted to reduce error handling.
		//	Will reset to state.pollInterval when error cleared.
			runEvery5Minutes("${pollMethod}")
			interval = "5 minutes"
		} else {
			schedule("3/${interval} * * * * ?", "${pollMethod}")
		}
	}
	return [MotionPollData: [method: pollMethod, interval: interval]]
}

def poll() {
	if (getDataValue("power")) { udpPoll() }
	else { encrPoll() }
}

def encrPoll() {
	requests = [[method:"getLastAlarmInfo", params:[system:[name:["last_alarm_info"]]]]]
	sendDevCmd(requests, "encrPoll", "parseUpdates")
}

def udpPoll() {
	def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
	sendFindCmd(getDataValue("devIp"), "20004", cmdData, "parseUdpPoll")
}

def parseUdpPoll(response) {
	def respData = parseLanMessage(response)
	if (respData.type == "LAN_TYPE_UDPCLIENT") {
		byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
		String payloadString = new String(payloadByte)
		Map payload = new JsonSlurper().parseText(payloadString).result
		if (payload.last_alarm_time > state.lastAlarmTime) {
			encrPoll()
		}
		if (state.udpRefresh == true) {
			udpUpdate(payload)
			state.udpRefresh = false
		}
	} else {
		logWarn([parseUdpPoll: [status: "Invalid UDP Poll Return", msg: "try configure"]])
	}
}

def udpRefresh() { state.udpRefresh = true }

def udpUpdate(payload) {
	String batStatus = "normal"
	if (payload.battery_charging == true) { batStatus = "charging" }
	else if (payload.low_battery == true) { batStatus = "low" }
	sendEvent(name: "batteryStatus", value: batStatus)
	sendEvent(name: "battery", value: payload.battery_percent)
	String privacy = "private"
	if (payload.lens_mask == "off") { privacy = "notPrivate" }
	sendEvent(name: "privacy", value: privacy)
	Map logData = [udpUpdate: [batteryStatus: batStatus,
				   battery: payload.battery_percent, privacy: "privacy"]]
	logDebug(logData)
}

def setInactive() { sendEvent(name: "motion", value: "inactive") }

def displayPrivacy(onOff) {
	List requests = [
		[method:"setLensMaskConfig", params:[lens_mask:[lens_mask_info:[enabled: onOff]]]],
		[method:"getLensMaskConfig", params:[lens_mask:[name:["lens_mask_info"]]]]
	]
	sendDevCmd(requests, "setPrivacy", "parseUpdates")
}

//	===== Data Distribution (and parse) =====
def sendDevCmd(requests, data, action) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	asyncSend(cmdBody, data, action)
}

def parseUpdates(resp, data = null) {
	def respData = parseCameraData(resp, data)
	Map logData = [:]
	if (respData.parseStatus == "OK") {
		if (respData.cmdResp.result.responses != null) {
			respData.cmdResp.result.responses.each {
				try {
					if (it.error_code == 0) {
						if (it.method.contains("get")) { 
							logData << "parse_${it.method}"(it.result)
						}
					} else {
						Map errData = ["${it.method}": [status: "cmdFailed", data: it]]
						logWarn([parseUpdates: errData])
					}
				} catch (err) {
					Map errData = ["${it.method}": [result: it.result, ERROR: err]]
					logWarn([parseUpdates: errData])
				}
			}
			logDebug([parseUpdates: logData])
		} else {
			logData << [parseLog: respData, errorMsg: "Unknown Return from Device"]
			logWarn([parseUpdates: logData])
		}
	} else {
		logData << [parseLog: respData, errorMsg: "No cmdResp in return"]
		logWarn([parseUpdates: logData])
	}
}

def parse_getLastAlarmInfo(devResp) {
	Map alarmData = devResp.system.last_alarm_info
	if (alarmData.last_alarm_time.toInteger() > state.lastAlarmTime) {
		state.lastAlarmTime = alarmData.last_alarm_time.toInteger()
		sendEvent(name: "motion", value: "active")
		runIn(30, setInactive)
	}
	return [alarmType: alarmData.last_alarm_type]
}

def parse_getLensMaskConfig(devResp) {
	String privacy = "private"
	if (devResp.lens_mask.lens_mask_info.enabled == "off") {
		privacy = "notPrivate"
	}
	sendEvent(name: "privacy", value: privacy)
	return [privacy: privacy]
}

def parse_getLedStatus(devResp) {
	device.updateSetting("ledRule", [type: "enum", value: devResp.led.config.enabled])
	state.ledStatus = devResp.led.config.enabled
	return [ledRule: devResp.led.config.enabled]
}

def parse_getDeviceAlias(devResp) {
	String alias = devRespsystem.sys.dev_alias
	device.setLabel(alias)
	device.updateSetting("syncName", [type: "enum", value: "notSet"])
	return [label: alias]
}

def parse_getDetectionConfig(devResp) {
	def detData = devResp.motion_detection.motion_det
	def motDet = detData.enabled
	if (motDet == "on") { motDet = detData.sensitivity }
	device.updateSetting("motionDetect", [type: "enum", value: motDet])
	return [motionDetect: motDet, peopleEnable: detData.people_enabled,
			vehEnable: detData.vehicle_enabled, nonVehEnable: detData.non_vehicle_enabled]
}

def parse_getTargetTrackConfig(devResp) {
	device.updateSetting("targetTrack", [type: "enum", value: devResp.target_track.target_track_info.enabled])
	return [targetTrack: devResp.target_track.target_track_info.enabled]
}

def parse_getAlertConfig(devResp) {
	Map alarmInfo = devResp.msg_alarm.chn1_msg_alarm_info
	def alertConfig  = "off"
	if (alarmInfo.enabled == "on") {
		List alarmMode = alarmInfo.alarm_mode
		if (alarmMode.size() > 1|| alarmMode == []) { alertConfig = "both" } 
		else { alertConfig = alarmMode[0] }
	}
	device.updateSetting("alertConf", [type: "enum", value: alertConfig])
	return [alertConf: alertConfig]
}

def nullParse(resp, data) { logDebug "nullParse" }

//	===== Check/Update device data =====
def updateDeviceData(fromConfig = false) {
	def devData = parent.getDeviceData(device.getDeviceNetworkId())
	updateChild(devData, fromConfig)
	return [updateDeviceData: "updating with app data"]
}

def updateChild(devData, fromConfig = false) {
	def currVersion = getDataValue("version")
	Map logData = [devData: devData, fromConfig: fromConfig]
	if (devData != null) {
		devData.each {
			if (it.key != "deviceType" && it.key != "model" && it.key != "alias") {
				updateDataValue(it.key, it.value.toString())
			}
		}
		if (currVersion != version()) {
			updateDataValue("version", version())
			logData << [newVersion: version()]
			runIn(20, updated)
		}
	} else {
		logData << [Note: "DEVICE DATA IS NULL"]
	}
	if (!fromConfig) { deviceHandshake() }
	logInfo([updateChild: logData])
}
