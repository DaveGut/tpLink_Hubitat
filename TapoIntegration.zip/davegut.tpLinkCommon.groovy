library (
	name: "tpLinkCommon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Common driver methods including capability Refresh and Configuration methods",
	category: "utilities",
	documentationLink: ""
)

capability "Refresh"
capability "Configuration"
attribute "commsError", "string"

def commonPreferences() {
	List pollOptions = ["5 sec", "10 sec", "1 min", "5 min", "15 min", "30 min"]
	input ("pollInterval", "enum", title: "Refresh Interval (includes on-off polling)",
		   options: pollOptions, defaultValue: "30 min")
	if (getDataValue("hasLed") == "true") {
		input ("ledRule", "enum", title: "LED Mode (if night mode, set type and times in phone app)",
			   options: ["always", "never", "night_mode"], defaultValue: "always")
	}
	input ("syncName", "enum", title: "Update Device Names and Labels", 
		   options: ["hubMaster", "tapoAppMaster", "notSet"], defaultValue: "notSet")
	input ("rebootDev", "bool", title: "Reboot Device", defaultValue: false)
	input ("logEnable", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
	input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
}

def commonInstalled() {
	Map logData = [method: "commonInstalled"]
	updateAttr("commsError", "false")
	state.errorCount = 0
	logData << [configure: configure()]
	return logData
}

def commonUpdated() {
	unschedule()
	def commsErr = device.currentValue("commsError")
	Map logData = [commsError: commsErr]
	if (rebootDev == true) {
		List requests = [[method: "device_reboot"]]
		sendDevCmd(requests, "rebootDevice", "parseUpdates") 
		logData << [rebootDevice: "device reboot being attempted"]
	} else {
		logData << [pollInterval: setPollInterval()]
		logData << [logging: setLogsOff()]
		logData << [updateDevSettings: updDevSettings()]
		if(pollInterval != "5 sec" && pollInterval != "10 sec") {
			runIn(5, refresh)
		}
		if (getDataValue("isEm") == "true") {
			runIn(7, emUpdated)
		}
	}
	return logData
}

def finishReboot(respData) {
	Map logData = [method: "finishReboot", respData: respData]
	logData << [wait: "<b>20s for device to reconnect to LAN</b>", action: "executing deviceHandshake"]
	runIn(20, configure)
	device.updateSetting("rebootDev",[type:"bool", value: false])
	logInfo(logData)
}

def updDevSettings() {
	List requests = []
	if (syncName == "hubMaster") {
		String nickname = device.getLabel().bytes.encodeBase64().toString()
		requests << [method: "set_device_info", params: [nickname: nickname]]
	}
	if (ledRule) {
		requests << [method: "get_led_info"]
	}
	if (getDataValue("isEm") == "true") {
		requests << [method: "get_energy_usage"]
	}
	requests << [method: "get_device_info"]
	sendDevCmd(requests, device.getDeviceNetworkId(), "parseUpdates")
	return "Updated"
}

//	===== Capability Configuration =====
def appConfigure(delay) {
	runIn(delay, configure)
}
def configure() {
	//	new design.
	//	a.	Ping the device for user information.
	//	b.	Poll the UDP port of the device to see if the device is this 
	//		device.  Goes to method configure2 for parsing.
	//	c.	If not this device, then run parent.tpLinkCheckForDevices to 
	//		repoll the lan and update the device baseUrl (if found).
	//		1.	If not found, notify the user of the failure and continue 
	//		using current baseUrl.
	//	d.  update device data, login to the device, and schedule
	//		periodic logins.
	def ip = getDataValue("baseUrl").replace("""http://""", "").replace(":80/app", "")
	Map logData = [method: "configure", ip: ip]
	logInfo("executing ${logData}")
	def await = ping()	//	quick check to (possibly) wake up connection. Also informs user if fails.
	def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
	try {
		sendFindCmd(ip, "20002", cmdData, "configure2", timeout)
		logInfo(logData)
	} catch (err) {
		//	If error here, log. then run parent.tpLinkCheckForDevices
		//	followed by configure3
		def parentChecked = parent.tpLinkCheckForDevices(5)
		logData << [status: "FAILED", error: err, parentChecked: parentChecked]
		logWarn(logData)
		configure3(parentChecked)
	}
}
def configure2(response) {
	Map logData = [method: "configure2"]
	def respData = parseLanMessage(response)
	String hubDni = device.getDeviceNetworkId()
	logData << [dni: respData.mac, hubDni: hubDni]
	def parentChecked = false
	if (respData.mac != hubDni) {
		logData << [status: "FAILED", action: "parentCheck"]
		parentChecked = parent.tpLinkCheckForDevices(5)
	} else {
		logData << [status: "OK", action: configure3]
	}
	configure3(parentChecked)
	logInfo(logData)
}
def configure3(parentChecked = false) {
	Map logData = [method: "configure3", parentChecked: parentChecked]
	logData << updateDeviceData()
	logData << deviceHandshake()
	pauseExecution(10000)
	runEvery3Hours(deviceHandshake)
	logData << [handshakeInterval: "3 Hours"]
	logData << [action: "exec updated"]
	runIn(2, updated)
	logInfo(logData)
}

def setPollInterval(pInterval = pollInterval) {
	if (pInterval.contains("sec")) {
		logWarn("<b>Poll intervals of less than 1 minute may overload the Hub</b>")
		def interval = pInterval.replace(" sec", "").toInteger()
		def start = Math.round((interval-1) * Math.random()).toInteger()
		schedule("${start}/${interval} * * * * ?", "refresh")
	} else {
		def interval= pInterval.replace(" min", "").toInteger()
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${interval} * * * ?", "refresh")
	}
	return pInterval
}

//	===== Data Distribution (and parse) =====
def parseUpdates(resp, data = null) {
	Map logData = [method: "parseUpdates", data: data]
	def respData = parseData(resp)
	if (resp.status == 200 && respData.cryptoStatus == "OK") {
		def cmdResp = respData.cmdResp.result.responses
		if (respData.cmdResp.result.responses != null) {
			respData.cmdResp.result.responses.each {
				if (it.error_code == 0) {
					distGetData(it, data)
				} else {
					logData << ["${it.method}": [status: "cmdFailed", data: it]]
					logDebug(logData)
				}
			}
		}
		if (respData.cmdResp.result.responseData != null) {
			respData.cmdResp.result.responseData.result.responses.each {
				if (it.error_code == 0) {
					distChildGetData(it, data)
				} else {
					logData << ["${it.method}": [status: "cmdFailed", data: it]]
					logDebug(logData)
				}
			}
		}
	} else {
		logData << [errorMsg: "Misc Error"]
		logDebug(logData)
	}
}

def distGetData(devResp, data) {
	switch(devResp.method) {
		case "get_device_info":
			parse_get_device_info(devResp.result, data)
			parseNameUpdate(devResp.result)
			break
		case "get_current_power":
			parse_get_current_power(devResp.result, data)
			break
		case "get_device_usage":
			parse_get_device_usage(devResp.result, data)
			break
		case "get_child_device_list":
			parse_get_child_device_list(devResp.result, data)
			break
		case "get_alarm_configure":
			parse_get_alarm_configure(devResp.result, data)
			break
		case "get_led_info":
			parse_get_led_info(devResp.result, data)
			break
		case "device_reboot":
			finishReboot(devResp)
			break
		case "get_battery_info":
			parse_get_battery_info(devResp.result)
			break
		case "getCleanNumber":
			parse_getCleanNumber(devResp.result)
			break
		case "getSwitchClean":
			parse_getSwitchClean(devResp)
			break
		case "getMopState":
			parse_getMopState(devResp)
			break
		case "getSwitchCharge":
			updateAttr("docking", devResp.switch_charge)
			break
		case "getVacStatus":
			parse_getVacStatus(devResp.result)
			break
		default:
			if (!devResp.method.contains("set_")) {
				Map logData = [method: "distGetData", data: data,
							   devMethod: devResp.method, status: "unprocessed"]
				logDebug(logData)
			}
	}
}

def parse_get_led_info(result, data) {
	Map logData = [method: "parse_get_led_info", data: data]
	if (ledRule != result.led_rule) {
		Map request = [
			method: "set_led_info",
			params: [
				led_rule: ledRule,
				night_mode: [
					night_mode_type: result.night_mode.night_mode_type,
					sunrise_offset: result.night_mode.sunrise_offset, 
					sunset_offset:result.night_mode.sunset_offset,
					start_time: result.night_mode.start_time,
					end_time: result.night_mode.end_time
				]]]
		asyncSend(request, "delayedUpdates", "parseUpdates")
		device.updateSetting("ledRule", [type:"enum", value: ledRule])
		logData << [status: "updatingLedRule"]
	}
	logData << [ledRule: ledRule]
	logDebug(logData)
}

def parseNameUpdate(result) {
	if (syncName != "notSet") {
		Map logData = [method: "parseNameUpdate"]
		byte[] plainBytes = result.nickname.decodeBase64()
		def newLabel = new String(plainBytes)
		device.setLabel(newLabel)
		device.updateSetting("syncName",[type:"enum", value: "notSet"])
		logData << [label: newLabel]
		logDebug(logData)
	}
}

//	===== Capability Refresh =====
def refresh() {
	def type = getDataValue("type")
	List requests = [[method: "get_device_info"]]
	if (type == "Hub" || type == "Parent") {
		requests << [method:"get_child_device_list"]
	}
	if (getDataValue("isEm") == "true") {
		requests << [method: "get_current_power"]
	}
	if (getDataValue("protocol") == "vacAes") {
		vacRefresh()
	}
	sendDevCmd(requests, device.getDeviceNetworkId(), "parseUpdates")
}

//	===== Version Compatibility =====
def plugEmRefresh() { refresh() }
def parentRefresh() { refresh() }
def minRefresh() { refresh() }

def sendDevCmd(requests, data, action) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	asyncSend(cmdBody, data, action)
}

def nullParse(resp, data) { }

//	===== Check/Update device data =====
def updateDeviceData() {
	def devData = parent.getDeviceData(device.getDeviceNetworkId())
	updateChild(devData)
	return [updateDeviceData: "updating with app data"]
}

def updateChild(devData) {
	def currVersion = getDataValue("version")
	Map logData = [method: "updateChild"]
	if (devData != null) {
		updateDataValue("baseUrl", devData.baseUrl)
		updateDataValue("protocol", devData.protocol)
		logData << [baseUrl: devData.baseUrl, protocol: devData.protocol]
		if (currVeresion != version()) {
			updateDataValue("isEm", devData.isEm)
			updateDataValue("hasLed", devData.hasLed)
			updateDataValue("version", version())
		}
		logData << [isEm: devData.isEm, hasLed: devData.hasLed, 
					currVersion: currVersion, newVersion: version()]
	} else {
		logData << [Note: "DEVICE DATA IS NULL"]
	}
	logInfo(logData)
}

//	===== Device Handshake =====
def deviceHandshake() {
	//	Do a three packet ping to check LAN connectivity.  This does
	//	not stop the sending of the handshake message.
	def await = ping()
	//	On handshake, will log into device and then attempt a command
	//	that validates the complete crypto path (get_device_info - no parse).
	//	When comms error is set for 403 or 408 reasons, this procedure is
	//	scheduled for every 10 minutes to check if the condition has alleviated.
	def protocol = getDataValue("protocol")
	Map logData = [method: "deviceHandshake", protocol: protocol]
	if (protocol == "KLAP") {
		klapHandshake()
	} else if (protocol == "AES") {
		aesHandshake()
	} else if (protocol == "vacAes") {
		vacHandshake()
	} else {
		logData << [ERROR: "Protocol not supported"]
	}
	logDebug(logData)
	runIn(5, commsTest)
	return logData
}

def commsTest() {
	List requests = [[method: "get_device_info"]]
	sendDevCmd(requests, device.getDeviceNetworkId(), "parseCommsTest")
}
def parseCommsTest(resp, data = null) {
	Map logData = [method: "parseCommsTest"]
	Map respData = parseData(resp)
	def message = "OK"
	if (resp.status == 200 && respData.cryptoStatus == "OK") {
		logData << [testStatus: "success", userMessage: "Comms Path (lan/crypto module) OK"]
		logInfo(logData)
	} else if (respData.cryptoStatus != "OK") {
		logData << [testStatus: "FAILED - Crypto",
					userMessage: "Decrypting failed.  Run Configure."]
		logWarn(logData)
	} else if (resp.status != 200) {
		logData << [testStatus: "FAILED - noRoute", respMessage: message,
					userMessage: "Your router connection to ${getDataValue("baseUrl")} failed.  Run Configure."]
		logWarn(logData)
	} else {
		logData << [testStatus: "FAILED - unknown cause"]
	}
}
