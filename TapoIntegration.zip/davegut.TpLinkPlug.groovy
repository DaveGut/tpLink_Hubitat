/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

Supports:  Tapo Plugs and Switches, New and Matter Kasa Plugs and Switches.
=================================================================================================*/
metadata {
	definition (name: "TpLink Plug", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_plug.groovy")
	{ }
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	state.eventType = "digital"
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	switchParse(result)
}

#include davegut.tpLinkCapSwitch
#include davegut.tpLinkCapEngMon
#include davegut.tpLinkCommon
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.Logging
