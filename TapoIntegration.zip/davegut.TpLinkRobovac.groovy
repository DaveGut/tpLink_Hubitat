/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Robovac", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_robovac.groovy")
	{
		capability "Battery"
		capability "Actuator"
		command "setCleanPrefs", [
			[name: "cleanPasses", type: "ENUM", description: "Number of Vacuum Passes",
			 constraints: [1, 2, 3]],
			[name: "vacSuction", type: "ENUM", description: "Vacuum Suction", 
			 constraints: ["quiet", "standard", "turbo", "max"]],
			[name: "waterLevel", type: "ENUM", description: "Vacuum Suction", 
			 constraints: ["none", "low", "moderate", "high"]]]
		attribute "cleanPasses", "number"
		attribute "vacuumSuction", "string"
		attribute "waterLevel", "string"
		command "cleanStart"
		command "cleanPause"
		command "cleanResume"
		command "dockVacuum"
		attribute "docking", "string"
		attribute "cleanOn", "string"
		attribute "vacuumStatus", "string"
		attribute "prompt", "string"
		attribute "promptCode", "promptCode"
		attribute "mopState", "string"
		attribute "waterLevel", "number"
	}
	preferences {
		commonPreferences()
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	state.eventType = "digital"
	logInfo(logData)
}

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

//	===== Cleaning Control =====
def cleanStart() {
	logDebug([method: "cleanStart"])
	def cmdBody = [method: "setSwitchClean", params: [clean_on: true, clean_mode: 0]]
	asyncSend(cmdBody,"cleanStart", "controlParse")
}

def cleanPause() {
	logDebug([method: "cleanPause"])
	def cmdBody = [method: "setRobotPause", params: [pause: true]]
	asyncSend(cmdBody,"cleanPause", "controlParse")
}

def cleanResume() {
	logDebug([method: "cleanResume"])
	def cmdBody = [method: "setRobotPause", params: [pause: false]]
	asyncSend(cmdBody,"dcleanResume", "controlParse")
}

def dockVacuum() {
	logDebug([method: "dockVacuum"])
	def cmdBody = [method: "setSwitchCharge", params: [switch_charge: true]]
	asyncSend(cmdBody,"dockVacuum", "controlParse")
}

def controlParse(resp, data=null) {
	Map logData = [method: "controlParse", control: data]
	try {
		def respData = parseData(resp)
		logData << [respData: respData]
		if(respData.cmdResp != "ERROR" && respData.cmdResp.error_code == 0) {
			runIn(8, getCleanData)
			logDebug(logData)
		} else {
			logData << [resp: resp.properties]
			logWarn(logData)
		}
	} catch (err) {
		logData << [errorData: err]
		logWarn(logData)
	}
}

def getCleanData() {
	logDebug([method: "getCleanData"])
	List requests = [
		[method: "getSwitchClean"],
		[method: "getVacStatus"],
		[method: "getMopState"],
		[method: "getSwitchCharge"]]
	sendDevCmd(requests,"getCleanData", "parseUpdates")
}

def parse_getVacStatus(vacData) {
	Map logData = [method: "parse_getVacStatus"]
	String vacuumStatus
	switch (vacData.status) {
		case 0: vacuumStatus = "OffDock/notCleaning"; break
		case 1: vacuumStatus = "cleaning"; break
		case 2: vacuumStatus = "2"; break
		case 3: vacuumStatus = "3"; break
		case 4: vacuumStatus = "docking"; break
		case 5: vacuumStatus = "docked/charging"; break
		case 6: vacuumStatus = "docked/charged"; break
		case 7: vacuumStatus = "paused"; break
		default: vacuumStatus = "${vacData.status}"
	}
	updateAttr("vacuumStatus", vacuumStatus)
	updateAttr("prompt", vacData.prompt)
	updateAttr("promptCode", vacData.promptCode_id)
	logData << [vacuumStatus: vacuumStatus, cleanOn: cleanOn, docking: docking,
			   mopState: mopState]
	if (vacData.status != 6 && vacData.status != 5) {
		runIn(60, getCleanData)
	}
	logDebug(logData)
}

//	==== Clean Preferences ====
def setCleanPrefs(passes=1, suction="standard", water="none") {
	def logData = [method: "setCleanPrefs", passes: passes, suction: suction, waterLevel: water]
	Integer sucNo
	switch(suction) {
		case "standard": sucNo = 2; break
		case "turbo": sucNo = 3; break
		case "max": sucNo = 4; break
		default: sucNo = 1
	}
	Integer watLev
	switch(water) {
		case "low": watLev = 2; break
		case "moderate": watLev = 3; break
		case "high": watLev = 4; break
		default: watLev = 1
	}
	List requests = [
		[method:"setCleanNumber", params:[suction_level: sucNo, 
										  clean_number: passes.toInteger(), 
										  cistern: watLev]],
		[method: "getCleanNumber"]]
	sendDevCmd(requests, "setCleanPrefs", "parseUpdates")
	logDebug(logData)
}

def parse_getCleanNumber(result) {
	logDebug([method: "parse_getCleanNumber", result: result])
	updateAttr("cleanPasses", result.clean_number)
	String vacuumSuction
	switch(result.suction) {
		case 2: vacuumSuction = "standard"; break
		case 3: vacuumSuction = "turbo"; break
		case 4: vacuumSuction = "max"; break
		default: vacuumSuction = "quiet"
	}
	updateAttr("vacuumSuction", vacuumSuction)
	String waterLevel
	switch(result.cistern) {
		case 2: waterLevel = "low"; break
		case 3: waterLevel = "moderate"; break
		case 4: waterLevel = "high"; break
		default: waterLevel = "none"
	}
	updateAttr("waterLevel", waterLevel)
}

//	===== Refresh =====
def vacRefresh() {
	getCleanData()
	List requests = [
		[method: "getBatteryInfo"],
		[method: "getCleanNumber"]	]
	sendDevCmd(requests, "refresh", "parseUpdates")
}

def parse_get_device_info(result, data) { }
def parse_get_battery_info(result) {
	logDebug([method: "parse_get_battery_info", result: result])
	updateAttr("battery", devResp.result.battery_percentage)
}
def parse_getSwitchClean(result) {
	logDebug([method: "parse_getSwitchClean", result: result])
	updateAttr("cleanOn", result.clean_on)
}
def parse_getSwitchCharge(result) {
	logDebug([method: "parse_getSwitchCharge", result: result])
	updateAttr("docking", result.switch_charge)
}
def parse_getMopState(result) {
	logDebug([method: "parse_getMopState", result: result])
	updateAttr("mopState", result.mop_state)
}

//	===== Login =====
def vacHandshake() { 
	Map reqData = [:]
	Map cmdBody = [method: "login",
				   params: [hashed: true, 
							password: parent.encPasswordVac,
							username: parent.userName]]
	Map reqParams = [uri: getDataValue("baseUrl"),
					 ignoreSSLIssues: true,
					 body: cmdBody,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10]
	asynchttpPost("parseVacAesLogin", reqParams, [data: reqData])
}

def parseVacAesLogin(resp, data) {
	Map logData = [method: "parseVacAesLogin", oldToken: token]
	if (resp.status == 200 && resp.json != null) {
		logData << [status: "OK"]
		def newToken = resp.json.result.token
		device.updateSetting("token", [type: "string", value: newToken])
		logData << [token: newToken]
		setCommsError(200)
		logDebug(logData)
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

//	===== Communications =====
def getVacAesParams(cmdBody) {
	Map reqParams = [uri: "${getDataValue("baseUrl")}/?token=${token}",
					 body: cmdBody,
					 contentType: "application/json",
					 requestContentType: "application/json",
					 ignoreSSLIssues: true,
					 timeout: 10]
	return reqParams	
}

def parseVacAesData(resp) {
	Map parseData = [parseMethod: "parseVacAesData"]
	try {
		parseData << [cryptoStatus: "OK", cmdResp: resp.json]
		logDebug(parseData)
	} catch (err) {
		parseData << [cryptoStatus: "deviceDataParseError", error: err, dataLength: resp.data.length()]
		logWarn(parseData)
		handleCommsError()
	}
	return parseData
}

#include davegut.tpLinkCommon
#include davegut.tpLinkComms
#include davegut.Logging
