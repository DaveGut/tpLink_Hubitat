library (
	name: "tpLinkComms",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Communication methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

//	===== Async Commsunications Methods =====
def asyncSend(cmdBody, reqData, action) {
	Map cmdData = [cmdBody: cmdBody, reqData: reqData, action: action]
	def protocol = getDataValue("protocol")
	Map reqParams = [:]
	if (protocol == "KLAP") {
		reqParams = getKlapParams(cmdBody)
	} else if (protocol == "AES") {
		reqParams = getAesParams(cmdBody)
	} else if (protocol == "vacAes") {
		reqParams = getVacAesParams(cmdBody)
	}
	if (state.errorCount == 0) {
		state.lastCommand = cmdData
	}
	asynchttpPost(action, reqParams, [data: reqData])
}

def parseData(resp, protocol = getDataValue("protocol")) {
	Map logData = [method: "parseData", status: resp.status]
	def message = "OK"
	if (resp.status != 200) { message = resp.errorMessage }
	if (resp.status == 200) {
		if (protocol == "KLAP") {
			logData << parseKlapData(resp)
		} else if (protocol == "AES") {
			logData << parseAesData(resp)
		} else if (protocol == "vacAes") {
			logData << parseVacAesData(resp)
		}
	} else {
		String userMessage = "unspecified"
		if (resp.status == 403) {
			userMessage = "<b>Try again. If error persists, check your credentials</b>"
		} else if (resp.status == 408) {
			userMessage = "<b>Your router connection to ${getDataValue("baseUrl")} failed.  Run Configure.</b>"
		} else {
			userMessage = "<b>Unhandled error Lan return</b>"
		}
		logData << [respMessage: message, userMessage: userMessage]
		logDebug(logData)
	}
	handleCommsError(resp.status, message)
	return logData
}

//	===== Communications Error Handling =====
def handleCommsError(status, msg = "") {
	//	Retransmit all comms error except Switch and Level related (Hub retries for these).
	//	This is determined by state.digital
	if (status == 200) {
		setCommsError(status, "OK")
	} else {
		Map logData = [method: "handleCommsError", status: code, msg: msg]
		def count = state.errorCount + 1
		logData << [count: count, status: status, msg: msg]
		switch(count) {
			case 1:
			case 2:
				//	errors 1 and 2, retry immediately
				runIn(2, delayedPassThrough)
				break
			case 3:
				//	error 3, login or scan find device on the lan
				//	then retry
				if (status == 403) {
					logData << [action: "attemptLogin"]
					deviceHandshake()
					runIn(4, delayedPassThrough)
				} else {
					logData << [action: "Find on LAN then login"]
					configure()
					runIn(10, delayedPassThrough)
				}
				break
			case 4:
				runIn(2, delayedPassThrough)
				break
			default:
				//	Set comms error first time errros are 5 or more.
				logData << [action: "SetCommsErrorTrue"]
				setCommsError(status, msg, 5)
		}
		state.errorCount = count
		logInfo(logData)
	}
}

def delayedPassThrough() {
	//	Do a single packet ping to check LAN connectivity.  This does
	//	not stop the sending of the retry message.
	def await = ping(getDataValue("baseUrl"), 1)
	def cmdData = new JSONObject(state.lastCommand)
	def cmdBody = parseJson(cmdData.cmdBody.toString())
	asyncSend(cmdBody, cmdData.reqData, cmdData.action)
}

def ping(baseUrl = getDataValue("baseUrl"), count = 1) {
	def ip = baseUrl.replace("""http://""", "").replace(":80/app", "").replace(":4433", "")
	ip = ip.replace("""https://""", "").replace(":4433", "")
	hubitat.helper.NetworkUtils.PingData pingData = hubitat.helper.NetworkUtils.ping(ip, count)
	Map pingReturn = [method: "ping", ip: ip]
	if (pingData.packetsReceived == count) {
		pingReturn << [pingStatus: "success"]
		logDebug(pingReturn)
	} else {
		pingReturn << [pingData: pingData, pingStatus: "<b>FAILED</b>.  There may be issues with your LAN."]
		logWarn(pingReturn)
	}
	return pingReturn
}

def setCommsError(status, msg = "OK", count = state.commsError) {
	Map logData = [method: "setCommsError", status: status, errorMsg: msg, count: count]
	if (device && status == 200) {
		state.errorCount = 0
		if (device.currentValue("commsError") == "true") {
			updateAttr("commsError", "false")
			setPollInterval()
			unschedule(errorDeviceHandshake)
			logInfo(logData)
		}
	} else if (device) {
		if (device.currentValue("commsError") == "false" && count > 4) {
			updateAttr("commsError", "true")
			setPollInterval("30 min")
			runEvery10Minutes(errorConfigure)
			logData << [pollInterval: "30 Min", errorDeviceHandshake: "ever 10 min"]
			logWarn(logData)
			if (status == 403) {
				logWarn(logInErrorAction())
			} else {
				logWarn(lanErrorAction())
			}
		} else {
			logData << [error: "Unspecified Error"]
			logWarn(logData)
		}
	}
}

def lanErrorAction() {
	def action = "Likely cause of this error is YOUR LAN device configuration: "
	action += "a. VERIFY your device is on the DHCP list in your router, "
	action += "b. VERIFY your device is in the active device list in your router, and "
	action += "c. TRY controlling your device from the TAPO phone app."
	return action
}

def logInErrorAction() {
	def action = "Likely cause is your login credentials are incorrect or the login has expired. "
	action += "a. RUN command Configure. b. If error persists, check your credentials in the App"
	return action
}

def errorConfigure() {
	logDebug([method: "errorConfigure"])
	configure()
}

//	===== Common UDP Communications for checking if device at IP is device in Hubitat =====
private sendFindCmd(ip, port, cmdData, action, commsTo = 5, ignore = false) {
	def myHubAction = new hubitat.device.HubAction(
		cmdData,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "${ip}:${port}",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 ignoreResponse: ignore,
		 parseWarning: true,
		 timeout: commsTo,
		 callback: action])
	try {
		sendHubCommand(myHubAction)
	} catch (error) {
		logWarn("sendLanCmd: command to ${ip}:${port} failed. Error = ${error}")
	}
	return
}
