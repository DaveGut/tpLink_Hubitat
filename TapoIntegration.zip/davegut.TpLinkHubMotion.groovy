/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
metadata {
	definition (name: "TpLink Hub Motion", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_hub_motion.groovy")
	{
		capability "Motion Sensor"
		attribute "lowBattery", "string"
		capability "Sensor"
	}
	preferences {
		commonPreferences()
	}
}

def installed() { runIn(1, updated) }

def updated() {
	Map logData = [method: "updated", commonUpdated: commonUpdated()]
	logInfo(logData)
}

//	Parse Methods
def parse_get_device_info(result, data = null) {
	Map logData = [method: "parse_get_device_info"]
	def motion = "inactive"
	if (result.detected) { motion = "active" }
	updateAttr("motion", motion)
	logData << [motion: motion]
	logDebug(logData)
}

#include davegut.tpLinkChildCommon
#include davegut.Logging
