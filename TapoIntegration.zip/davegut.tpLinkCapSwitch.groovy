library (
	name: "tpLinkCapSwitch",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat capability Switch methods",
	category: "utilities",
	documentationLink: ""
)

capability "Switch"

def on() { setPower(true) }

def off() { setPower(false) }

def setPower(onOff) {
	state.eventType = "digital"
	logDebug("setPower: [device_on: ${onOff}]")
	List requests = [[
		method: "set_device_info",
		params: [device_on: onOff]]]
	requests << [method: "get_device_info"]
	sendDevCmd(requests, device.getDeviceNetworkId(), "parseUpdates")
}

def switchParse(result) {
	Map logData = [method: "switchParse"]
	if (result.device_on != null) {
		def onOff = "off"
		if (result.device_on == true) { onOff = "on" }
		if (device.currentValue("switch") != onOff) {
			sendEvent(name: "switch", value: onOff, type: state.eventType)
			if (getDataValue("isEm") == "true" && !pollInterval.contains("sec")) {
				runIn(4, refresh)
			}
		}
		state.eventType = "physical"
		logData << [switch: onOff]
	}
	logDebug(logData)
}
